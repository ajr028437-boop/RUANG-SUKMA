<?php
    $hostname = 'localhost';
    $username = 'root';
    $passwoard= '';
    $dbname   = 'db_ruang_sukma';

    $conn = mysqli_connect($hostname, $username, $passwoard, $dbname) or die ('gagal terhubung ke database');
?>
