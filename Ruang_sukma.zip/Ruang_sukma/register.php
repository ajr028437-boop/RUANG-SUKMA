<?php
// register.php
session_start();
include 'db.php';

// Jika sudah login, redirect ke index
if (isset($_SESSION['user_login'])) {
    header("Location: index.php");
    exit;
}

$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama = trim($_POST['nama'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $password_confirm = $_POST['password_confirm'] ?? '';
    $no_hp = trim($_POST['no_hp'] ?? '');
    $alamat = trim($_POST['alamat'] ?? '');
    $lokasi = trim($_POST['lokasi'] ?? '');

    // Validasi dasar
    if (empty($nama) || empty($email) || empty($password) || empty($password_confirm)) {
        $error = "Nama, email, password, dan konfirmasi password wajib diisi!";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Format email tidak valid!";
    } elseif (strlen($password) < 6) {
        $error = "Password minimal 6 karakter!";
    } elseif ($password !== $password_confirm) {
        $error = "Password dan konfirmasi password tidak sama!";
    } else {
        // Cek email sudah dipakai atau belum (prepared statement)
        $cek_query = "SELECT id FROM tb_user WHERE email = ?";
        $stmt_cek = mysqli_prepare($conn, $cek_query);
        if ($stmt_cek) {
            mysqli_stmt_bind_param($stmt_cek, "s", $email);
            mysqli_stmt_execute($stmt_cek);
            mysqli_stmt_store_result($stmt_cek);
            
            if (mysqli_stmt_num_rows($stmt_cek) > 0) {
                $error = "Email sudah terdaftar! Gunakan email lain atau <a href='login_user.php'>login</a>.";
            } else {
                mysqli_stmt_close($stmt_cek);
                
                // Hash password
                $password_hash = password_hash($password, PASSWORD_DEFAULT);
                
                // Insert ke tb_user (nama kolom password diperbaiki)
                $insert_query = "INSERT INTO tb_user (nama, email, no_hp, alamat, lokasi, password, created_at) VALUES (?, ?, ?, ?, ?, ?, NOW())";
                $stmt_insert = mysqli_prepare($conn, $insert_query);
                if ($stmt_insert) {
                    mysqli_stmt_bind_param($stmt_insert, "ssssss", $nama, $email, $no_hp, $alamat, $lokasi, $password_hash);
                    if (mysqli_stmt_execute($stmt_insert)) {
                        // Tidak auto-login, redirect ke login_user.php dengan pesan sukses
                        mysqli_stmt_close($stmt_insert);
                        header("Location: login_user.php?register=success");
                        exit;
                    } else {
                        $error = "Gagal daftar: " . mysqli_stmt_error($stmt_insert) . ". Coba lagi!";
                    }
                    mysqli_stmt_close($stmt_insert);
                } else {
                    $error = "Terjadi kesalahan pada server (mungkin kolom password tidak ada). Coba lagi!";
                }
            }
        } else {
            $error = "Terjadi kesalahan pada server. Coba lagi!";
        }
        if (isset($stmt_cek)) mysqli_stmt_close($stmt_cek);
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Ruang Sukma - Daftar Akun</title>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Google Fonts: Poppins -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <!-- Font Awesome -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
  <style>
    body {
      font-family: 'Poppins', sans-serif;
      background: linear-gradient(135deg, #f4f6f8, #e9ecef);
      color: #333;
      line-height: 1.6;
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 20px;
    }
    .register-card {
      background: #fff;
      border-radius: 20px;
      box-shadow: 0 10px 30px rgba(0,0,0,0.1);
      padding: 2rem;
      width: 100%;
      max-width: 450px;
      text-align: center;
    }
    .register-card h2 {
      color: #d83a4a;
      margin-bottom: 1.5rem;
      font-weight: 600;
    }
    .form-control {
      border-radius: 10px;
      border: 1px solid #ddd;
      padding: 0.75rem;
      margin-bottom: 1rem;
    }
    .form-label {
      font-weight: 500;
      color: #d83a4a;
      text-align: left;
    }
    .btn-register {
      background: linear-gradient(135deg, #d83a4a, #c0392b);
      color: #fff;
      border: none;
      padding: 0.75rem;
      border-radius: 10px;
      font-weight: 500;
      width: 100%;
      transition: all 0.3s;
    }
    .btn-register:hover {
      background: linear-gradient(135deg, #c0392b, #a93226);
      transform: translateY(-2px);
    }
    .alert {
      border-radius: 10px;
      margin-bottom: 1rem;
    }
    .alert a {
      color: inherit;
      text-decoration: underline;
    }
    .login-link {
      color: #d83a4a;
      text-decoration: underline;
    }
    .optional-field {
      font-size: 0.9rem;
      color: #666;
      margin-top: -0.5rem;
      margin-bottom: 1rem;
    }
    /* Responsive */
    @media (max-width: 576px) {
      .register-card { padding: 1.5rem; }
    }
  </style>
</head>
<body>

<div class="register-card">
  <i class="fas fa-user-plus fa-3x text-primary mb-3"></i>
  <h2>Daftar Akun Baru</h2>
  <p class="text-muted mb-3">Buat akun untuk belanja lebih mudah di Ruang Sukma.</p>
  
  <?php if ($error): ?>
    <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
  <?php endif; ?>
  
  <?php if (!$error && !isset($_SESSION['user_login'])): ?>
    <form method="POST" id="registerForm">
      <div class="mb-3">
        <label class="form-label">Nama Lengkap *</label>
        <input type="text" name="nama" class="form-control" placeholder="Masukkan nama Anda" required value="<?= htmlspecialchars($nama ?? '') ?>">
      </div>
      <div class="mb-3">
        <label class="form-label">Email *</label>
        <input type="email" name="email" class="form-control" placeholder="Masukkan email Anda" required value="<?= htmlspecialchars($email ?? '') ?>">
      </div>
      <div class="mb-3">
        <label class="form-label">Password *</label>
        <input type="password" name="password" class="form-control" placeholder="Buat password kuat (minimal 6 karakter)" required minlength="6">
      </div>
      <div class="mb-3">
        <label class="form-label">Konfirmasi Password *</label>
        <input type="password" name="password_confirm" class="form-control" placeholder="Ulangi password Anda" required minlength="6">
      </div>
      <div class="mb-3">
        <label class="form-label">Nomor HP / WhatsApp (Opsional)</label>
        <input type="tel" name="no_hp" class="form-control" placeholder="08xxxxxxxxxx" value="<?= htmlspecialchars($no_hp ?? '') ?>">
        <div class="optional-field">Untuk konfirmasi pesanan dan pengiriman.</div>
      </div>
      <div class="mb-3">
        <label class="form-label">Alamat (Opsional)</label>
        <textarea name="alamat" class="form-control" rows="2" placeholder="Jl. Contoh No. 123, RT/RW, Kelurahan"><?= htmlspecialchars($alamat ?? '') ?></textarea>
        <div class="optional-field">Alamat lengkap untuk pengiriman (bisa diubah nanti).</div>
      </div>
      <div class="mb-3">
        <label class="form-label">Lokasi / Kota (Opsional)</label>
        <input type="text" name="lokasi" class="form-control" placeholder="Kelurahan, Kecamatan, Kota" value="<?= htmlspecialchars($lokasi ?? '') ?>">
        <div class="optional-field">Misal: Kelurahan Test, Kecamatan Demo, Kota Bandung.</div>
      </div>
      <button type="submit" class="btn btn-register">
        <i class="fas fa-user-plus me-2"></i>Daftar Sekarang
      </button>
    </form>
  <?php endif; ?>
  
  <p class="mt-3 mb-0">Sudah punya akun? <a href="login_user.php" class="login-link">Login sekarang</a></p>
</div>

<!-- Scripts -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Validasi konfirmasi password di client-side
document.getElementById('registerForm').addEventListener('submit', function(e) {
    const password = document.querySelector('input[name="password"]').value;
    const confirm = document.querySelector('input[name="password_confirm"]').value;
    if (password !== confirm) {
        e.preventDefault();
        alert('Password dan konfirmasi password tidak sama!');
    }
});
</script>

</body>
</html>
<?php
mysqli_close($conn);
?>