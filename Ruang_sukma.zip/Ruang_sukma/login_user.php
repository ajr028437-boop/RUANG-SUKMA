<?php
// login_user.php
session_start();
include 'db.php';

// Jika sudah login, redirect ke index
if (isset($_SESSION['user_login'])) {
    header("Location: index.php");
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    
    if (empty($email) || empty($password)) {
        $error = "Email dan password wajib diisi!";
    } else {
        // Prepared statement untuk query user (gunakan 'password' bukan 'passwoard')
        $query = "SELECT id, nama, password FROM tb_user WHERE email = ?";
        $stmt = mysqli_prepare($conn, $query);
        if ($stmt) {
            mysqli_stmt_bind_param($stmt, "s", $email);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_store_result($stmt);
            
            if (mysqli_stmt_num_rows($stmt) > 0) {
                mysqli_stmt_bind_result($stmt, $id, $nama, $password_hash);  // Ganti 'passwoard' jadi 'password'
                mysqli_stmt_fetch($stmt);
                
                // Verifikasi password (hashed)
                if (password_verify($password, $password_hash)) {
                    // Login sukses, set session
                    $_SESSION['user_login'] = true;
                    $_SESSION['user_id'] = $id;
                    $_SESSION['user_name'] = $nama;
                    $_SESSION['user_email'] = $email;
                    
                    mysqli_stmt_close($stmt);
                    header("Location: index.php?login=success");
                    exit;
                } else {
                    $error = "Password salah!";
                }
            } else {
                $error = "Email tidak ditemukan!";
            }
            mysqli_stmt_close($stmt);
        } else {
            $error = "Terjadi kesalahan pada server (mungkin kolom password tidak ada).";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Ruang Sukma - Login</title>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <!-- Google Fonts: Poppins -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet" />
  <!-- Font Awesome -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
  <style>
    body {
      font-family: 'Poppins', sans-serif;
      background: linear-gradient(135deg, #f4f6f8, #e9ecef);
      color: #333;
      line-height: 1.6;
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 20px;
    }
    .login-card {
      background: #fff;
      border-radius: 20px;
      box-shadow: 0 10px 30px rgba(0,0,0,0.1);
      padding: 2rem;
      width: 100%;
      max-width: 400px;
      text-align: center;
    }
    .login-card h2 {
      color: #d83a4a;
      margin-bottom: 1.5rem;
      font-weight: 600;
    }
    .form-control {
      border-radius: 10px;
      border: 1px solid #ddd;
      padding: 0.75rem;
      margin-bottom: 1rem;
    }
    .btn-login {
      background: linear-gradient(135deg, #d83a4a, #c0392b);
      color: #fff;
      border: none;
      padding: 0.75rem;
      border-radius: 10px;
      font-weight: 500;
      width: 100%;
      transition: all 0.3s;
    }
    .btn-login:hover {
      background: linear-gradient(135deg, #c0392b, #a93226);
      transform: translateY(-2px);
    }
    .error {
      color: #dc3545;
      background: #f8d7da;
      border: 1px solid #f5c6cb;
      padding: 0.75rem;
      border-radius: 10px;
      margin-bottom: 1rem;
    }
    .register-link {
      color: #d83a4a;
      text-decoration: underline;
    }
  </style>
</head>
<body>

<div class="login-card">
  <i class="fas fa-user-lock fa-3x text-primary mb-3"></i>
  <h2>Login ke Ruang Sukma</h2>
  
  <?php if ($error): ?>
    <div class="error"><?= htmlspecialchars($error) ?></div>
  <?php endif; ?>
  
  <form method="POST" novalidate>
    <div class="mb-3">
      <input type="email" name="email" class="form-control" placeholder="Email Anda" required value="<?= htmlspecialchars($email ?? '') ?>">
    </div>
    <div class="mb-3">
      <input type="password" name="password" class="form-control" placeholder="Password" required>
    </div>
    <button type="submit" class="btn btn-login">
      <i class="fas fa-sign-in-alt me-2"></i>Login
    </button>
  </form>
  
  <p class="mt-3 mb-0">Belum punya akun? <a href="register.php" class="register-link">Daftar sekarang</a></p>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
<?php
mysqli_close($conn);
?>