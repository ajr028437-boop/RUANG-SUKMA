<?php
session_start();
include 'db.php';

// Cek login
if (!isset($_SESSION['status_login'])) {
    echo "<script>window.location='login.php'</script>";
    exit;
}

// Ambil ID dari URL
$id = $_GET['id'] ?? 0;

// Ambil data produk dulu untuk hapus file gambar
$produk = mysqli_query($conn, "SELECT product_image FROM tb_product WHERE product_id = '$id'");
if (mysqli_num_rows($produk) == 0) {
    echo "<script>alert('Data tidak ditemukan'); window.location='data-produk.php';</script>";
    exit;
}
$p = mysqli_fetch_object($produk);

// Hapus gambar dari folder jika ada
if (file_exists('./produk/' . $p->product_image) && $p->product_image != '') {
    unlink('./produk/' . $p->product_image);
}

// Hapus data produk dari database
$delete = mysqli_query($conn, "DELETE FROM tb_product WHERE product_id = '$id'");

if ($delete) {
    echo "<script>alert('Data berhasil dihapus'); window.location='data-produk.php';</script>";
} else {
    echo "<script>alert('Gagal menghapus data'); window.location='data-produk.php';</script>";
}
?>
