<?php
// checkout.php (PERBAIKI FINAL: no blank, muncul lengkap, terhubung ongkir dari detail, total include ongkir)
error_reporting(E_ALL); // Debug sementara (hapus di production)
ini_set('display_errors', 1); // Tampil error di browser jika ada

session_start();
include 'db.php';

if (!isset($_SESSION['user_login']) || !isset($_SESSION['user_id'])) {
    header("Location: login_user.php");
    exit;
}

// Inisialisasi session temp aman (hindari undefined)
if (!isset($_SESSION['temp_checkout'])) {
    $_SESSION['temp_checkout'] = ['from_detail' => false, 'ongkir' => 0, 'total_harga' => 0, 'alamat_detail' => '', 'metode_detail' => ''];
}

// Handle POST dari detail.php (checkout langsung, terhubung ongkir)
$from_detail = false;
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['product_id']) && isset($_POST['qty'])) {
    $from_detail = true;
    $product_id_detail = (int)$_POST['product_id'];
    $qty_detail = (int)$_POST['qty'];
    $alamat_detail = trim($_POST['alamat'] ?? '');
    $metode_detail = trim($_POST['metode'] ?? '');
    $ongkir_detail = (int)($_POST['ongkir'] ?? 0);
    $total_harga_detail = (int)($_POST['total_harga'] ?? 0);

    // Ambil data produk
    $query_produk = "SELECT product_id, product_name, product_price FROM tb_product WHERE product_id = ? AND product_status = 1";
    $stmt_produk = mysqli_prepare($conn, $query_produk);
    if ($stmt_produk) {
        mysqli_stmt_bind_param($stmt_produk, "i", $product_id_detail);
        mysqli_stmt_execute($stmt_produk);
        $result_produk = mysqli_stmt_get_result($stmt_produk);
        
        if (mysqli_num_rows($result_produk) > 0) {
            $produk_detail = mysqli_fetch_assoc($result_produk);
            // Tambah/update cart
            if (!isset($_SESSION['cart'][$product_id_detail])) {
                $_SESSION['cart'][$product_id_detail] = [
                    'name' => $produk_detail['product_name'],
                    'price' => $produk_detail['product_price'],
                    'qty' => 0
                ];
            }
            $_SESSION['cart'][$product_id_detail]['qty'] += $qty_detail;
            // Simpan temp untuk prefill
            $_SESSION['temp_checkout'] = [
                'from_detail' => true,
                'ongkir' => $ongkir_detail,
                'total_harga' => $total_harga_detail,
                'alamat_detail' => $alamat_detail,
                'metode_detail' => ($metode_detail == 'COD') ? 'COD' : 'Transfer'
            ];
        } else {
            $_SESSION['error'] = 'Produk tidak ditemukan.';
            header("Location: index.php");
            exit;
        }
        mysqli_stmt_close($stmt_produk);
    } else {
        error_log("Error prepare produk: " . mysqli_error($conn));
        $_SESSION['error'] = 'Error sistem. Coba lagi.';
        header("Location: index.php");
        exit;
    }
}

if (!isset($_SESSION['cart']) || count($_SESSION['cart']) == 0) {
    header("Location: cart.php");
    exit;
}

// Prefill user dari DB
$user_id = $_SESSION['user_id'];
$prefill_alamat = '';
$prefill_phone = '';
$query_user = "SELECT nama, email, no_hp, alamat, lokasi FROM tb_user WHERE id = ?";
$stmt_user = mysqli_prepare($conn, $query_user);
if ($stmt_user) {
    mysqli_stmt_bind_param($stmt_user, "i", $user_id);
    mysqli_stmt_execute($stmt_user);
    $result_user = mysqli_stmt_get_result($stmt_user);
    if (mysqli_num_rows($result_user) > 0) {
        $user_data = mysqli_fetch_assoc($result_user);
        $alamat_part = trim($user_data['alamat'] ?? '');
        $lokasi_part = trim($user_data['lokasi'] ?? '');
        $prefill_alamat = trim($alamat_part . ($alamat_part && $lokasi_part ? ', ' : '') . $lokasi_part);
        $prefill_phone = trim($user_data['no_hp'] ?? '');
    }
    mysqli_stmt_close($stmt_user);
} else {
    error_log("Error query user: " . mysqli_error($conn));
}

// Gabung prefill (prioritas: POST > detail > user > kosong)
$final_prefill_alamat = isset($_POST['alamat']) ? trim($_POST['alamat']) : ($_SESSION['temp_checkout']['alamat_detail'] ?: $prefill_alamat);
$final_prefill_phone = isset($_POST['phone']) ? trim($_POST['phone']) : $prefill_phone;
$final_prefill_payment = isset($_POST['payment_method']) ? trim($_POST['payment_method']) : $_SESSION['temp_checkout']['metode_detail'];
$final_prefill_ongkir = isset($_POST['ongkir']) ? (int)$_POST['ongkir'] : $_SESSION['temp_checkout']['ongkir'];

// Handle submit form (proses pesanan)
$error = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['alamat']) && isset($_POST['phone'])) {
    $alamat = trim($_POST['alamat']);
    $phone = trim($_POST['phone']);
    $payment_method = trim($_POST['payment_method']);
    $ongkir = (int)($_POST['ongkir'] ?? 0);
    
    if (empty($alamat) || empty($phone) || empty($payment_method) || $ongkir <= 0) {
        $error = "Lengkapi semua field dan pastikan ongkir terhitung (minimal Rp 15.000)!";
    } else {
        $subtotal = 0;
        foreach ($_SESSION['cart'] as $item) {
            $subtotal += $item['price'] * $item['qty'];
        }
        $total = $subtotal + $ongkir;
        
        mysqli_begin_transaction($conn);
        try {
            $lokasi = '';
            $query_order = "INSERT INTO tb_order (user_id, alamat, lokasi, order_date, total_amount, phone, payment_method) VALUES (?, ?, ?, NOW(), ?, ?, ?)";
            $stmt_order = mysqli_prepare($conn, $query_order);
            mysqli_stmt_bind_param($stmt_order, "isssds", $user_id, $alamat, $lokasi, $total, $phone, $payment_method);
            mysqli_stmt_execute($stmt_order);
            $order_id = mysqli_insert_id($conn);
            mysqli_stmt_close($stmt_order);
            
            foreach ($_SESSION['cart'] as $product_id => $item) {
                $qty = $item['qty'];
                $subtotal_item = $item['price'] * $qty;
                $query_detail = "INSERT INTO tb_order_detail (order_id, product_id, quantity, subtotal) VALUES (?, ?, ?, ?)";
                $stmt_detail = mysqli_prepare($conn, $query_detail);
                mysqli_stmt_bind_param($stmt_detail, "iiid", $order_id, $product_id, $qty, $subtotal_item);
                mysqli_stmt_execute($stmt_detail);
                mysqli_stmt_close($stmt_detail);
            }
            
            mysqli_commit($conn);
            unset($_SESSION['cart']);
            unset($_SESSION['temp_checkout']);
            header("Location: success.php?order_id=$order_id");
            exit;
        } catch (Exception $e) {
            mysqli_rollback($conn);
            $error = "Gagal proses pesanan: " . $e->getMessage();
            error_log("Error pesanan: " . $e->getMessage());
        }
    }
}

// Hitung subtotal
$subtotal = 0;
foreach ($_SESSION['cart'] as $item) {
    $subtotal += $item['price'] * $item['qty'];
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Ruang Sukma - Checkout</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css" rel="stylesheet">
  <style>
    body { font-family: 'Poppins', sans-serif; background: linear-gradient(135deg, #f4f6f8, #e9ecef); color: #333; line-height: 1.6; padding-top: 80px; }
    a { text-decoration: none; }
    .navbar-custom { background: rgba(216, 58, 74, 0.95) !important; backdrop-filter: blur(20px); box-shadow: 0 4px 20px rgba(216, 58, 74, 0.2); padding: 1rem 0; }
    .navbar-brand { font-weight: 700; font-size: 1.8rem; color: #fff !important; }
    .nav-link { color: #fff !important; font-weight: 500; padding: 0.5rem 1rem; }
    .nav-link:hover { color: #f8f9fa !important; }
    .cart-badge { background: #fff; color: #d83a4a; border-radius: 50%; padding: 4px 8px; font-size: 0.8rem; }
    .checkout-section { max-width: 1000px; margin: 2rem auto; padding: 0 1rem; }
    .checkout-card { background: #fff; border-radius: 20px; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.1); margin-bottom: 2rem; }
    .summary-item { display: flex; justify-content: space-between; align-items: center; padding: 0.75rem 1rem; border-bottom: 1px solid #eee; }
    .summary-name { font-weight: 500; }
    .summary-price { color: #18a74a; font-weight: 600; }
    .price-summary { background: #f8f9fa; border-radius: 15px; padding: 1.5rem; margin-top: 1rem; border: 1px solid #e9ecef; }
    .price-row { display: flex; justify-content: space-between; margin-bottom: 0.75rem; font-size: 1rem; }
    .price-label { color: #666; }
    .price-value { font-weight: 600; color: #333; }
    .total-row .price-value { color: #d83a4a; font-size: 1.3rem; font-weight: 700; }
    .ongkir-info { font-size: 0.9rem; color: #888; margin-top: 0.5rem; text-align: center; }
    .form-card { padding: 2rem; }
    .form-label { font-weight: 600; color: #d83a4a; }
    .btn-checkout { background: linear-gradient(135deg, #28a745, #218838); color: #fff; border: none; padding: 1rem 2rem; border-radius: 50px; font-weight: 600; font-size: 1.1rem; transition: all 0.3s; width: 100%; }
    .btn-checkout:hover:not(:disabled) { background: linear-gradient(135deg, #218838, #1e7e34); transform: translateY(-2px); }
    .btn-checkout:disabled { background: #6c757d; cursor: not-allowed; }
    .error { color: #dc3545; background: #f8d7da; border: 1px solid #f5c6cb; padding: 1rem; border-radius: 10px; margin-bottom: 1rem; }
    .payment-option { display: flex; align-items: center; margin-bottom: 0.5rem; }
    .payment-option input[type="radio"] { margin-right: 0.5rem; }
    .prefill-note { background: #e7f3ff; border: 1px solid #bee5eb; padding: 0.5rem; border-radius: 5px; font-size: 0.9rem; color: #0c5460; margin-top: 0.25rem; }
    .prefill-empty-note { background: #fff3cd; border: 1px solid #ffeaa7; padding: 0.5rem; border-radius: 5px; font-size: 0.9rem; color: #856404; margin-top: 0.25rem; }
    .map-box { margin-top: 1rem; border-radius: 15px; overflow: hidden; border: 2px solid #e9ecef; }
    .note { margin-top: 1.5rem; color: #666; font-size: 0.95rem; text-align: center; padding: 1rem; background: #f8f9fa; border-radius: 10px; }
    footer { background: linear-gradient(135deg, #333, #555); color: #fff; text-align: center; padding: 3rem 1rem; margin-top: 5rem; }
    .social-links a { color: #fff; font-size: 1.5rem; margin: 0 1rem; transition: color 0.3s; }
    .social-links a:hover { color: #d83a4a; }
    @media (max-width: 768px) {
      .form-card { padding: 1.5rem; }
      .summary-item { flex-direction: column; align-items: flex-start; }
      .price-row { flex-direction: column; align-items: flex-start; gap: 0.25rem; }
      .map-box iframe { height: 200px; }
      .navbar-brand { font-size: 1.5rem; }
    }
  </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-custom fixed-top">
  <div class="container">
    <a class="navbar-brand" href="index.php"><i class="fas fa-home me-2"></i>Ruang Sukma</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"><span class="navbar-toggler-icon"></span></button>
        <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link" href="index.php"><i class="fas fa-home me-1"></i>Home</a></li>
        <li class="nav-item"><a class="nav-link" href="index.php"><i class="fas fa-box me-1"></i>Produk</a></li>
        <li class="nav-item position-relative">
          <a class="nav-link" href="cart.php">
            <i class="fas fa-shopping-cart me-1"></i>Keranjang
            <?php if(isset($_SESSION['cart']) && count($_SESSION['cart']) > 0): ?>
              <span class="cart-badge"><?php echo count($_SESSION['cart']); ?></span>
            <?php endif; ?>
          </a>
        </li>
        <li class="nav-item"><span class="nav-link text-white">Halo, <?php echo htmlspecialchars($_SESSION['user_name'] ?? 'User '); ?>!</span></li>
        <li class="nav-item"><a class="nav-link" href="logout_user.php"><i class="fas fa-sign-out-alt me-1"></i>Logout</a></li>
      </ul>
    </div>
  </div>
</nav>

<!-- Checkout Section -->
<section class="checkout-section" data-aos="fade-up">
  <div class="container">
    <h2 class="text-center mb-4"><i class="fas fa-credit-card me-2"></i>Checkout Pesanan</h2>
    
    <?php if ($error): ?>
      <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <form id="checkoutForm" method="POST" onsubmit="return validateCheckoutForm();">
      <!-- Ringkasan Pesanan -->
      <div class="checkout-card">
        <h5 class="p-3 border-bottom" style="background: #f8f9fa; color: #d83a4a;"><i class="fas fa-receipt me-2"></i>Ringkasan Pesanan</h5>
        <div class="p-3">
          <?php foreach ($_SESSION['cart'] as $product_id => $item): ?>
            <div class="summary-item">
              <span class="summary-name"><?php echo htmlspecialchars($item['name']); ?> (x<?php echo $item['qty']; ?>)</span>
              <span class="summary-price">Rp <?php echo number_format($item['price'] * $item['qty'], 0, ',', '.'); ?></span>
            </div>
          <?php endforeach; ?>
          
          <!-- Price Summary (update via JS) -->
          <div class="price-summary" id="priceSummary" style="<?php echo ($final_prefill_ongkir > 0) ? '' : 'display: none;'; ?>">
            <div class="price-row">
              <span class="price-label">Subtotal Belanja:</span>
              <span class="price-value" id="subtotal">Rp <?php echo number_format($subtotal, 0, ',', '.'); ?></span>
            </div>
            <div class="price-row">
              <span class="price-label">Ongkir (dari Indihiang, Perum Taman Katumbiri):</span>
              <span class="price-value" id="ongkirDisplay">Rp <?php echo number_format($final_prefill_ongkir, 0, ',', '.'); ?></span>
            </div>
            <div class="price-row total-row">
              <span class="price-label">Total Bayar:</span>
              <span class="total-value" id="totalDisplay">Rp <?php echo number_format($subtotal + $final_prefill_ongkir, 0, ',', '.'); ?></span>
            </div>
            <div class="ongkir-info">
              <i class="fas fa-info-circle me-1"></i>Ongkir dihitung berdasarkan alamat.  Update alamat untuk hitung ulang.
            </div>
          </div>
        </div>
      </div>
      
      <!-- Form Pengiriman & Pembayaran -->
      <div class="checkout-card">
        <h5 class="p-3 border-bottom" style="background: #f8f9fa; color: #d83a4a;"><i class="fas fa-truck me-2"></i>Informasi Pengiriman & Pembayaran</h5>
        <div class="form-card">
          <div class="mb-3">
            <label class="form-label">Alamat Lengkap Pengiriman *</label>
            <textarea id="alamat" name="alamat" class="form-control" rows="3" placeholder="Masukkan alamat lengkap Anda (contoh: Kampus UNSIL, Tasikmalaya)" required><?php echo htmlspecialchars($final_prefill_alamat); ?></textarea>
            <?php if ($_SESSION['temp_checkout']['from_detail'] && !empty($_SESSION['temp_checkout']['alamat_detail'])): ?>
              <div class="prefill-note">Prefilled dari detail produk: <?php echo htmlspecialchars($_SESSION['temp_checkout']['alamat_detail']); ?> (Edit untuk update ongkir)</div>
            <?php elseif (!empty($final_prefill_alamat)): ?>
              <div class="prefill-note">Prefilled dari profil: <?php echo htmlspecialchars($final_prefill_alamat); ?> (Edit jika perlu)</div>
            <?php else: ?>
              <div class="prefill-empty-note">Alamat belum tersimpan. Isi manual untuk hitung ongkir.</div>
            <?php endif; ?>

            <!-- Map Box -->
            <div class="map-box">
              <iframe id="mapFrame" width="100%" height="260" style="border:0"
                src="https://www.google.com/maps?q=<?php echo urlencode($final_prefill_alamat ?: 'Indihiang,+Perum+Taman+Katumbiri,+Tasikmalaya'); ?>&output=embed"
                allowfullscreen="" loading="lazy"></iframe>
            </div>
          </div>

          <div class="mb-3">
            <label class="form-label">Nomor Telepon / WhatsApp *</label>
            <input type="tel" id="phone" name="phone" class="form-control" placeholder="08xxxxxxxxxx" required value="<?php echo htmlspecialchars($final_prefill_phone); ?>">
            <?php if (!empty($final_prefill_phone)): ?>
              <div class="prefill-note">Prefilled dari profil: <?php echo htmlspecialchars($final_prefill_phone); ?> (Edit jika perlu)</div>
            <?php else: ?>
              <div class="prefill-empty-note">Nomor HP belum tersimpan. Isi manual.</div>
            <?php endif; ?>
          </div>

          <div class="mb-3">
            <label class="form-label">Metode Pembayaran *</label>
            <div>
              <div class="payment-option">
                <input type="radio" name="payment_method" value="COD" id="cod" <?php echo ($final_prefill_payment == 'COD') ? 'checked' : ''; ?> required>
                <label for="cod"><i class="fas fa-truck me-2 text-success"></i>COD (Bayar di Tempat)</label>
              </div>
              <div class="payment-option">
                <input type="radio" name="payment_method" value="Transfer" id="transfer" <?php echo ($final_prefill_payment == 'Transfer') ? 'checked' : ''; ?> required>
                <label for="transfer"><i class="fas fa-bank me-2 text-primary"></i>Transfer Bank / E-Wallet (DANA/OVO/ShopeePay)</label>
              </div>
              <small class="text-muted d-block mt-2">Untuk transfer/e-wallet, konfirmasi via WhatsApp setelah pembayaran. Rekening: BCA 1234567890 a.n. Ruang Sukma.</small>
            </div>
          </div>

          <!-- Hidden inputs -->
          <input type="hidden" name="ongkir" id="ongkir" value="<?php echo $final_prefill_ongkir; ?>" />
          <input type="hidden" name="total_harga" id="total_harga" value="<?php echo $subtotal + $final_prefill_ongkir; ?>" />

          <button type="submit" class="btn btn-checkout" id="btnCheckout" <?php echo ($final_prefill_ongkir <= 0) ? 'disabled' : ''; ?>>
            <i class="fas fa-check me-2"></i>Konfirmasi Pesanan & Bayar (Rp <span id="totalBtn"><?php echo number_format($subtotal + $final_prefill_ongkir, 0, ',', '.'); ?></span>)
          </button>

          <div class="note" id="noteMsg">
            <i class="fas fa-info-circle me-2"></i>Lengkapi alamat untuk hitung ongkir dan konfirmasi pesanan.
          </div>
        </div>
      </div>
      
      <div class="text-center mb-4">
        <a href="cart.php" class="btn btn-secondary"><i class="fas fa-arrow-left me-2"></i>Kembali ke Keranjang</a>
        <a href="index.php" class="btn btn-outline-secondary ms-2"><i class="fas fa-home me-2"></i>Kembali ke Beranda</a>
      </div>
    </form>
  </div>
</section>

<!-- Footer -->
<footer class="text-center py-5" data-aos="fade-up">
  <div class="container">
    <div class="row">
      <div class="col-md-6">
        <h5 class="text-white mb-3">Ruang Sukma</h5>
        <p class="text-light">Toko online terpercaya untuk kebutuhan rumah tangga dan kantor. Kualitas terbaik, harga terjangkau.</p>
      </div>
      <div class="col-md-6">
        <h5 class="text-white mb-3">Hubungi Kami</h5>
        <p class="text-light">Email: info@ruangsukma.com | Telp: (021) 123-4567</p>
        <div class="social-links">
          <a href="#"><i class="fab fa-facebook-f"></i></a>
          <a href="#"><i class="fab fa-instagram"></i></a>
          <a href="#"><i class="fab fa-twitter"></i></a>
          <a href="#"><i class="fab fa-whatsapp"></i></a>
        </div>
      </div>
    </div>
    <hr class="my-4 border-light">
    <p class="text-light mb-0">&copy; 2024 Ruang Sukma. All rights reserved. | <a href="tentang.php" class="text-light">Tentang Kami</a></p>
  </div>
</footer>

<!-- Scripts -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
<script>
  AOS.init({ duration: 1000, once: true, offset: 100 });

  // Variabel (cek null untuk no error)
  const subtotalFixed = <?php echo $subtotal; ?>;
  const alamatEl = document.getElementById('alamat');
  const mapFrame = document.getElementById('mapFrame');
  const btnCheckout = document.getElementById('btnCheckout');
  const noteMsg = document.getElementById('noteMsg');
  const priceSummary = document.getElementById('priceSummary');
  const subtotalEl = document.getElementById('subtotal');
  const ongkirEl = document.getElementById('ongkirDisplay');
  const totalEl = document.getElementById('totalDisplay');
  const totalBtn = document.getElementById('totalBtn');
  const ongkirHidden = document.getElementById('ongkir');
  const totalHidden = document.getElementById('total_harga');
  const phoneEl = document.getElementById('phone');

  if (!alamatEl || !btnCheckout) {
    console.warn('Elemen form tidak ditemukan. Cek HTML.');
  }

  let mapTimer = null;

  // Fungsi hitung ongkir (sama seperti detail.php)
  function hitungOngkir(alamat) {
    if (!alamat || alamat.trim().length < 10) return 0;
    const lowerAlamat = alamat.toLowerCase();
    
    if (lowerAlamat.includes('tasik') || lowerAlamat.includes('unsil') || lowerAlamat.includes('katumbiri') || lowerAlamat.includes('indihiang')) {
      return 15000;
    } else if (lowerAlamat.includes('bandung') || lowerAlamat.includes('cirebon') || lowerAlamat.includes('garut')) {
      return 30000;
    } else if (lowerAlamat.includes('jakarta') || lowerAlamat.includes('bekasi') || lowerAlamat.includes('bogor')) {
      return 50000;
    } else {
      return 20000;
    }
  }

  // Fungsi update harga
  function updateHarga() {
    const alamat = alamatEl ? alamatEl.value.trim() : '';
    const ongkir = hitungOngkir(alamat);
    const total = subtotalFixed + ongkir;

    if (subtotalEl) subtotalEl.textContent = 'Rp ' + subtotalFixed.toLocaleString('id-ID');
    if (ongkirEl) ongkirEl.textContent = 'Rp ' + ongkir.toLocaleString('id-ID');
    if (totalEl) totalEl.textContent = 'Rp ' + total.toLocaleString('id-ID');
    if (totalBtn) totalBtn.textContent = total.toLocaleString('id-ID');

    if (ongkirHidden) ongkirHidden.value = ongkir;
    if (totalHidden) totalHidden.value = total;

    if (priceSummary) {
      if (alamat.length >= 10 && ongkir > 0) {
        priceSummary.style.display = 'block';
      } else {
        priceSummary.style.display = 'none';
      }
    }

    validateCheckoutForm();
  }

  // Event listener alamat
  if (alamatEl) {
    alamatEl.addEventListener('input', function() {
      if (mapTimer) clearTimeout(mapTimer);
      mapTimer = setTimeout(() => {
        const val = alamatEl.value.trim();
        if (mapFrame && val.length > 0) {
          mapFrame.src = "https://www.google.com/maps?q=" + encodeURIComponent(val) + "&output=embed";
        } else if (mapFrame) {
          mapFrame.src = "https://www.google.com/maps?q=Indihiang,+Perum+Taman+Katumbiri,+Tasikmalaya&output=embed";
        }
        updateHarga();
      }, 600);
    });
  }

  // Event listener phone dan payment
  if (phoneEl) {
    phoneEl.addEventListener('input', validateCheckoutForm);
  }
  document.querySelectorAll('input[name="payment_method"]').forEach(radio => {
    if (radio) radio.addEventListener('change', validateCheckoutForm);
  });

  // Fungsi validate lengkap
  function validateCheckoutForm() {
    if (!alamatEl || !phoneEl || !btnCheckout || !noteMsg) {
      console.warn('Elemen validasi tidak lengkap.');
      return false;
    }

    const alamat = alamatEl.value.trim();
    const phone = phoneEl.value.trim();
    const paymentMethod = document.querySelector('input[name="payment_method"]:checked');
    const ongkir = parseInt(ongkirHidden ? ongkirHidden.value : '0') || 0;

    const isValidAlamat = alamat.length > 10;
    const isValidPhone = phone.length >= 10;
    const isValidPayment = !!paymentMethod;
    const isValidOngkir = ongkir > 0;

    console.log('Validasi:', { alamat: isValidAlamat, phone: isValidPhone, payment: isValidPayment, ongkir: isValidOngkir, ongkirValue: ongkir });

    if (isValidAlamat && isValidPhone && isValidPayment && isValidOngkir) {
      btnCheckout.disabled = false;
      noteMsg.innerHTML = '<i class="fas fa-check-circle text-success me-2"></i>Form valid! Total: Rp ' + parseInt(totalHidden ? totalHidden.value : '0').toLocaleString('id-ID') + '. Siap konfirmasi.';
      return true;
    } else {
      btnCheckout.disabled = true;
      let errorMsg = '<i class="fas fa-exclamation-triangle me-2"></i>';
      if (!isValidAlamat) errorMsg += 'Alamat minimal 10 karakter (untuk ongkir). ';
      if (!isValidPhone) errorMsg += 'Nomor HP minimal 10 digit. ';
      if (!isValidPayment) errorMsg += 'Pilih metode pembayaran. ';
      if (!isValidOngkir) errorMsg += 'Lengkapi alamat untuk hitung ongkir (minimal Rp 15.000). ';
      noteMsg.innerHTML = errorMsg + 'Lengkapi data sebelum konfirmasi.';
      return false;
    }
  }

  // Inisialisasi saat load
  document.addEventListener('DOMContentLoaded', function() {
    updateHarga();
    validateCheckoutForm(); // Validasi awal
    console.log('Checkout loaded. Subtotal: Rp ' + subtotalFixed.toLocaleString('id-ID'));
  });
</script>

</body>
</html>
<?php
mysqli_close($conn);
?>