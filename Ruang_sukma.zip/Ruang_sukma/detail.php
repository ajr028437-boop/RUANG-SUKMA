<?php
// detail.php
session_start();
include 'db.php';

// Inisialisasi cart jika belum ada (struktur array kosong untuk konsistensi dengan cart.php)
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Hitung jumlah item cart untuk badge navbar
$cart_count = isset($_SESSION['cart']) ? count($_SESSION['cart']) : 0;

// Ambil ID produk
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id <= 0) {
    header("Location: index.php");
    exit;
}

// Ambil data produk
$produk_q = mysqli_query($conn, "SELECT * FROM tb_product WHERE product_id = {$id}");
if (!$produk_q || mysqli_num_rows($produk_q) == 0) {
    echo "Produk tidak ditemukan";
    exit;
}
$p = mysqli_fetch_assoc($produk_q);

// Data user (ambil dari tb_user jika login)
$user_nama  = '';
$user_email = '';
$user_hp    = '';
$user_id    = '';

if (isset($_SESSION['user_id'])) {
    $uid = (int)$_SESSION['user_id'];
    $user_q = mysqli_query($conn, "SELECT * FROM tb_user WHERE id = {$uid} LIMIT 1");
    if ($user_q && mysqli_num_rows($user_q) > 0) {
        $u = mysqli_fetch_assoc($user_q);
        $user_id    = $u['id'];
        $user_nama  = $u['nama'] ?? 'User ';
        $user_email = $u['email'];
        $user_hp    = $u['no_hp'];
    }
}

// Nomor admin WA
$wa_admin   = "6283120987582";

// Query untuk featured (3 random) - mirip index untuk sidebar
$featured_query = mysqli_query($conn, "SELECT * FROM tb_product WHERE product_status = 1 ORDER BY RAND() LIMIT 3");
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Detail Produk - <?php echo htmlspecialchars($p['product_name']); ?> - Ruang Sukma</title>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <!-- Google Fonts: Poppins -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet" />
  <!-- Font Awesome Icons -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
  <!-- AOS Animations -->
  <link href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css" rel="stylesheet" />
  <style>
    /* (Sama seperti style sebelumnya, termasuk .price-summary yang sudah ditambah) */
    body {
      font-family: 'Poppins', sans-serif;
      background: linear-gradient(135deg, #f4f6f8, #e9ecef);
      color: #333;
      line-height: 1.6;
      padding-top: 80px;
    }
    a { text-decoration: none; }
    .navbar-custom {
      background: rgba(216, 58, 74, 0.95) !important;
      backdrop-filter: blur(20px);
      box-shadow: 0 4px 20px rgba(216, 58, 74, 0.2);
      padding: 1rem 0;
    }
    .navbar-brand {
      font-weight: 700; font-size: 1.8rem; color: #fff !important;
    }
    .nav-link { color: #fff !important; font-weight: 500; padding: 0.5rem 1rem; }
    .nav-link:hover { color: #f8f9fa !important; }
    .cart-badge { background: #fff; color: #d83a4a; border-radius: 50%; padding: 4px 8px; font-size: 0.8rem; }
    .detail-hero {
      height: 30vh; overflow: hidden; margin-bottom: 2rem;
      background: linear-gradient(135deg, #d83a4a, #c0392b);
      position: relative;
    }
    @media (max-width: 768px) { .detail-hero { height: 25vh; } }
    .hero-overlay {
      position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);
      text-align: center; color: #fff; z-index: 10; line-height: 1.4;
      padding: 0 1rem;
    }
    .hero-overlay h1 {
      font-size: 2.5rem; font-weight: 700; text-shadow: 2px 2px 8px rgba(0,0,0,0.5);
      margin-bottom: 0.5rem;
    }
    @media (max-width: 768px) { .hero-overlay h1 { font-size: 1.8rem; } }
    .hero-overlay p { font-size: 1.1rem; margin-bottom: 1.5rem; }
    .hero-btn {
      background: rgba(255, 255, 255, 0.9); color: #d83a4a; border: none;
      padding: 0.75rem 1.5rem; border-radius: 50px; font-weight: 600; font-size: 1rem;
      transition: all 0.3s;
    }
    .hero-btn:hover { background: #fff; color: #d83a4a; transform: translateY(-2px); }
    .detail-section { max-width: 1100px; margin: 0 auto 3rem; padding: 0 1rem; }
    .product-detail-card {
      background: #fff; border-radius: 20px; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.1);
      transition: all 0.4s ease;
    }
    .product-detail-card:hover { transform: translateY(-5px); box-shadow: 0 15px 40px rgba(0,0,0,0.15); }
    .detail-img {
      width: 100%; height: 400px; object-fit: contain;
      background: #f8f9fa; display: flex; align-items: center; justify-content: center;
    }
    @media (max-width: 768px) { .detail-img { height: 300px; } }
    .detail-body { padding: 2rem; }
    .product-name { font-size: 2rem; font-weight: 700; color: #333; margin-bottom: 1rem; }
    .product-price { color: #18a74a; font-weight: 700; font-size: 1.8rem; margin-bottom: 1.5rem; }
    .product-desc { color: #666; font-size: 1rem; margin-bottom: 2rem; line-height: 1.7; }
    label { display: block; font-weight: 600; margin-top: 1.5rem; margin-bottom: 0.75rem; color: #333; font-size: 1rem; }
    input[type="number"], textarea {
      width: 100%; padding: 1rem; border: 2px solid #e9ecef; border-radius: 10px; font-size: 1rem;
      box-sizing: border-box; transition: border-color 0.3s; font-family: 'Poppins', sans-serif;
    }
    input[type="number"]:focus, textarea:focus { border-color: #d83a4a; outline: none; }
    .map-box { margin-top: 1rem; border-radius: 15px; overflow: hidden; border: 2px solid #e9ecef; }
    .pay-options { display: flex; gap: 1rem; flex-wrap: wrap; margin-top: 1rem; }
    .pay-options button {
      background: #f8f9fa; border: 2px solid #e9ecef; padding: 0.75rem 1.5rem; border-radius: 25px;
      cursor: pointer; font-weight: 500; transition: all 0.3s; font-family: 'Poppins', sans-serif;
    }
    .pay-options button:hover, .pay-options button.active {
      background: #d83a4a; color: #fff; border-color: #d83a4a; transform: translateY(-2px);
    }
    .btn-detail {
      background: linear-gradient(135deg, #007bff, #0056b3); color: #fff; border: none;
      padding: 1rem 2rem; border-radius: 50px; font-weight: 600; font-size: 1.1rem;
      transition: all 0.3s; margin-right: 1rem;
    }
    .btn-detail:hover { background: linear-gradient(135deg, #0056b3, #004085); transform: scale(1.05); }
    .note {
      margin-top: 1.5rem; color: #666; font-size: 0.95rem; text-align: center; padding: 1rem; background: #f8f9fa; border-radius: 10px;
    }
    /* Style untuk ringkasan harga (subtotal, ongkir, total) */
    .price-summary {
      background: #f8f9fa; border-radius: 15px; padding: 1.5rem; margin-top: 2rem; border: 1px solid #e9ecef;
    }
    .price-row {
      display: flex; justify-content: space-between; margin-bottom: 0.75rem; font-size: 1rem;
    }
    .price-label { color: #666; }
    .price-value { font-weight: 600; color: #333; }
    .total-row { border-top: 2px solid #d83a4a; padding-top: 1rem; margin-top: 1rem; }
    .total-value { color: #d83a4a; font-size: 1.3rem; font-weight: 700; }
    .ongkir-info { font-size: 0.9rem; color: #888; margin-top: 0.5rem; text-align: center; }
    .sidebar { background: #fff; border-radius: 15px; padding: 1.5rem; box-shadow: 0 5px 20px rgba(0,0,0,0.1); height: fit-content; position: sticky; top: 100px; }
    .sidebar h5 { color: #d83a4a; border-bottom: 2px solid #d83a4a; padding-bottom: 0.5rem; margin-bottom: 1rem; font-weight: 600; }
    .sidebar-product { display: flex; gap: 1rem; margin-bottom: 1rem; padding-bottom: 1rem; border-bottom: 1px solid #eee; align-items: center; }
    .sidebar-img {
      width: 70px; height: 70px; object-fit: contain; border-radius: 10px; flex-shrink: 0;
      background: #f8f9fa; display: flex; align-items: center; justify-content: center;
    }
    .sidebar-name { font-size: 1rem; font-weight: 500; margin-bottom: 0.25rem; }
    .sidebar-price { color: #18a74a; font-weight: 600; font-size: 1rem; }
    .btn-sidebar { background: linear-gradient(135deg, #007bff, #0056b3); color: #fff; border: none; padding: 0.5rem 1rem; border-radius: 25px; font-weight: 500; font-size: 0.9rem; }
    .btn-sidebar:hover { background: linear-gradient(135deg, #0056b3, #004085); }
    footer { background: linear-gradient(135deg, #333, #555); color: #fff; text-align: center; padding: 3rem 1rem; margin-top: 5rem; }
    .social-links a { color: #fff; font-size: 1.5rem; margin: 0 1rem; transition: color 0.3s; }
    .social-links a:hover { color: #d83a4a; }
    @media (max-width: 992px) { .sidebar { position: static; margin-top: 2rem; } }
    @media (max-width: 768px) {
      .detail-body { padding: 1.5rem; }
      .pay-options { justify-content: center; }
      .btn-detail { width: 100%; margin-bottom: 1rem; margin-right: 0; }
      .price-summary { margin-top: 1rem; }
    }
  </style>
</head>
<body>

<!-- Navbar Bootstrap Modern -->
<nav class="navbar navbar-expand-lg navbar-custom fixed-top">
  <div class="container">
    <a class="navbar-brand" href="index.php">
      <i class="fas fa-home me-2"></i>Ruang Sukma
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link" href="index.php"><i class="fas fa-home me-1"></i>Home</a></li>
        <li class="nav-item"><a class="nav-link active" href="index.php"><i class="fas fa-box me-1"></i>Produk</a></li>
        <li class="nav-item position-relative">
          <a class="nav-link" href="cart.php">
            <i class="fas fa-shopping-cart me-1"></i>Keranjang
            <?php if ($cart_count > 0): ?>
              <span class="cart-badge"><?php echo $cart_count; ?></span>
            <?php endif; ?>
          </a>
        </li>
        <li class="nav-item"><span class="nav-link text-white">Halo, <?php echo htmlspecialchars($user_nama); ?>!</span></li>
        <li class="nav-item"><a class="nav-link" href="logout_user.php"><i class="fas fa-sign-out-alt me-1"></i>Logout</a></li>
      </ul>
    </div>
  </div>
</nav>

<!-- Hero Sederhana untuk Detail -->
<section class="detail-hero">
  <div class="hero-overlay">
    <h1>Detail Produk</h1>
    <p><?php echo htmlspecialchars($p['product_name']); ?></p>
    <a href="index.php" class="hero-btn"><i class="fas fa-arrow-left me-2"></i>Kembali ke Beranda</a>
  </div>
</section>

<!-- Detail Section Modern (Grid + Sidebar) -->
<section class="detail-section" data-aos="fade-up">
  <div class="row">
    <!-- Main Detail (9 kolom desktop) -->
    <div class="col-lg-9">
      <div class="product-detail-card h-100">
        <div class="row g-0">
          <div class="col-md-5">
            <img src="produk/<?php echo htmlspecialchars($p['product_image'] ?? 'default.jpg'); ?>" alt="<?php echo htmlspecialchars($p['product_name']); ?>" class="detail-img" onerror="this.src='https://via.placeholder.com/400x400/d83a4a/ffffff?text=No+Image'">
          </div>
          <div class="col-md-7">
            <div class="detail-body">
              <h1 class="product-name"><?php echo htmlspecialchars($p['product_name']); ?></h1>
              <div class="              <div class="product-price">Rp <?php echo number_format($p['product_price'], 0, ',', '.'); ?></div>
              <div class="product-desc"><?php echo nl2br(htmlspecialchars($p['product_description'] ?? 'Deskripsi produk akan ditampilkan di sini.')); ?></div>

              <form id="orderForm" action="checkout.php" method="POST" onsubmit="return validateForm();">
                <label for="qty">Jumlah:</label>
                <input type="number" id="qty" name="qty" value="1" min="1" required />

                <label for="alamat">Lokasi Pengiriman:</label>
                <textarea id="alamat" name="alamat" rows="3" placeholder="Masukkan alamat lengkap" required></textarea>

                <div class="map-box">
                  <iframe id="mapFrame" width="100%" height="260" style="border:0"
                    src="https://www.google.com/maps?q=Indonesia&output=embed"
                    allowfullscreen="" loading="lazy"></iframe>
                </div>

                <label>Metode Pembayaran:</label>
                <div class="pay-options">
                  <button type="button" onclick="selectMethod('DANA', 'https://link.dana.id', this)" class="pay-btn">DANA</button>
                  <button type="button" onclick="selectMethod('OVO', 'https://www.ovo.id', this)" class="pay-btn">OVO</button>
                  <button type="button" onclick="selectMethod('ShopeePay', 'https://shopeepay.co.id', this)" class="pay-btn">ShopeePay</button>
                  <button type="button" onclick="selectMethod('COD', '', this)" class="pay-btn">COD</button>
                </div>
                <input type="hidden" id="metode" name="metode" value="" />

                <input type="hidden" name="product_id" value="<?php echo $p['product_id']; ?>" />
                <!-- MODIFIKASI ONGKI: Hidden inputs untuk ongkir dan total -->
                <input type="hidden" name="ongkir" id="ongkir" value="0" />
                <input type="hidden" name="total_harga" id="total_harga" value="0" />

                <div style="margin-top: 2rem;">
                  <button class="btn-detail" type="button" onclick="addToCart(<?php echo $p['product_id']; ?>)">
                    <i class="fas fa-shopping-cart me-2"></i>+ Tambah ke Keranjang
                  </button>
                  <button class="btn-detail" id="btnCheckout" type="submit" disabled>
                    <i class="fas fa-credit-card me-2"></i>Checkout
                  </button>
                </div>

                <!-- MODIFIKASI ONGKI: Ringkasan Harga (Subtotal + Ongkir + Total) -->
                <div class="price-summary" id="priceSummary" style="display: none;">
                  <div class="price-row">
                    <span class="price-label">Subtotal (Rp <?php echo number_format($p['product_price'], 0, ',', '.'); ?> × Jumlah):</span>
                    <span class="price-value" id="subtotal">Rp 0</span>
                  </div>
                  <div class="price-row">
                    <span class="price-label">Ongkir (dari Indihiang, Perum Taman Katumbiri):</span>
                    <span class="price-value" id="ongkirDisplay">Rp 0</span>
                  </div>
                  <div class="price-row total-row">
                    <span class="price-label">Total Bayar:</span>
                    <span class="total-value" id="totalDisplay">Rp 0</span>
                  </div>
                  <div class="ongkir-info">
                    <i class="fas fa-info-circle me-1"></i>Ongkir dihitung berdasarkan alamat.
                  </div>
                </div>

                <div class="note" id="noteMsg">
                  <i class="fas fa-info-circle me-2"></i>Pilih metode pembayaran dan lengkapi data sebelum checkout.
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Sidebar Featured (3 kolom desktop) - Dengan fallback null -->
    <div class="col-lg-3 sidebar">
      <h5><i class="fas fa-star me-2"></i>Produk Unggulan</h5>
      <?php
      if ($featured_query && mysqli_num_rows($featured_query) > 0) {
          mysqli_data_seek($featured_query, 0); // Reset pointer
          while ($feat = mysqli_fetch_assoc($featured_query)) {
              $feat_name = $feat['product_name'] ?? 'Produk Unggulan';
              $short_name = strlen($feat_name) > 30 ? substr($feat_name, 0, 30) . '...' : $feat_name;
              $feat_price = (float)($feat['product_price'] ?? 0);
              echo '<div class="sidebar-product">
                      <img src="produk/' . htmlspecialchars($feat['product_image'] ?? 'default.jpg') . '" alt="' . htmlspecialchars($feat_name) . '" class="sidebar-img" onerror="this.src=\'https://via.placeholder.com/70x70/d83a4a/ffffff?text=P\'">
                      <div>
                        <div class="sidebar-name">' . htmlspecialchars($short_name) . '</div>
                        <div class="sidebar-price">Rp ' . number_format($feat_price, 0, ',', '.') . '</div>
                        <a href="detail.php?id=' . ($feat['product_id'] ?? 0) . '" class="btn btn-sm btn-sidebar mt-1">Lihat</a>
                      </div>
                    </div>';
          }
      } else {
          echo '<p class="text-muted">Tidak ada produk unggulan saat ini.</p>';
      }
      ?>
    </div>
  </div>
</section>

<!-- Footer Modern -->
<footer class="text-center py-5" data-aos="fade-up">
  <div class="container">
    <div class="row">
      <div class="col-md-6">
        <h5 class="text-white mb-3">Ruang Sukma</h5>
        <p class="text-light">Toko online terpercaya untuk kebutuhan rumah tangga dan kantor. Kualitas terbaik, harga terjangkau.</p>
      </div>
      <div class="col-md-6">
        <h5 class="text-white mb-3">Hubungi Kami</h5>
        <p class="text-light">Email: info@ruangsukma.com | Telp: (021) 123-4567</p>
        <div class="social-links">
          <a href="#"><i class="fab fa-facebook-f"></i></a>
          <a href="#"><i class="fab fa-instagram"></i></a>
          <a href="#"><i class="fab fa-twitter"></i></a>
          <a href="#"><i class="fab fa-whatsapp"></i></a>
        </div>
      </div>
    </div>
    <hr class="my-4 border-light">
    <p class="text-light mb-0">&copy; 2024 Ruang Sukma. All rights reserved. | <a href="tentang.php" class="text-light">Tentang Kami</a></p>
  </div>
</footer>

<!-- Scripts Modern -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
<script>
  AOS.init({ duration: 1000, once: true, offset: 100 });

  // MODIFIKASI ONGKI: Variabel global untuk harga produk (dari PHP)
  const productPrice = <?php echo $p['product_price']; ?>;
  const alamatEl = document.getElementById('alamat');
  const mapFrame = document.getElementById('mapFrame');
  const metodeEl = document.getElementById('metode');
  const btnCheckout = document.getElementById('btnCheckout');
  const qtyEl = document.getElementById('qty');
  const noteMsg = document.getElementById('noteMsg');
  const priceSummary = document.getElementById('priceSummary');
  const subtotalEl = document.getElementById('subtotal');
  const ongkirEl = document.getElementById('ongkirDisplay');
  const totalEl = document.getElementById('totalDisplay');
  const ongkirHidden = document.getElementById('ongkir');
  const totalHidden = document.getElementById('total_harga');

  let mapTimer = null;

  // MODIFIKASI ONGKI: Fungsi hitung ongkir berdasarkan alamat (rate lebih tinggi, minimal 15k)
  function hitungOngkir(alamat) {
    if (!alamat || alamat.trim().length < 10) return 0; // Belum valid, ongkir 0
    const lowerAlamat = alamat.toLowerCase();
    
    if (lowerAlamat.includes('tasik') || lowerAlamat.includes('unsil') || lowerAlamat.includes('katumbiri') || lowerAlamat.includes('indihiang')) {
      return 15000; // Dekat: Tasikmalaya/UNSIL (15k)
    } else if (lowerAlamat.includes('bandung') || lowerAlamat.includes('cirebon') || lowerAlamat.includes('garut')) {
      return 30000; // Sedang: Kota sekitar (30k)
    } else if (lowerAlamat.includes('jakarta') || lowerAlamat.includes('bekasi') || lowerAlamat.includes('bogor')) {
      return 50000; // Jauh: Jakarta & sekitar (50k)
    } else {
      return 20000; // Default: Lainnya (20k)
    }
  }

  // Fungsi update harga (dipanggil saat qty atau alamat berubah)
  function updateHarga() {
    const qty = parseInt(qtyEl.value) || 1;
    const alamat = alamatEl.value.trim();
    const ongkir = hitungOngkir(alamat);
    const subtotal = productPrice * qty;
    const total = subtotal + ongkir;

    // Update tampilan
    subtotalEl.textContent = 'Rp ' + subtotal.toLocaleString('id-ID');
    ongkirEl.textContent = 'Rp ' + ongkir.toLocaleString('id-ID');
    totalEl.textContent = 'Rp ' + total.toLocaleString('id-ID');

    // Update hidden inputs
    ongkirHidden.value = ongkir;
    totalHidden.value = total;

    // Tampilkan/sembunyikan summary jika alamat valid
    if (alamat.length >= 10 && ongkir > 0) {
      priceSummary.style.display = 'block';
    } else {
      priceSummary.style.display = 'none';
    }
  }

  alamatEl.addEventListener('input', function(){
    if (mapTimer) clearTimeout(mapTimer);
    mapTimer = setTimeout(function(){
      const val = alamatEl.value.trim();
      if (val.length > 0) {
        mapFrame.src = "https://www.google.com/maps?q=" + encodeURIComponent(val) + "&output=embed";
      } else {
        mapFrame.src = "https://www.google.com/maps?q=Indihiang,+Perum+Taman+Katumbiri,+Tasikmalaya&output=embed"; // Default ke lokasi toko
      }
      updateHarga(); // MODIFIKASI: Update ongkir dan harga
      validateForm();
    }, 600);
  });

  qtyEl.addEventListener('input', function() {
    if (this.value < 1) this.value = 1; // Validasi minimal 1
    updateHarga(); // MODIFIKASI: Update subtotal dan total
    validateForm();
  });

  // Fungsi selectMethod (tidak diubah)
  function selectMethod(m, url, btn) {
    metodeEl.value = m;
    document.querySelectorAll('.pay-btn').forEach(b => b.classList.remove('active'));
    if (btn) btn.classList.add('active');
    if (url && url !== '') window.open(url, '_blank');
    validateForm();
  }

  // MODIFIKASI ONGKI: validateForm yang diperkuat (tambah validasi ongkir > 0)
  function validateForm() {
    const qty = parseInt(qtyEl.value) || 0;
    const alamat = alamatEl.value.trim();
    const metode = metodeEl.value.trim();
    const ongkir = parseInt(ongkirHidden.value) || 0;

    const isValidQty = qty >= 1;
    const isValidAlamat = alamat.length > 10; // Minimal 10 char
    const isValidMetode = metode.length > 0;
    const isValidOngkir = ongkir > 0; // Ongkir harus terhitung

    console.log('Validasi Debug:', { qty: isValidQty, alamat: isValidAlamat, metode: isValidMetode, ongkir: isValidOngkir });

    if (isValidQty && isValidAlamat && isValidMetode && isValidOngkir) {
      btnCheckout.disabled = false;
      noteMsg.innerHTML = '<i class="fas fa-check-circle text-success me-2"></i>Form valid! Total: Rp ' + parseInt(totalHidden.value).toLocaleString('id-ID');
      console.log('Form valid, siap submit ke checkout.php');
      return true;
    } else {
      btnCheckout.disabled = true;
      let errorMsg = '<i class="fas fa-exclamation-triangle me-2"></i>';
      if (!isValidQty) errorMsg += 'Jumlah harus >= 1. ';
      if (!isValidAlamat) errorMsg += 'Alamat minimal 10 karakter (untuk hitung ongkir). ';
      if (!isValidMetode) errorMsg += 'Pilih metode pembayaran. ';
      if (!isValidOngkir) errorMsg += 'Lengkapi alamat untuk hitung ongkir (minimal Rp 15.000). ';
      noteMsg.innerHTML = errorMsg + 'Lengkapi data sebelum checkout.';
      console.log('Form invalid, disable checkout');
      return false;
    }
  }

  // Fungsi addToCart (diperbaiki: tambah check sesi dan lebih detail error)
  function addToCart(productId) {
    const qty = parseInt(document.getElementById('qty').value) || 1;
    console.log('Debug: Mulai tambah cart. ID:', productId, 'Qty:', qty);

    fetch('tambah_cart.php', {
      method: 'POST',
      headers: {'Content-Type': 'application/x-www-form-urlencoded'},
      body: 'id=' + encodeURIComponent(productId) + '&qty=' + encodeURIComponent(qty)
    })
    .then(response => {
      console.log('Debug: Response status:', response.status);
      if (!response.ok) {
        throw new Error('HTTP error! Status: ' + response.status);
      }
      return response.text();
    })
    .then(txt => {
      console.log('Debug: Response text:', txt);
      if (txt.trim() === 'sukses') {
        alert('Produk ditambahkan ke keranjang!');
        // Update badge cart di navbar tanpa reload penuh (opsional)
        const badge = document.querySelector('.cart-badge');
        if (badge) {
          let currentCount = parseInt(badge.textContent) || 0;
          badge.textContent = currentCount + 1;
          badge.style.display = 'inline-block';
        }
        // Atau reload untuk simplicity: location.reload();
        // Atau redirect: setTimeout(() => { window.location.href = 'cart.php'; }, 1000);
      } else {
        alert('Gagal menambah: ' + txt);
        console.error('Debug: Gagal tambah cart. Response:', txt);
      }
    })
    .catch(err => {
      console.error('Debug: Fetch error:', err);
      alert('Gagal menambah ke keranjang: ' + err.message + '. Pastikan file tambah_cart.php ada dan koneksi DB OK.');
    });
  }

  // Inisialisasi saat load halaman
  document.addEventListener('DOMContentLoaded', function() {
    updateHarga(); // MODIFIKASI: Inisialisasi harga awal
    validateForm();
  });
</script>

</body>
</html>
<?php
// Tutup koneksi DB
mysqli_close($conn);
?>