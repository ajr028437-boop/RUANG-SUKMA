<?php
// cart.php
session_start();
include 'db.php';

// Inisialisasi cart jika belum ada (struktur sub-array)
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// FIX: Konversi otomatis jika struktur lama (sederhana array) ke sub-array
foreach ($_SESSION['cart'] as $id => $value) {
    if (is_int($value) || is_numeric($value)) { // Struktur lama: $id => qty
        $_SESSION['cart'][$id] = ['qty' => (int)$value];
    }
}

// Handle POST: Update qty atau hapus item
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'] ?? '';
    $product_id = (int)($_POST['product_id'] ?? 0);

    if ($action == 'update') {
        $qty = (int)($_POST['qty'] ?? 1);
        if ($qty > 0 && isset($_SESSION['cart'][$product_id])) {
            $_SESSION['cart'][$product_id]['qty'] = $qty;
        } else {
            unset($_SESSION['cart'][$product_id]); // Hapus jika qty 0 atau invalid
        }
    } elseif ($action == 'delete') {
        unset($_SESSION['cart'][$product_id]);
    }
    header("Location: cart.php"); // Redirect untuk refresh halaman
    exit;
}

// Ambil data user jika login
$user_id = 0;
$user_nama = '';
if (isset($_SESSION['user_id'])) {
    $user_id = (int)$_SESSION['user_id'];
    $user_q = mysqli_query($conn, "SELECT * FROM tb_user WHERE id = {$user_id} LIMIT 1");
    if ($user_q && mysqli_num_rows($user_q) > 0) {
        $u = mysqli_fetch_assoc($user_q);
        $user_nama = $u['nama'] ?? 'User  ';
    }
}

// Hitung jumlah item untuk badge (jumlah key unik di cart)
$cart_count = count($_SESSION['cart']);

// Ambil detail produk di cart dari DB (hanya yang status=1)
$cart_items = [];
$total = 0;
if (!empty($_SESSION['cart'])) {
    $ids = array_keys($_SESSION['cart']);
    if (!empty($ids)) {
        $ids_str = implode(',', array_map('intval', $ids)); // Sanitize IDs
        $cart_query = mysqli_query($conn, "SELECT * FROM tb_product WHERE product_id IN ({$ids_str}) AND product_status = 1");
        if ($cart_query) { // Cek query sukses
            while ($item = mysqli_fetch_assoc($cart_query)) {
                if (isset($_SESSION['cart'][$item['product_id']])) {
                    $qty_data = $_SESSION['cart'][$item['product_id']];
                    $qty = (int)($qty_data['qty'] ?? 0); // Fallback jika 'qty' null
                    if ($qty > 0) { // Skip jika qty 0
                        $price = (float)($item['product_price'] ?? 0);
                        $subtotal = $price * $qty;
                        $item['qty'] = $qty;
                        $item['subtotal'] = $subtotal;
                        $cart_items[] = $item;
                        $total += $subtotal;
                    }
                }
            }
        } else {
            // Optional: Log error jika query gagal
            error_log("Cart query failed: " . mysqli_error($conn));
        }
    }
}

// Query untuk featured (3 random)
$featured_query = mysqli_query($conn, "SELECT * FROM tb_product WHERE product_status = 1 ORDER BY RAND() LIMIT 3");
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Keranjang Belanja - Ruang Sukma</title>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <!-- Google Fonts: Poppins -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet" />
  <!-- Font Awesome Icons -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
  <!-- AOS Animations -->
  <link href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css" rel="stylesheet" />
  <style>
    /* (Style Anda tetap sama, tidak ada perubahan) */
    body {
      font-family: 'Poppins', sans-serif;
      background: linear-gradient(135deg, #f4f6f8, #e9ecef);
      color: #333;
      line-height: 1.6;
      padding-top: 80px;
    }
    a { text-decoration: none; }
    .navbar-custom {
      background: rgba(216, 58, 74, 0.95) !important;
      backdrop-filter: blur(20px);
      box-shadow: 0 4px 20px rgba(216, 58, 74, 0.2);
      padding: 1rem 0;
    }
    .navbar-brand {
      font-weight: 700; font-size: 1.8rem; color: #fff !important;
    }
    .nav-link { color: #fff !important; font-weight: 500; padding: 0.5rem 1rem; }
    .nav-link:hover { color: #f8f9fa !important; }
    .cart-badge { background: #fff; color: #d83a4a; border-radius: 50%; padding: 4px 8px; font-size: 0.8rem; }
    .cart-hero {
      height: 25vh; overflow: hidden; margin-bottom: 2rem;
      background: linear-gradient(135deg, #d83a4a, #c0392b);
      position: relative;
    }
    @media (max-width: 768px) { .cart-hero { height: 20vh; } }
    .hero-overlay {
      position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);
      text-align: center; color: #fff; z-index: 10; line-height: 1.4;
      padding: 0 1rem;
    }
    .hero-overlay h1 {
      font-size: 2.5rem; font-weight: 700; text-shadow: 2px 2px 8px rgba(0,0,0,0.5);
      margin-bottom: 0.5rem;
    }
    @media (max-width: 768px) { .hero-overlay h1 { font-size: 1.8rem; } }
    .hero-overlay p { font-size: 1.1rem; margin-bottom: 1.5rem; }
    .hero-btn {
      background: rgba(255, 255, 255, 0.9); color: #d83a4a; border: none;
      padding: 0.75rem 1.5rem; border-radius: 50px; font-weight: 600; font-size: 1rem;
      transition: all 0.3s;
    }
    .hero-btn:hover { background: #fff; color: #d83a4a; transform: translateY(-2px); }
    .cart-section { max-width: 1100px; margin: 0 auto 3rem; padding: 0 1rem; }
    .cart-card {
      background: #fff; border-radius: 20px; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.1);
      transition: all 0.4s ease;
    }
    .cart-card:hover { transform: translateY(-5px); box-shadow: 0 15px 40px rgba(0,0,0,0.15); }
    .cart-item {
      display: flex; align-items: center; padding: 1rem; border-bottom: 1px solid #eee;
      gap: 1rem;
    }
    .cart-img { width: 80px; height: 80px; object-fit: contain; border-radius: 10px; background: #f8f9fa; }
    .cart-details { flex-grow: 1; }
    .cart-name { font-weight: 600; margin-bottom: 0.5rem; }
    .cart-price { color: #18a74a; font-weight: 700; font-size: 1.1rem; }
    .qty-input { width: 60px; padding: 0.5rem; border: 2px solid #e9ecef; border-radius: 5px; text-align: center; }
    .btn-cart { padding: 0.5rem 1rem; border-radius: 25px; font-weight: 500; transition: all 0.3s; }
    .btn-update { background: #007bff; color: #fff; border: none; }
    .btn-update:hover { background: #0056b3; }
    .btn-delete { background: #dc3545; color: #fff; border: none; }
    .btn-delete:hover { background: #c82333; }
    .price-summary {
      background: #f8f9fa; border-radius: 15px; padding: 1.5rem; margin-top: 2rem; border: 1px solid #e9ecef;
    }
    .price-row { display: flex; justify-content: space-between; margin-bottom: 0.75rem; font-size: 1rem; }
    .price-label { color: #666; }
    .price-value { font-weight: 600; color: #333; }
    .total-row { border-top: 2px solid #d83a4a; padding-top: 1rem; margin-top: 1rem; }
    .total-value { color: #d83a4a; font-size: 1.5rem; font-weight: 700; }
    .ongkir-note { font-size: 0.9rem; color: #888; margin-top: 0.5rem; text-align: center; font-style: italic; }
    .empty-cart { text-align: center; padding: 3rem; color: #666; }
    .btn-main { background: linear-gradient(135deg, #007bff, #0056b3); color: #fff; border: none; padding: 1rem 2rem; border-radius: 50px; font-weight: 600; font-size: 1.1rem; transition: all 0.3s; }
    .btn-main:hover { background: linear-gradient(135deg, #0056b3, #004085); transform: scale(1.05);    .sidebar { background: #fff; border-radius: 15px; padding: 1.5rem; box-shadow: 0 5px 20px rgba(0,0,0,0.1); height: fit-content; position: sticky; top: 100px; }
    .sidebar h5 { color: #d83a4a; border-bottom: 2px solid #d83a4a; padding-bottom: 0.5rem; margin-bottom: 1rem; font-weight: 600; }
    .sidebar-product { display: flex; gap: 1rem; margin-bottom: 1rem; padding-bottom: 1rem; border-bottom: 1px solid #eee; align-items: center; }
    .sidebar-img { width: 70px; height: 70px; object-fit: contain; border-radius: 10px; flex-shrink: 0; background: #f8f9fa; display: flex; align-items: center; justify-content: center; }
    .sidebar-name { font-size: 1rem; font-weight: 500; margin-bottom: 0.25rem; }
    .sidebar-price { color: #18a74a; font-weight: 600; font-size: 1rem; }
    .btn-sidebar { background: linear-gradient(135deg, #007bff, #0056b3); color: #fff; border: none; padding: 0.5rem 1rem; border-radius: 25px; font-weight: 500; font-size: 0.9rem; }
    .btn-sidebar:hover { background: linear-gradient(135deg, #0056b3, #004085); }
    footer { background: linear-gradient(135deg, #333, #555); color: #fff; text-align: center; padding: 3rem 1rem; margin-top: 5rem; }
    .social-links a { color: #fff; font-size: 1.5rem; margin: 0 1rem; transition: color 0.3s; }
    .social-links a:hover { color: #d83a4a; }
    @media (max-width: 992px) { .sidebar { position: static; margin-top: 2rem; } }
    @media (max-width: 768px) {
      .cart-item { flex-direction: column; text-align: center; gap: 0.5rem; }
      .btn-main { width: 100%; margin-bottom: 1rem; }
      .qty-input { width: 80px; }
      .cart-hero { height: 20vh; }
      .hero-overlay h1 { font-size: 1.8rem; }
    }
  </style>
</head>
<body>

<!-- Navbar Bootstrap Modern (dengan badge menggunakan $cart_count) -->
<nav class="navbar navbar-expand-lg navbar-custom fixed-top">
  <div class="container">
    <a class="navbar-brand" href="index.php">
      <i class="fas fa-home me-2"></i>Ruang Sukma
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link" href="index.php"><i class="fas fa-home me-1"></i>Home</a></li>
        <li class="nav-item"><a class="nav-link" href="index.php"><i class="fas fa-box me-1"></i>Produk</a></li>
        <li class="nav-item position-relative">
          <a class="nav-link active" href="cart.php">
            <i class="fas fa-shopping-cart me-1"></i>Keranjang
            <?php if ($cart_count > 0): ?>
              <span class="cart-badge"><?php echo $cart_count; ?></span>
            <?php endif; ?>
          </a>
        </li>
        <li class="nav-item"><span class="nav-link text-white">Halo, <?php echo htmlspecialchars($user_nama); ?>!</span></li>
        <li class="nav-item"><a class="nav-link" href="logout_user.php"><i class="fas fa-sign-out-alt me-1"></i>Logout</a></li>
      </ul>
    </div>
  </div>
</nav>

<!-- Hero Sederhana untuk Cart -->
<section class="cart-hero">
  <div class="hero-overlay">
    <h1>Keranjang Belanja</h1>
    <p><?php echo $cart_count; ?> item di keranjang Anda</p>
    <a href="index.php" class="hero-btn"><i class="fas fa-arrow-left me-2"></i>Lanjut Belanja</a>
  </div>
</section>

<!-- Cart Section Modern (Grid + Sidebar) -->
<section class="cart-section" data-aos="fade-up">
  <div class="row">
    <!-- Main Cart (9 kolom desktop) -->
    <div class="col-lg-9">
      <div class="cart-card">
        <?php if (empty($cart_items)): ?>
          <div class="empty-cart">
            <i class="fas fa-shopping-cart fa-3x mb-3 text-muted"></i>
            <h4>Keranjang Anda kosong</h4>
            <p>Tambahkan produk dari halaman detail untuk memulai belanja.</p>
            <a href="index.php" class="btn btn-main"><i class="fas fa-home me-2"></i>Ke Beranda</a>
          </div>
        <?php else: ?>
          <div class="p-3">
            <h5><i class="fas fa-list me-2"></i>Daftar Belanja (<?php echo count($cart_items); ?> item)</h5>
            <?php foreach ($cart_items as $item): ?>
              <div class="cart-item">
                <img src="produk/<?php echo htmlspecialchars($item['product_image'] ?? 'default.jpg'); ?>" alt="<?php echo htmlspecialchars($item['product_name'] ?? 'Produk'); ?>" class="cart-img" onerror="this.src='https://via.placeholder.com/80x80/d83a4a/ffffff?text=P'">
                <div class="cart-details">
                  <div class="cart-name"><?php echo htmlspecialchars($item['product_name'] ?? 'Produk Tidak Dikenal'); ?></div>
                  <div class="cart-price">Rp <?php echo number_format($item['product_price'] ?? 0, 0, ',', '.'); ?></div>
                  <small class="text-muted">Subtotal: Rp <?php echo number_format($item['subtotal'] ?? 0, 0, ',', '.'); ?></small>
                </div>
                <div class="text-center">
                  <form method="POST" style="display: inline;" onsubmit="return confirm('Update qty?');">
                    <input type="hidden" name="action" value="update">
                    <input type="hidden" name="product_id" value="<?php echo $item['product_id']; ?>">
                    <input type="number" name="qty" value="<?php echo $item['qty']; ?>" min="1" class="qty-input" required>
                    <br>
                    <button type="submit" class="btn btn-cart btn-update mt-1"><i class="fas fa-sync me-1"></i>Update</button>
                  </form>
                  <br>
                  <form method="POST" style="display: inline;" onsubmit="return confirm('Hapus item ini dari keranjang?');">
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="product_id" value="<?php echo $item['product_id']; ?>">
                    <button type="submit" class="btn btn-cart btn-delete mt-1"><i class="fas fa-trash me-1"></i>Hapus</button>
                  </form>
                </div>
              </div>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      </div>

      <!-- Price Summary (jika ada item) - HANYA SUBTOTAL, ONGKI DI CHECKOUT -->
      <?php if (!empty($cart_items)): ?>
        <div class="price-summary">
          <div class="price-row">
            <span class="price-label">Subtotal (<?php echo count($cart_items); ?> item):</span>
            <span class="price-value">Rp <?php echo number_format($total, 0, ',', '.'); ?></span>
          </div>
          <div class="price-row">
            <span class="price-label">Ongkir:</span>
            <span class="price-value">Rp 0 (akan dihitung di checkout berdasarkan alamat)</span>
          </div>
          <div class="price-row total-row">
            <span class="price-label">Total Sementara:</span>
            <span class="total-value">Rp <?php echo number_format($total, 0, ',', '.'); ?></span>
          </div>
          <div class="ongkir-note">
            <i class="fas fa-info-circle me-1"></i>Ongkir akan dihitung otomatis saat checkout berdasarkan alamat pengiriman Anda. Lanjutkan untuk input alamat dan pilih pembayaran.
          </div>
          <div class="text-center mt-3">
            <a href="checkout.php?from=cart" class="btn btn-main"><i class="fas fa-credit-card me-2"></i>Lanjut Checkout</a>
          </div>
        </div>
      <?php endif; ?>
    </div>


    </div>
  </div>
</section>

<!-- Footer Modern -->
<footer class="text-center py-5" data-aos="fade-up">
  <div class="container">
    <div class="row">
      <div class="col-md-6">
        <h5 class="text-white mb-3">Ruang Sukma</h5>
        <p class="text-light">Toko online terpercaya untuk kebutuhan rumah tangga dan kantor. Kualitas terbaik, harga terjangkau.</p>
      </div>
      <div class="col-md-6">
        <h5 class="text-white mb-3">Hubungi Kami</h5>
        <p class="text-light">Email: info@ruangsukma.com | Telp: (021) 123-4567</p>
        <div class="social-links">
          <a href="#"><i class="fab fa-facebook-f"></i></a>
          <a href="#"><i class="fab fa-instagram"></i></a>
          <a href="#"><i class="fab fa-twitter"></i></a>
          <a href="#"><i class="fab fa-whatsapp"></i></a>
        </div>
      </div>
    </div>
    <hr class="my-4 border-light">
    <p class="text-light mb-0">&copy; 2024 Ruang Sukma. All rights reserved. | <a href="tentang.php" class="text-light">Tentang Kami</a></p>
  </div>
</footer>

<!-- Scripts Modern -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
<script>
  AOS.init({ duration: 1000, once: true, offset: 100 });

  // Optional: Validasi qty input (minimal 1, max opsional jika ada stok)
  document.querySelectorAll('.qty-input').forEach(input => {
    input.addEventListener('input', function() {
      if (this.value < 1) {
        this.value = 1;
      }
      // Optional: Max qty berdasarkan stok (jika dikirim dari PHP via data attribute)
      // const maxStok = parseInt(this.dataset.max) || 999;
      // if (this.value > maxStok) this.value = maxStok;
    });
  });

  // Optional: Konfirmasi sebelum submit form (sudah ada onsubmit confirm)
</script>

</body>
</html>
<?php
// Tutup koneksi DB
mysqli_close($conn);
?>