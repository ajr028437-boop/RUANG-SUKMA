<?php
session_start();
include 'db.php';

// Ambil data user jika login
$user_nama = isset($_SESSION['nama']) ? $_SESSION['nama'] : null;
$is_logged_in = isset($_SESSION['user_id']);
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Tentang Kami - Ruang Sukma</title>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Google Fonts: Poppins (Modern 2025) -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <!-- Font Awesome Icons -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
  <!-- AOS Animations -->
  <link href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css" rel="stylesheet">
  <style>
    body {
      font-family: 'Poppins', sans-serif;
      background: linear-gradient(135deg, #f4f6f8, #e9ecef);
      color: #333;
      line-height: 1.6;
      padding-top: 80px; /* Ruang untuk navbar fixed */
    }
    a { text-decoration: none; }
    /* Navbar Modern */
    .navbar-custom {
      background: rgba(216, 58, 74, 0.95) !important;
      backdrop-filter: blur(20px);
      box-shadow: 0 4px 20px rgba(216, 58, 74, 0.2);
      padding: 1rem 0;
    }
    .navbar-brand {
      font-weight: 700; font-size: 1.8rem; color: #fff !important;
    }
    .nav-link { color: #fff !important; font-weight: 500; padding: 0.5rem 1rem; }
    .nav-link:hover { color: #f8f9fa !important; }
    .cart-badge { background: #fff; color: #d83a4a; border-radius: 50%; padding: 4px 8px; font-size: 0.8rem; }
    /* Hero Section Sederhana untuk Tentang Kami (Merah, Tanpa Gambar) */
    .about-hero { 
      height: 30vh; overflow: hidden; margin-bottom: 2rem; 
      background: linear-gradient(135deg, #d83a4a, #c0392b); 
      position: relative;
    }
    @media (max-width: 768px) { .about-hero { height: 25vh; } }
    .hero-overlay {
      position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);
      text-align: center; color: #fff; z-index: 10; line-height: 1.4;
      padding: 0 1rem;
    }
    .hero-overlay h1 { 
      font-size: 2.5rem; font-weight: 700; text-shadow: 2px 2px 8px rgba(0,0,0,0.5); 
      margin-bottom: 0.5rem; 
    }
    @media (max-width: 768px) { .hero-overlay h1 { font-size: 1.8rem; } }
    .hero-overlay p { font-size: 1.1rem; margin-bottom: 1.5rem; }
    .hero-btn { 
      background: rgba(255, 255, 255, 0.9); color: #d83a4a; border: none; 
      padding: 0.75rem 1.5rem; border-radius: 50px; font-weight: 600; font-size: 1rem; 
      transition: all 0.3s; 
    }
    .hero-btn:hover { background: #fff; color: #d83a4a; transform: translateY(-2px); }
    /* About Section Modern */
    .about-section { max-width: 1100px; margin: 0 auto 3rem; padding: 0 1rem; }
    .about-card {
      background: #fff; border-radius: 20px; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.1);
      transition: all 0.4s ease;
    }
    .about-card:hover { transform: translateY(-5px); box-shadow: 0 15px 40px rgba(0,0,0,0.15); }
    .about-body { padding: 2rem; }
    .section-title { color: #d83a4a; font-weight: 700; margin-bottom: 1.5rem; font-size: 1.5rem; }
    .about-content p { 
      font-size: 1.1rem; margin-bottom: 1.5rem; text-align: justify; 
      color: #555; 
    }
    .about-content i { color: #d83a4a; margin-right: 0.5rem; }
    .btn-back { 
      background: linear-gradient(135deg, #6c757d, #5a6268); color: #fff; border: none; 
      padding: 1rem 2rem; border-radius: 50px; font-weight: 600; font-size: 1.1rem; 
      transition: all 0.3s; 
    }
    .btn-back:hover { background: linear-gradient(135deg, #5a6268, #495057); transform: scale(1.05); }
    /* Footer Modern */
    footer { background: linear-gradient(135deg, #333, #555); color: #fff; text-align: center; padding: 3rem 1rem; margin-top: 5rem; }
    .social-links a { color: #fff; font-size: 1.5rem; margin: 0 1rem; transition: color 0.3s; }
    .social-links a:hover { color: #d83a4a; }
    /* Responsive */
    @media (max-width: 768px) { 
      .about-body { padding: 1.5rem; } 
      .about-content p { font-size: 1rem; }
    }
  </style>
</head>
<body>

<!-- Navbar Bootstrap Modern -->
<nav class="navbar navbar-expand-lg navbar-custom fixed-top">
  <div class="container">
    <a class="navbar-brand" href="index.php">
      <i class="fas fa-home me-2"></i>Ruang Sukma
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link" href="index.php"><i class="fas fa-home me-1"></i>Home</a></li>
        <li class="nav-item"><a class="nav-link" href="index.php"><i class="fas fa-box me-1"></i>Produk</a></li>
        <li class="nav-item"><a class="nav-link active" href="tentang.php"><i class="fas fa-info-circle me-1"></i>Tentang Kami</a></li>
        <?php if ($is_logged_in): ?>
          <li class="nav-item position-relative">
            <a class="nav-link" href="cart.php">
              <i class="fas fa-shopping-cart me-1"></i>Keranjang
              <?php if(isset($_SESSION['cart']) && count($_SESSION['cart']) > 0): ?>
                <span class="cart-badge"><?php echo count($_SESSION['cart']); ?></span>
              <?php endif; ?>
            </a>
          </li>
          <li class="nav-item"><span class="nav-link text-white">Halo, <?php echo htmlspecialchars($user_nama ?? 'User '); ?>!</span></li>
          <li class="nav-item"><a class="nav-link" href="logout_user.php"><i class="fas fa-sign-out-alt me-1"></i>Logout</a></li>
        <?php else: ?>
          <li class="nav-item"><a class="nav-link" href="login_user.php"><i class="fas fa-sign-in-alt me-1"></i>Login</a></li>
          <li class="nav-item"><a class="nav-link" href="register_user.php"><i class="fas fa-user-plus me-1"></i>Register</a></li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>

<!-- Hero Sederhana untuk Tentang Kami -->
<section class="about-hero">
  <div class="hero-overlay">
    <h1>Tentang Kami</h1>
    <p>Kisah dan visi Ruang Sukma</p>
    <a href="index.php" class="hero-btn"><i class="fas fa-arrow-left me-2"></i>Kembali ke Beranda</a>
  </div>
</section>

<!-- About Section Modern -->
<section class="about-section" data-aos="fade-up">
  <div class="row justify-content-center">
    <div class="col-12">
      <div class="about-card">
        <div class="about-body">
          <h2 class="section-title"><i class="fas fa-building me-2"></i>Selamat Datang di Ruang Sukma</h2>
          
          <div class="about-content" data-aos="fade-up" data-aos-delay="100">
            <p>
              <i class="fas fa-heart me-2"></i>Ruang Sukma adalah platform sederhana yang menyediakan berbagai produk kebutuhan Anda. 
              Kami hadir untuk memberikan pengalaman belanja yang nyaman, cepat, dan terpercaya.
            </p>
            <p>
              <i class="fas fa-shopping-bag me-2"></i>Dengan berbagai kategori produk, kami berharap bisa membantu Anda menemukan barang yang sesuai dengan kebutuhan. 
              Kepuasan pelanggan adalah prioritas utama kami.
            </p>
          </div>

          <div style="margin-top: 2rem; text-align: center;">
            <a href="index.php" class="btn btn-back">
              <i class="fas fa-arrow-left me-2"></i>Kembali ke Beranda
            </a>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Footer Modern -->
<footer class="text-center py-5" data-aos="fade-up">
  <div class="container">
    <div class="row">
      <div class="col-md-6">
        <h5 class="text-white mb-3">Ruang Sukma</h5>
        <p class="text-light">Toko online terpercaya untuk kebutuhan rumah tangga dan kantor. Kualitas terbaik, harga terjangkau.</p>
      </div>
      <div class="col-md-6">
        <h5 class="text-white mb-3">Hubungi Kami</h5>
        <p class="text-light">Email: info@ruangsukma.com | Telp: (021) 123-4567</p>
        <div class="social-links">
          <a href="#"><i class="fab fa-facebook-f"></i></a>
          <a href="#"><i class="fab fa-instagram"></i></a>
          <a href="#"><i class="fab fa-twitter"></i></a>
          <a href="#"><i class="fab fa-whatsapp"></i></a>
        </div>
      </div>
    </div>
    <hr class="my-4 border-light">
    <p class="text-light mb-0">&copy; 2024 Ruang Sukma. All rights reserved. | <a href="tentang.php" class="text-light">Tentang Kami</a></p>
  </div>
</footer>

<!-- Scripts Modern -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
<script>
  AOS.init({ duration: 1000, once: true, offset: 100 });
</script>

</body>
</html>
<?php
// Tutup koneksi DB
mysqli_close($conn);
?>