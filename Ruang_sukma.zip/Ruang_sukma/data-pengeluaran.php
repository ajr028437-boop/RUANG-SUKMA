<?php
include 'db.php';

// Tambah data
if (isset($_POST['tambah'])) {
    $deskripsi = $_POST['deskripsi'];
    $jumlah = $_POST['jumlah'];
    mysqli_query($conn, "INSERT INTO tb_expense (description, amount) 
                         VALUES ('$deskripsi', '$jumlah')");
    header("Location: data-pengeluaran.php");
    exit;
}

// Hapus
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    mysqli_query($conn, "DELETE FROM tb_expense WHERE expense_id='$id'");
    header("Location: data-pengeluaran.php");
    exit;
}

// Edit
if (isset($_POST['edit'])) {
    $id = $_POST['expense_id'];
    $deskripsi = $_POST['deskripsi'];
    $jumlah = $_POST['jumlah'];
    mysqli_query($conn, "UPDATE tb_expense 
                         SET description='$deskripsi', amount='$jumlah' 
                         WHERE expense_id='$id'");
    header("Location: data-pengeluaran.php");
    exit;
}

// Ambil data
$data = mysqli_query($conn, "SELECT * FROM tb_expense ORDER BY expense_date DESC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Data Pengeluaran - Ruang Sukma</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Quicksand&display=swap');

        body {
            font-family: 'Quicksand', sans-serif;
            background-color: #f9fafb;
            margin: 0;
            min-height: 100vh;
        }
        .sidebar {
            min-height: 100vh;
            background: #d32f2f;
            color: #fff;
            padding: 30px 0;
            box-shadow: 3px 0 8px rgba(0,0,0,0.1);
            width: 250px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        .sidebar h2 {
            font-weight: 700;
            font-size: 1.8rem;
            margin-bottom: 2rem;
            letter-spacing: 1px;
            text-align: center;
        }
        .sidebar a {
            color: #fff;
            font-weight: 600;
            font-size: 1rem;
            padding: 12px 25px;
            border-radius: 10px;
            margin: 8px 15px;
            text-decoration: none;
            width: 100%;
            transition: background-color 0.3s ease, transform 0.2s ease;
            display: block;
        }
        .sidebar a.active, .sidebar a:hover {
            background: #b71c1c;
            box-shadow: inset 5px 0 0 0 #ff5252;
            transform: translateX(5px);
            text-decoration: none;
        }
        .content {
            flex-grow: 1;
            background-color: #fff;
            min-height: 100vh;
            padding: 30px 40px;
        }
        h2.page-title {
            margin-bottom: 1.5rem;
            font-weight: 700;
        }
        .card {
            border-radius: 12px;
            box-shadow: 0 6px 15px rgb(0 0 0 / 0.1);
            border: none;
            margin-bottom: 2rem;
        }
        .card-body {
            padding: 2rem;
        }
        table {
            border-collapse: separate !important;
            border-spacing: 0 10px !important;
            width: 100%;
        }
        thead tr {
            background-color: #b71c1c !important;
            color: #fff;
            border-radius: 12px;
        }
        thead th {
            border: none !important;
            font-weight: 700;
            font-size: 1rem;
            padding: 12px 15px;
            vertical-align: middle;
            text-align: center;
        }
        tbody tr {
            background-color: #fff;
            box-shadow: 0 2px 8px rgb(0 0 0 / 0.05);
            border-radius: 10px;
            transition: box-shadow 0.3s ease;
        }
        tbody tr:hover {
            box-shadow: 0 6px 20px rgb(0 0 0 / 0.12);
        }
        tbody td {
            vertical-align: middle;
            padding: 15px 12px;
            font-size: 0.95rem;
            color: #333;
            border: none !important;
            text-align: center;
            word-wrap: break-word;
        }
        tbody td.text-start {
            text-align: left;
        }
        .btn-primary, .btn-danger {
            font-weight: 600;
            border-radius: 8px;
            padding: 6px 14px;
            transition: background-color 0.3s ease, box-shadow 0.3s ease;
        }
        .btn-primary {
            background-color: #e53935;
            border: none;
            box-shadow: 0 3px 8px rgb(229 38 16 / 0.4);
            color: #fff;
        }
        .btn-primary:hover {
            background-color: #b71c1c;
            box-shadow: 0 6px 12px rgb(204 0 0 / 0.6);
            color: #fff;
        }
        .btn-danger {
            background-color: #e53935;
            border: none;
            box-shadow: 0 3px 8px rgb(229 57 53 / 0.4);
            color: #fff;
        }
        .btn-danger:hover {
            background-color: #b71c1c;
            color: #fff;
        }
        form.inline-form {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            justify-content: center;
            align-items: center;
        }
        form.inline-form input[type="text"],
        form.inline-form input[type="number"] {
            padding: 6px 10px;
            border-radius: 6px;
            border: 1px solid #ccc;
            font-size: 0.9rem;
            min-width: 150px;
        }
        form.inline-form button {
            padding: 6px 14px;
            border-radius: 8px;
            font-weight: 600;
            border: none;
            background-color: #1976d2;
            color: #fff;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        form.inline-form button:hover {
            background-color: #115293;
        }
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                min-height: auto;
                flex-direction: row;
                justify-content: space-around;
                padding: 15px 0;
            }
            .sidebar h2 {
                display: none;
            }
            .sidebar a {
                margin: 0 5px;
                padding: 8px 12px;
                font-size: 0.9rem;
                text-align: center;
                flex-grow: 1;
            }
            .content {
                padding: 20px 15px;
                min-height: auto;
            }
            table {
                font-size: 0.85rem;
            }
            thead th, tbody td {
                padding: 10px 8px;
            }
            form.inline-form {
                flex-direction: column;
                gap: 8px;
            }
            form.inline-form input,
            form.inline-form button {
                min-width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="d-flex flex-column flex-md-row min-vh-100">
        <!-- Sidebar -->
        <nav class="sidebar d-flex flex-column">
            <h2>Ruang Sukma</h2>
            <a href="dashboard.php" class="nav-link">📊 Dashboard</a>
            <a href="profil.php" class="nav-link">👤 Profil</a>
            <a href="data-kategori.php" class="nav-link">📂 Data Kategori</a>
            <a href="data-produk.php" class="nav-link">📦 Data Produk</a>
            <a href="data-pesanan.php" class="nav-link">🧾 Data Pesanan</a>
            <a href="data-pendapatan.php" class="nav-link">💰 Data Pendapatan</a>
            <a href="data-pengeluaran.php" class="nav-link active">💸 Data Pengeluaran</a>
            <a href="keluar.php" class="nav-link">🚪 Keluar</a>
        </nav>

        <!-- Content -->
        <main class="content">
            <h2 class="page-title">💸 Data Pengeluaran</h2>

            <!-- Form Tambah Pengeluaran -->
            <div class="card mb-4">
                <div class="card-body">
                    <form method="POST" class="inline-form" novalidate>
                        <input type="text" name="deskripsi" placeholder="Deskripsi" required />
                        <input type="number" name="jumlah" placeholder="Jumlah" required min="0" />
                        <button type="submit" name="tambah">Tambah Pengeluaran</button>
                    </form>
                </div>
            </div>

            <!-- Tabel Data Pengeluaran -->
            <div class="card">
                <div class="card-body">
                    <table class="table table-striped table-bordered align-middle">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th class="text-start">Deskripsi</th>
                                <th>Jumlah</th>
                                <th>Tanggal</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($row = mysqli_fetch_assoc($data)) { ?>
                            <tr>
                                <td><?= $row['expense_id'] ?></td>
                                <td class="text-start"><?= htmlspecialchars($row['description']) ?></td>
                                <td class="text-end">Rp <?= number_format($row['amount'],0,',','.') ?></td>
                                <td><?= date('d-m-Y', strtotime($row['expense_date'])) ?></td>
                                <td>
                                    <form method="POST" class="inline-form" style="justify-content:flex-start; gap:5px; flex-wrap: nowrap;">
                                        <input type="hidden" name="expense_id" value="<?= $row['expense_id'] ?>" />
                                        <input type="text" name="deskripsi" value="<?= htmlspecialchars($row['description']) ?>" required style="width: 200px;" />
                                        <input type="number" name="jumlah" value="<?= $row['amount'] ?>" required min="0" style="width: 120px;" />
                                        <button type="submit" name="edit" class="btn btn-primary btn-sm">Edit</button>
                                    </form>
                                    <a href="?hapus=<?= $row['expense_id'] ?>" class="btn btn-danger btn-sm mt-1" onclick="return confirm('Hapus data ini?')">Hapus</a>
                                </td>
                            </tr>
                            <?php } ?>
                            <?php if(mysqli_num_rows($data) == 0) { ?>
                            <tr>
                                <td colspan="5" class="text-center py-4">Belum ada data pengeluaran</td>
                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
</body>
</html>