<?php
session_start();
include 'db.php';

// Cek login
if (!isset($_SESSION['user_id'])) {
    header("Location: login_user.php");
    exit;
}

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id > 0 && isset($_SESSION['cart'][$id])) {
    unset($_SESSION['cart'][$id]);
    $_SESSION['flash_message'] = 'Item berhasil dihapus dari keranjang!';
    $_SESSION['flash_type'] = 'success';
} else {
    $_SESSION['flash_message'] = 'Item tidak ditemukan.';
    $_SESSION['flash_type'] = 'error';
}

header("Location: cart.php");
exit;

mysqli_close($conn);
?>