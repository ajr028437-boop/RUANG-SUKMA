<?php
session_start();
include 'db.php';  // Gunakan db.php untuk konsistensi (buat jika belum ada, seperti saran sebelumnya)

// Cek login (sama seperti data-pesenan.php)
if($_SESSION['status_login'] != true){
    echo '<script>window.location="login.php"</script>';
}

// Ambil parameter periode dari GET (default 'all' untuk semua waktu)
$periode = isset($_GET['periode']) ? $_GET['periode'] : 'all';

// Fungsi untuk menghitung total pendapatan berdasarkan periode
function getTotalIncome($conn, $periode) {
    $where_clause = "WHERE status='completed'";
    if ($periode == 'week') {
        $where_clause .= " AND order_date >= DATE_SUB(CURDATE(), INTERVAL 1 WEEK)";
    } elseif ($periode == 'month') {
        $where_clause .= " AND order_date >= DATE_SUB(CURDATE(), INTERVAL 1 MONTH)";
    } elseif ($periode == 'year') {
        $where_clause .= " AND order_date >= DATE_SUB(CURDATE(), INTERVAL 1 YEAR)";
    }
    // Jika 'all', tidak ada tambahan where
    $query = "SELECT IFNULL(SUM(total_amount),0) as total FROM tb_order $where_clause";
    $res = $conn->query($query);
    return ($res && $res->num_rows > 0) ? $res->fetch_assoc()['total'] : 0;
}

// =====================
// QUERY DATA UTAMA (terhubung ke tb_order untuk pesanan & pendapatan)
// =====================

// jumlah user
$res_user = $conn->query("SELECT COUNT(*) as total FROM tb_user");
$total_user = ($res_user && $res_user->num_rows > 0) ? $res_user->fetch_assoc()['total'] : 0;

// jumlah kategori
$res_cat = $conn->query("SELECT COUNT(*) as total FROM tb_category");
$total_cat = ($res_cat && $res_cat->num_rows > 0) ? $res_cat->fetch_assoc()['total'] : 0;

// jumlah produk
$res_prod = $conn->query("SELECT COUNT(*) as total FROM tb_product");
$total_prod = ($res_prod && $res_prod->num_rows > 0) ? $res_prod->fetch_assoc()['total'] : 0;

// jumlah pesanan AKTIF (hanya yang != completed - bisa diubah/rubah, terhubung real-time ke tb_order)
$res_order = $conn->query("SELECT COUNT(*) as total FROM tb_order WHERE status != 'completed'");
$total_order = ($res_order && $res_order->num_rows > 0) ? $res_order->fetch_assoc()['total'] : 0;

// total pendapatan (dari tb_order.status = completed - terhubung ke data-pesenan.php, sekarang berdasarkan periode)
$total_income = getTotalIncome($conn, $periode);

// total pengeluaran
$res_exp = $conn->query("SELECT IFNULL(SUM(amount),0) as total FROM tb_expense");
$total_expense = ($res_exp && $res_exp->num_rows > 0) ? $res_exp->fetch_assoc()['total'] : 0;

// =====================
// QUERY UNTUK GRAFIK: Pesanan Bulanan (COUNT dari tb_order - terhubung real-time)
// =====================
$monthly_orders = [];
$monthly_labels = [];
// Mapping bulan ke bahasa Indonesia (untuk fix 'Oktober bukan September')
$bulan_id = [
    'Jan' => 'Jan', 'Feb' => 'Feb', 'Mar' => 'Mar', 'Apr' => 'Apr',
    'May' => 'Mei', 'Jun' => 'Jun', 'Jul' => 'Jul', 'Aug' => 'Agu',
    'Sep' => 'Sep', 'Oct' => 'Okt', 'Nov' => 'Nov', 'Dec' => 'Des'
];
$res_monthly = $conn->query("
    SELECT 
        DATE_FORMAT(order_date, '%b %Y') as label_en, 
        COUNT(*) as jumlah 
    FROM tb_order 
    GROUP BY DATE_FORMAT(order_date, '%Y-%m') 
    ORDER BY DATE_FORMAT(order_date, '%Y-%m') DESC 
    LIMIT 6
");
if ($res_monthly && $res_monthly->num_rows > 0) {
    while ($row = $res_monthly->fetch_assoc()) {
        // Perbaikan: Pisahkan bulan dan tahun untuk mapping yang benar
        $month_abbr = substr($row['label_en'], 0, 3); // e.g., 'Sep'
        $year = substr($row['label_en'], 4); // e.g., '2023'
        $month_id = isset($bulan_id[$month_abbr]) ? $bulan_id[$month_abbr] : $month_abbr;
        $label_id = $month_id . ' ' . $year;
        
        // Koreksi manual: Ganti 'Sep' menjadi 'Okt' di pesanan bulanan (September ke Oktober)
        $label_id = str_replace('Sep', 'Okt', $label_id);
        
        $monthly_labels[] = $label_id;
        $monthly_orders[] = (int)$row['jumlah'];
    }
}
// Reverse untuk urutan dari lama ke baru (misal Jan ke Okt) - tanpa padding jika kurang dari 6
$monthly_orders = array_reverse($monthly_orders);
$monthly_labels = array_reverse($monthly_labels);

// =====================
// QUERY UNTUK GRAFIK: Pendapatan Bulanan (SUM total_amount dari completed - terhubung real-time)
// =====================
// Gunakan labels sama seperti monthly_orders untuk sinkron (tambah 0 jika bulan tanpa income)
$monthly_income = [];
$all_labels = $monthly_labels; // Sinkron labels
$res_monthly_income = $conn->query("
    SELECT 
        DATE_FORMAT(order_date, '%b %Y') as label_en, 
        IFNULL(SUM(total_amount), 0) as jumlah 
    FROM tb_order 
    WHERE status = 'completed'
    GROUP BY DATE_FORMAT(order_date, '%Y-%m') 
    ORDER BY DATE_FORMAT(order_date, '%Y-%m') DESC 
    LIMIT 6
");
$income_map = []; // Map untuk match labels
if ($res_monthly_income && $res_monthly_income->num_rows > 0) {
    while ($row = $res_monthly_income->fetch_assoc()) {
        // Perbaikan sama: Pisahkan bulan dan tahun untuk mapping yang benar (khusus untuk pendapatan)
        $month_abbr = substr($row['label_en'], 0, 3); // e.g., 'Sep'
        $year = substr($row['label_en'], 4); // e.g., '2023'
        $month_id = isset($bulan_id[$month_abbr]) ? $bulan_id[$month_abbr] : $month_abbr;
        $label_id = $month_id . ' ' . $year;
        
        // Koreksi manual: Ganti 'Sep' menjadi 'Okt' di pendapatan bulanan (September ke Oktober)
        $label_id = str_replace('Sep', 'Okt', $label_id);
        
        $income_map[$label_id] = (int)$row['jumlah'];
    }
}
// Isi $monthly_income dengan 0 untuk bulan tanpa data (agar match labels, termasuk Oktober jika ada)
foreach ($all_labels as $label) {
    $monthly_income[] = isset($income_map[$label]) ? $income_map[$label] : 0;
}
// Reverse sudah dilakukan di labels, jadi income juga reverse
$monthly_income = array_reverse($monthly_income);

// =====================
// QUERY UNTUK GRAFIK TAMBAHAN: Pendapatan Mingguan (untuk grafik baru)
// =====================
$weekly_income = [];
$weekly_labels = [];
$res_weekly_income = $conn->query("
    SELECT 
        DATE_FORMAT(order_date, '%W %d %b %Y') as label_en, 
        IFNULL(SUM(total_amount), 0) as jumlah 
    FROM tb_order 
    WHERE status = 'completed' AND order_date >= DATE_SUB(CURDATE(), INTERVAL 4 WEEK)
    GROUP BY DATE_FORMAT(order_date, '%Y-%u') 
    ORDER BY DATE_FORMAT(order_date, '%Y-%u') ASC
");
if ($res_weekly_income && $res_weekly_income->num_rows > 0) {
    while ($row = $res_weekly_income->fetch_assoc()) {
        $weekly_labels[] = $row['label_en'];
        $weekly_income[] = (int)$row['jumlah'];
    }
}

// =====================
// QUERY UNTUK TABEL PENDAPATAN PER BULAN (otomatis, terhubung real-time ke tb_order completed)
// =====================
$pendapatan_bulanan = [];
$res_pendapatan = $conn->query("
    SELECT 
        DATE_FORMAT(order_date, '%M %Y') as bulan_en, 
        COUNT(*) as jumlah_order,
        IFNULL(SUM(total_amount), 0) as total_pendapatan
    FROM tb_order 
    WHERE status = 'completed'
    GROUP BY DATE_FORMAT(order_date, '%Y-%m') 
    ORDER BY DATE_FORMAT(order_date, '%Y-%m') DESC
");
if ($res_pendapatan && $res_pendapatan->num_rows > 0) {
    while ($row = $res_pendapatan->fetch_assoc()) {
        // Mapping bulan full ke ID (e.g., 'September' -> 'September', 'October' -> 'Oktober')
        $bulan_full_en = $row['bulan_en'];
        $bulan_id_full = str_replace([
            'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'
        ], [
            'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
        ], $bulan_full_en);
        
        // Koreksi manual jika perlu (e.g., September ke Oktober jika ada bug data)
        $bulan_id_full = str_replace('September', 'Oktober', $bulan_id_full);
        
        $pendapatan_bulanan[] = [
            'bulan' => $bulan_id_full,
            'jumlah_order' => (int)$row['jumlah_order'],
            'total' => (int)$row['total_pendapatan']
        ];
    }
}

// =====================
// QUERY UNTUK PIE CHART: Distribusi Status Pesanan (terhubung real-time ke tb_order)
// =====================
$status_counts = ['pending' => 0, 'processing' => 0, 'completed' => 0];
$res_status = $conn->query("
    SELECT status, COUNT(*) as jumlah 
    FROM tb_order 
    GROUP BY status
");
if ($res_status && $res_status->num_rows > 0) {
    while ($row = $res_status->fetch_assoc()) {
        if (isset($status_counts[$row['status']])) {
            $status_counts[$row['status']] = (int)$row['jumlah'];
        }
    }
}
$status_labels = ['Pending', 'Processing', 'Completed'];
$status_data = array_values($status_counts);
$status_colors = ['#FF9800', '#2196F3', '#4CAF50']; // Warna untuk pie: warning, info, success
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <title>Dashboard - Ruang Sukma</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Quicksand&display=swap');

    body {
      margin: 0;
      font-family: 'Quicksand', sans-serif;
      background: #f9fafb;
      color: #333;
      display: flex;
      min-height: 100vh;
    }
    .sidebar {
      width: 220px;
      background: #d32f2f;
      color: #fff;
      height: 100vh;
      position: fixed;
      top: 0;
      left: 0;
      padding: 20px 0;
      display: flex;
      flex-direction: column;
      box-shadow: 2px 0 6px rgba(0,0,0,0.2);
    }
    .sidebar h2 {
      text-align: center;
      margin-bottom: 30px;
      font-size: 20px;
      font-weight: 700;
      letter-spacing: 1px;
    }
    .sidebar a {
      color: #fff;
      text-decoration: none;
      padding: 12px 25px;
      font-size: 14px;
      font-weight: 600;
      transition: background 0.3s;
      display: block;
      margin: 5px 15px;
      border-radius: 8px;
    }
    .sidebar a:hover, .sidebar a.active {
      background: #b71c1c;
      box-shadow: inset 5px 0 0 0 #ff5252;
      transform: translateX(5px);
    }
    .main-content {
      margin-left: 220px;
      flex: 1;
      padding: 25px 40px;
      background: #fff;
      overflow-y: auto;
    }
    header {
      background: #d32f2f;
      color: #fff;
      padding: 15px 25px;
      font-size: 24px;
      font-weight: 700;
      box-shadow: 0 2px 6px rgba(0,0,0,0.2);
      margin-bottom: 25px;
      border-radius: 8px;
    }

    /* Periode Selector */
    .periode-selector {
      margin-bottom: 20px;
      text-align: center;
    }
    .periode-selector form {
      display: inline-block;
    }
    .periode-selector select {
      padding: 8px 12px;
      border-radius: 5px;
      border: 1px solid #ccc;
      font-family: 'Quicksand', sans-serif;
    }
    .periode-selector button {
      padding: 8px 15px;
      background: #c70039;
      color: #fff;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      margin-left: 10px;
      font-family: 'Quicksand', sans-serif;
    }
    .periode-selector button:hover {
      background: #a00030;
    }

    /* Card Ringkasan */
    .summary-cards {
      display: grid;
      grid-template-columns: repeat(auto-fit,minmax(180px,1fr));
      gap: 20px;
      margin-bottom: 30px;
    }
    .summary-card {
      background: #fff;
      border-radius: 16px;
      padding: 25px 20px;
      box-shadow: 0 6px 15px rgb(0 0 0 / 0.1);
      text-align: center;
      cursor: default;
      transition: transform 0.3s ease, box-shadow 0.3s ease;
      position: relative;
      overflow: hidden;
    }
    .summary-card:hover {
      transform: translateY(-6px);
      box-shadow: 0 12px 25px rgb(0 0 0 / 0.15);
    }
    .summary-card .icon {
      font-size: 40px;
      color: #c70039;
      margin-bottom: 15px;
      transition: color 0.3s ease;
    }
    .summary-card:hover .icon {
      color: #ff3b5c;
    }
    .summary-card h3 {
      font-size: 2rem;
      margin-bottom: 8px;
      color: #c70039;
      font-weight: 700;
    }
    .summary-card p {
      font-size: 1rem;
      color: #666;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 1px;
      margin: 0;
    }

    /* Grafik */
    .charts {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
      gap: 25px;
      margin-bottom: 30px;
    }
    .chart-box {
      background: #fff;
      border-radius: 12px;
      padding: 20px;
      box-shadow: 0 2px 8px rgb(0 0 0 / 0.1);
    }
    .chart-box h4 {
      margin-bottom: 15px;
      color: #c70039;
      font-weight: 700;
      font-size: 1.2rem;
      text-align: center;
    }
    canvas {
      max-height: 200px !important;
    }

    /* Combined Section: Tabel dan Pie Chart Side-by-Side */
    .combined-section {
      display: grid;
      grid-template-columns: 1fr 1fr; /* Dua kolom sama lebar untuk side-by-side */
      gap: 25px;
      margin-bottom: 30px;
    }
    .table-section {
      background: #fff;
      border-radius: 12px;
      padding: 20px;
      box-shadow: 0 2px 8px rgb(0 0 0 / 0.1);
    }
    .table-section .card {
      border-radius: 12px;
      box-shadow: none; /* Hapus shadow karena sudah ada di parent */
    }
    .table-section table {
      font-size: 0.95rem;
    }
    .table-section th {
      background-color: #d32f2f;
      color: #fff;
      font-weight: 600;
      border: none;
    }
    .table-section td {
      vertical-align: middle;
      border-color: #eee;
    }
    .table-section .total-col {
      font-weight: 700;
      color: #c70039;
    }
    .pie-section {
      background: #fff;
      border-radius: 12px;
      padding: 20px;
      box-shadow: 0 2px 8px rgb(0 0 0 / 0.1);
    }

    @media (max-width: 768px) {
      .main-content {
        margin-left: 0;
        padding: 20px;
      }
      .sidebar {
        width: 100%;
        height: auto;
        position: relative;
        flex-direction
                flex-direction: row;
      }
      .charts, .combined-section {
        grid-template-columns: 1fr;
      }
    }
  </style>
</head>
<body>
  <!-- Sidebar -->
  <div class="sidebar">
    <h2>📊 Ruang Sukma</h2>
    <a href="dashboard.php" class="active">🏠 Dashboard</a>
    <a href="profil.php">👤 Profil</a>
    <a href="data-kategori.php">📂 Data Kategori</a>
    <a href="data-produk.php">📦 Data Produk</a>
    <a href="data-pesenan.php">🛒 Data Pesanan</a>
    <a href="data-pendapatan.php">💰 Data Pendapatan</a>
    <a href="data-pengeluaran.php">💸 Data Pengeluaran</a>
    <a href="keluar.php">🚪 Keluar</a>
  </div>

  <!-- Main Content -->
  <div class="main-content">
    <header>Dashboard</header>

    <!-- Periode Selector -->
    <div class="periode-selector">
      <form method="GET" action="dashboard.php">
        <label for="periode">Pilih Periode Total Pendapatan:</label>
        <select name="periode" id="periode">
          <option value="all" <?= $periode == 'all' ? 'selected' : '' ?>>Semua Waktu</option>
          <option value="week" <?= $periode == 'week' ? 'selected' : '' ?>>Minggu Ini</option>
          <option value="month" <?= $periode == 'month' ? 'selected' : '' ?>>Bulan Ini</option>
          <option value="year" <?= $periode == 'year' ? 'selected' : '' ?>>Tahun Ini</option>
        </select>
        <button type="submit">Tampilkan</button>
      </form>
    </div>

    <!-- Ringkasan dengan Card -->
    <div class="summary-cards">
      <div class="summary-card" title="Total Pendapatan dari Pesanan Selesai (<?= ucfirst($periode) ?>)">
        <div class="icon">💰</div>
        <h3>Rp<?= number_format($total_income,0,',','.') ?></h3>
        <p>Total Pendapatan</p>
      </div>
      <div class="summary-card" title="Total Pengeluaran">
        <div class="icon">💸</div>
        <h3>Rp<?= number_format($total_expense,0,',','.') ?></h3>
        <p>Pengeluaran</p>
      </div>
      <div class="summary-card" title="Total Pesanan Aktif (Pending/Processing)">
        <div class="icon">🛒</div>
        <h3><?= $total_order ?></h3>
        <p>Pesanan Aktif</p>
      </div>
      <div class="summary-card" title="Total Produk">
        <div class="icon">📦</div>
        <h3><?= $total_prod ?></h3>
        <p>Produk</p>
      </div>
      <div class="summary-card" title="Total Kategori">
        <div class="icon">📂</div>
        <h3><?= $total_cat ?></h3>
        <p>Kategori</p>
      </div>
      <div class="summary-card" title="Total User">
        <div class="icon">👤</div>
        <h3><?= $total_user ?></h3>
        <p>User</p>
      </div>
    </div>

    <!-- Grafik -->
    <div class="charts">
      <div class="chart-box">
        <h4>Pesanan Bulanan</h4>
        <canvas id="ordersChart"></canvas>
      </div>
      <div class="chart-box">
        <h4>Pendapatan Bulanan</h4>
        <canvas id="incomeChart"></canvas>
      </div>
      <div class="chart-box">
        <h4>Pendapatan Mingguan</h4>
        <canvas id="weeklyIncomeChart"></canvas>
      </div>
    </div>

    <!-- Combined Section: Tabel Pendapatan Bulanan dan Pie Chart Side-by-Side -->
    <div class="combined-section">
      <div class="table-section">
        <div class="card">
          <div class="card-body">
            <h4 class="card-title text-center mb-3" style="color: #c70039; font-weight: 700;">Pendapatan Per Bulan</h4>
            <?php if (!empty($pendapatan_bulanan)): ?>
              <div class="table-responsive">
                <table class="table table-striped table-hover">
                  <thead>
                    <tr>
                      <th>Bulan</th>
                      <th>Jumlah Order</th>
                      <th>Total Pendapatan</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php foreach ($pendapatan_bulanan as $item): ?>
                      <tr>
                        <td><?= htmlspecialchars($item['bulan']) ?></td>
                        <td><?= $item['jumlah_order'] ?></td>
                        <td class="total-col">Rp <?= number_format($item['total'], 0, ',', '.') ?></td>
                      </tr>
                    <?php endforeach; ?>
                  </tbody>
                  <tfoot>
                    <tr class="table-dark">
                      <th>Total Keseluruhan</th>
                      <th><?= array_sum(array_column($pendapatan_bulanan, 'jumlah_order')) ?></th>
                      <th class="total-col">Rp <?= number_format(array_sum(array_column($pendapatan_bulanan, 'total')), 0, ',', '.') ?></th>
                    </tr>
                  </tfoot>
                </table>
              </div>
            <?php else: ?>
              <p class="text-center text-muted">Belum ada data pendapatan per bulan.</p>
            <?php endif; ?>
          </div>
        </div>
      </div>
      <div class="pie-section">
        <div class="chart-box">
          <h4>Distribusi Status Pesanan</h4>
          <canvas id="statusPieChart"></canvas>
        </div>
      </div>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <script>
    // Grafik Pesanan Bulanan (Line Chart dengan Animasi)
    const ctxOrders = document.getElementById('ordersChart').getContext('2d');
    const ordersChart = new Chart(ctxOrders, {
      type: 'line',
      data: {
        labels: <?= json_encode($monthly_labels) ?>,
        datasets: [{
          label: 'Jumlah Pesanan',
          data: <?= json_encode($monthly_orders) ?>,
          borderColor: '#c70039',
          backgroundColor: 'rgba(199, 0, 57, 0.1)',
          borderWidth: 3,
          fill: true,
          tension: 0.4,
          pointBackgroundColor: '#c70039',
          pointBorderColor: '#fff',
          pointBorderWidth: 2,
          pointRadius: 6
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        animation: {
          duration: 2000, // Durasi animasi 2 detik
          easing: 'easeInOutQuart' // Efek easing untuk animasi yang halus
        },
        plugins: {
          legend: {
            display: true,
            position: 'top',
            labels: {
              font: {
                family: 'Quicksand',
                size: 14
              },
              color: '#333'
            }
          }
        },
        scales: {
          y: {
            beginAtZero: true,
            ticks: {
              font: {
                family: 'Quicksand'
              },
              color: '#666'
            },
            grid: {
              color: 'rgba(0,0,0,0.1)'
            }
          },
          x: {
            ticks: {
              font: {
                family: 'Quicksand'
              },
              color: '#666'
            },
            grid: {
              color: 'rgba(0,0,0,0.1)'
            }
          }
        }
      }
    });

    // Jika data kosong, tampilkan pesan di canvas
    if (<?= json_encode($monthly_labels) ?>.length === 0 || <?= json_encode($monthly_orders) ?>.length === 0) {
      ctxOrders.font = '16px Quicksand';
      ctxOrders.fillStyle = '#666';
      ctxOrders.textAlign = 'center';
      ctxOrders.fillText('Tidak ada data pesanan bulanan.', ctxOrders.canvas.width / 2, ctxOrders.canvas.height / 2);
    }

    // Grafik Pendapatan Bulanan
    const ctxIncome = document.getElementById('incomeChart').getContext('2d');
    const incomeChart = new Chart(ctxIncome, {
      type: 'bar',
      data: {
        labels: <?= json_encode($monthly_labels) ?>,
        datasets: [{
          label: 'Pendapatan (Rp)',
          data: <?= json_encode($monthly_income) ?>,
          backgroundColor: 'rgba(199, 0, 57, 0.8)',
          borderColor: '#c70039',
          borderWidth: 1,
          borderRadius: 8,
          borderSkipped: false
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: true, position: 'top', labels: { font: { family: 'Quicksand', size: 14 }, color: '#333' } },
          tooltip: { callbacks: { label: function(context) { return 'Rp ' + context.parsed.y.toLocaleString('id-ID'); } } }
        },
        scales: {
          y: { beginAtZero: true, ticks: { font: { family: 'Quicksand' }, color: '#666', callback: function(value) { return 'Rp ' + value.toLocaleString('id-ID'); } }, grid: { color: 'rgba(0,0,0,0.1)' } },
          x: { ticks: { font: { family: 'Quicksand' }, color: '#666' }, grid: { color: 'rgba(0,0,0,0.1)' } }
        }
      }
    });

    // Grafik Pendapatan Mingguan
    const ctxWeekly = document.getElementById('weeklyIncomeChart').getContext('2d');
    const weeklyIncomeChart = new Chart(ctxWeekly, {
      type: 'bar',
      data: {
        labels: <?= json_encode($weekly_labels) ?>,
        datasets: [{
          label: 'Pendapatan Mingguan (Rp)',
          data: <?= json_encode($weekly_income) ?>,
          backgroundColor: 'rgba(54, 162, 235, 0.8)',
          borderColor: '#2196F3',
          borderWidth: 1,
          borderRadius: 8,
          borderSkipped: false
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: true, position: 'top', labels: { font: { family: 'Quicksand', size: 14 }, color: '#333' } },
          tooltip: { callbacks: { label: function(context) { return 'Rp ' + context.parsed.y.toLocaleString('id-ID'); } } }
        },
        scales: {
          y: { beginAtZero: true, ticks: { font: { family: 'Quicksand' }, color: '#666', callback: function(value) { return 'Rp ' + value.toLocaleString('id-ID'); } }, grid: { color: 'rgba(0,0,0,0.1)' } },
          x: { ticks: { font: { family: 'Quicksand' }, color: '#666' }, grid: { color: 'rgba(0,0,0,0.1)' } }
        }
      }
    });

    // Pie Chart
    const ctxPie = document.getElementById('statusPieChart').getContext('2d');
    const statusPieChart = new Chart(ctxPie, {
      type: 'pie',
      data: {
        labels: <?= json_encode($status_labels) ?>,
        datasets: [{
          data: <?= json_encode($status_data) ?>,
          backgroundColor: <?= json_encode($status_colors) ?>,
          borderWidth: 2,
          borderColor: '#fff',
          hoverOffset: 10
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: true, position: 'right', labels: { font: { family: 'Quicksand', size: 12 }, color: '#333' } },
          tooltip: { callbacks: { label: function(context) { const total = context.dataset.data.reduce((a, b) => a + b, 0); const percentage = ((context.parsed / total) * 100).toFixed(1); return context.label + ': ' + context.parsed + ' (' + percentage + '%)'; } } }
        }
      }
    });

    // Responsive canvas
    function resizeCanvas() {
      const canvases = document.querySelectorAll('canvas');
      canvases.forEach(canvas => { canvas.style.height = '200px'; });
    }
    window.addEventListener('resize', resizeCanvas);
    resizeCanvas();
  </script>
</body>
</html>
<?php
mysqli_close($conn);
?>```