<?php
session_start();
include 'db.php';
if($_SESSION['status_login'] != true){
    echo '<script>window.location="login.php"</script>';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Data Kategori - Ruang Sukma</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Quicksand&display=swap');

    body {
      font-family: 'Quicksand', sans-serif;
      background-color: #f9fafb;
      margin: 0;
      min-height: 100vh;
    }
    .sidebar {
      min-height: 100vh;
      background: #d32f2f; /* merah lembut */
      color: #fff;
      padding: 30px 0;
      box-shadow: 3px 0 8px rgba(0,0,0,0.1);
    }
    .sidebar h4 {
      font-weight: 700;
      font-size: 1.6rem;
      margin-bottom: 2rem;
      text-align: center;
      letter-spacing: 1px;
    }
    .sidebar a {
      color: #fff;
      text-decoration: none;
      display: block;
      padding: 12px 25px;
      border-radius: 10px;
      margin: 8px 15px;
      font-weight: 600;
      font-size: 1rem;
      transition: background-color 0.3s ease, transform 0.2s ease;
      box-shadow: inset 0 0 0 0 transparent;
    }
    .sidebar a.active, .sidebar a:hover {
      background: #b71c1c; /* merah gelap */
      box-shadow: inset 5px 0 0 0 #ff5252;
      transform: translateX(5px);
    }
    .content {
      padding: 30px 40px;
      background-color: #fff;
      min-height: 100vh;
    }
    .btn-primary {
      background: #e53935;
      border: none;
      font-weight: 600;
      padding: 10px 20px;
      border-radius: 8px;
      box-shadow: 0 4px 8px rgb(229 38 16 / 0.4);
      transition: background-color 0.3s ease, box-shadow 0.3s ease;
    }
    .btn-primary:hover {
      background: #b71c1c;
      box-shadow: 0 6px 12px rgb(204 0 0 / 0.6);
    }
    .card {
      border-radius: 12px;
      box-shadow: 0 6px 15px rgb(0 0 0 / 0.1);
      border: none;
    }
    .card-body {
      padding: 1.8rem 2rem;
    }
    table {
      border-collapse: separate !important;
      border-spacing: 0 10px !important;
      width: 100%;
    }
    thead tr {
      background-color: #b71c1c !important;
      color: #fff;
      border-radius: 12px;
    }
    thead th {
      border: none !important;
      font-weight: 700;
      font-size: 1rem;
      padding: 12px 15px;
      vertical-align: middle;
      text-align: center;
    }
    tbody tr {
      background-color: #fff;
      box-shadow: 0 2px 8px rgb(0 0 0 / 0.05);
      border-radius: 10px;
      transition: box-shadow 0.3s ease;
    }
    tbody tr:hover {
      box-shadow: 0 6px 20px rgb(0 0 0 / 0.12);
    }
    tbody td {
      vertical-align: middle;
      padding: 15px 12px;
      font-size: 0.95rem;
      color: #333;
      border: none !important;
      text-align: center;
    }
    .btn-warning {
      background-color: #fbc02d;
      border: none;
      font-weight: 600;
      padding: 6px 14px;
      border-radius: 6px;
      box-shadow: 0 3px 8px rgb(251 192 45 / 0.4);
      transition: background-color 0.3s ease;
      color: #333;
      margin-right: 5px;
    }
    .btn-warning:hover {
      background-color: #c49000;
      color: #fff;
    }
    .btn-danger {
      background-color: #e53935;
      border: none;
      font-weight: 600;
      padding: 6px 14px;
      border-radius: 6px;
      box-shadow: 0 3px 8px rgb(229 57 53 / 0.4);
      transition: background-color 0.3s ease;
    }
    .btn-danger:hover {
      background-color: #b71c1c;
    }
    @media (max-width: 768px) {
      .sidebar {
        min-height: auto;
        padding: 15px 0;
      }
      .sidebar a {
        margin: 5px 10px;
        padding: 10px 15px;
        font-size: 0.9rem;
      }
      .content {
        padding: 20px 15px;
      }
      table {
        font-size: 0.85rem;
      }
      thead th, tbody td {
        padding: 10px 8px;
      }
    }
  </style>
</head>
<body>
<div class="container-fluid">
  <div class="row">
    <!-- Sidebar -->
    <nav class="col-md-2 sidebar d-flex flex-column">
      <h4 class="text-center mb-4">📌 Ruang Sukma</h4>
      <a href="dashboard.php">📊 Dashboard</a>
      <a href="profil.php">👤 Profil</a>
      <a href="data-kategori.php" class="active">📂 Data Kategori</a>
      <a href="data-produk.php">📦 Data Produk</a>
      <a href="data-pesenan.php">🧾 Data Pesanan</a>
      <a href="data-pendapatan.php">💰 Data Pendapatan</a>
      <a href="data-pengeluaran.php">💸 Data Pengeluaran</a>
      <a href="keluar.php">🚪 Keluar</a>
    </nav>

    <!-- Main Content -->
    <main class="col-md-10 content">
      <div class="d-flex justify-content-between align-items-center mb-4">
        <h3>📂 Data Kategori</h3>
        <a href="tambah-kategori.php" class="btn btn-primary">+ Tambah Kategori</a>
      </div>

      <div class="card shadow-sm">
        <div class="card-body">
          <table class="table table-bordered table-striped align-middle">
            <thead>
              <tr>
                <th width="60px">No</th>
                <th>Kategori</th>
                <th width="150px">Aksi</th>
              </tr>
            </thead>
            <tbody>
              <?php 
                $no = 1;
                $kategori = mysqli_query($conn, "SELECT * FROM tb_category ORDER BY category_id DESC");
                if($kategori && mysqli_num_rows($kategori) > 0){
                  while ($row = mysqli_fetch_array($kategori)) {
              ?>
              <tr>
                <td><?= $no++; ?></td>
                <td><?= htmlspecialchars($row['category_name']); ?></td>
                <td>
                  <a href="edit-kategori.php?id=<?= $row['category_id']; ?>" class="btn btn-sm btn-warning">Edit</a>
                  <a href="proses-hapus.php?id=<?= $row['category_id']; ?>" 
                     onclick="return confirm('Yakin ingin menghapus kategori ini?')" 
                     class="btn btn-sm btn-danger">Hapus</a>
                </td>
              </tr>
              <?php
                  }
                } else {
                  echo '<tr><td colspan="3" class="text-center py-4">Belum ada data</td></tr>';
                }
              ?>
            </tbody>
          </table>
        </div>
      </div>
    </main>
  </div>
</div>
</body>
</html>