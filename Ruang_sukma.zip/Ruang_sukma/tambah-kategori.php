<?php
session_start();
include 'db.php';
if (!isset($_SESSION['status_login']) || $_SESSION['status_login'] !== true) {
    header('Location: login.php');
    exit();
}

// Proses tambah data kategori
if (isset($_POST['submit'])) {
    $nama = ucwords(mysqli_real_escape_string($conn, $_POST['nama']));

    $insert = mysqli_query($conn, "INSERT INTO tb_category (category_name) VALUES ('$nama')");

    if ($insert) {
        echo '<script>alert("Tambah data berhasil")</script>';
        echo '<script>window.location="data-kategori.php"</script>';
        exit();
    } else {
        $error = 'Gagal: ' . mysqli_error($conn);
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Tambah Kategori - Ruang Sukma</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Quicksand&display=swap');

        body {
            font-family: 'Quicksand', sans-serif;
            background-color: #f9fafb;
            margin: 0;
            min-height: 100vh;
        }

        .sidebar {
            min-height: 100vh;
            background: #d32f2f;
            color: #fff;
            padding: 30px 0;
            box-shadow: 3px 0 8px rgba(0, 0, 0, 0.1);
        }

        .sidebar h4 {
            font-weight: 700;
            font-size: 1.6rem;
            margin-bottom: 2rem;
            text-align: center;
            letter-spacing: 1px;
        }

        .sidebar a {
            color: #fff;
            text-decoration: none;
            display: block;
            padding: 12px 25px;
            border-radius: 10px;
            margin: 8px 15px;
            font-weight: 600;
            font-size: 1rem;
            transition: background-color 0.3s ease, transform 0.2s ease;
            box-shadow: inset 0 0 0 0 transparent;
        }

        .sidebar a.active,
        .sidebar a:hover {
            background: #b71c1c;
            box-shadow: inset 5px 0 0 0 #ff5252;
            transform: translateX(5px);
        }

        .content {
            padding: 30px 40px;
            background-color: #fff;
            min-height: 100vh;
        }

        h3 {
            margin-bottom: 1.5rem;
        }

        .input-control {
            width: 100%;
            padding: 10px 15px;
            border-radius: 8px;
            border: 1px solid #ddd;
            font-size: 1rem;
            margin-bottom: 20px;
            transition: border-color 0.3s ease;
        }

        .input-control:focus {
            outline: none;
            border-color: #e53935;
            box-shadow: 0 0 8px rgb(229 38 16 / 0.4);
        }

        .btn {
            background: #e53935;
            border: none;
            color: #fff;
            font-weight: 600;
            padding: 10px 25px;
            border-radius: 8px;
            cursor: pointer;
            box-shadow: 0 4px 8px rgb(229 38 16 / 0.4);
            transition: background-color 0.3s ease, box-shadow 0.3s ease;
        }

        .btn:hover {
            background: #b71c1c;
            box-shadow: 0 6px 12px rgb(204 0 0 / 0.6);
        }

        .alert {
            max-width: 600px;
            margin-bottom: 20px;
        }

        @media (max-width: 768px) {
            .sidebar {
                min-height: auto;
                padding: 15px 0;
            }

            .sidebar a {
                margin: 5px 10px;
                padding: 10px 15px;
                font-size: 0.9rem;
            }

            .content {
                padding: 20px 15px;
            }
        }
    </style>
</head>

<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <nav class="col-md-2 sidebar d-flex flex-column">
                <h4 class="text-center mb-4">📌 Ruang Sukma</h4>
                <a href="dashboard.php">📊 Dashboard</a>
                <a href="profil.php">👤 Profil</a>
                <a href="data-kategori.php" class="active">📂 Data Kategori</a>
                <a href="data-produk.php">📦 Data Produk</a>
                <a href="data-pesenan.php">🧾 Data Pesanan</a>
                <a href="data-pendapatan.php">💰 Data Pendapatan</a>
                <a href="data-pengeluaran.php">💸 Data Pengeluaran</a>
                <a href="keluar.php">🚪 Keluar</a>
            </nav>

            <!-- Main Content -->
            <main class="col-md-10 content">
                <h3>➕ Tambah Data Kategori</h3>

                <?php if (isset($error)) : ?>
                    <div class="alert alert-danger" role="alert">
                        <?= htmlspecialchars($error) ?>
                    </div>
                <?php endif; ?>

                <form action="" method="POST" style="max-width: 600px;">
                    <input type="text" name="nama" placeholder="Nama Kategori" class="input-control" required>
                    <button type="submit" name="submit" class="btn">Simpan</button>
                </form>
            </main>
        </div>
    </div>
</body>

</html>