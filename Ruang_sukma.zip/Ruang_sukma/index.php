<?php
// index.php
session_start();
include 'db.php';

// Debug koneksi (hapus setelah test)
if (!isset($conn)) { die('Error: db.php gagal!'); }
error_reporting(E_ALL); ini_set('display_errors', 1); // Aktifkan error PHP sementara

// Debug session cart (hapus setelah test)
if (isset($_GET['debug_cart'])) {
    echo "<!-- DEBUG: Cart count = " . (isset($_SESSION['cart']) ? count($_SESSION['cart']) : 0) . " -->";
}

if (!isset($_SESSION['user_login'])) {
    header("Location: login_user.php");
    exit;
}

// Ambil data nama user dari session atau database (untuk tampilan profil)
$user_name = $_SESSION['user_name'] ?? null;
$user_id = $_SESSION['user_login']; // Asumsi ini user_id (int)
if (!$user_name && $user_id) {
    $stmt = mysqli_prepare($conn, "SELECT nama FROM tb_user WHERE id = ?");
    mysqli_stmt_bind_param($stmt, "i", $user_id);
    mysqli_stmt_execute($stmt);
    $result_user = mysqli_stmt_get_result($stmt);
    if ($result_user && mysqli_num_rows($result_user) > 0) {
        $user_data = mysqli_fetch_assoc($result_user);
        $user_name = $user_data['nama'];
        $_SESSION['user_name'] = $user_name; // Simpan ke session agar tidak query ulang
    }
    mysqli_stmt_close($stmt);
}

$search   = isset($_GET['search']) ? trim($_GET['search']) : '';
$kategori = isset($_GET['kategori']) ? $_GET['kategori'] : '';

$kategori_query = mysqli_query($conn, "SELECT DISTINCT category_name FROM tb_product ORDER BY category_name ASC");

$query_produk = "SELECT * FROM tb_product WHERE product_status = 1";
if ($search !== '') {
    $search_esc = mysqli_real_escape_string($conn, $search);
    $query_produk .= " AND product_name LIKE '%$search_esc%'";
}
if ($kategori !== '') {
    $kategori_esc = mysqli_real_escape_string($conn, $kategori);
    $query_produk .= " AND category_name='$kategori_esc'";
}
$query_produk .= " ORDER BY product_id DESC";
$produk_query = mysqli_query($conn, $query_produk);

// Debug: Cek jumlah produk
$num_produk = mysqli_num_rows($produk_query);
if ($num_produk == 0) {
    echo "<!-- DEBUG: 0 produk. Tambah data DB! -->";
}

// Query untuk featured (3 random)
$featured_query = mysqli_query($conn, "SELECT * FROM tb_product WHERE product_status = 1 ORDER BY RAND() LIMIT 3");
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Ruang Sukma</title>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Google Fonts: Poppins (Modern 2025) -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <!-- Font Awesome Icons -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
  <!-- AOS Animations -->
  <link href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css" rel="stylesheet">
  <style>
    body {
      font-family: 'Poppins', sans-serif;
      background: linear-gradient(135deg, #f4f6f8, #e9ecef);
      color: #333;
      line-height: 1.6;
      padding-top: 80px; /* Ruang untuk navbar fixed agar hero tidak overlap */
    }
    a { text-decoration: none; }
    /* Navbar Modern */
    .navbar-custom {
      background: rgba(216, 58, 74, 0.95) !important;
      backdrop-filter: blur(20px);
      box-shadow: 0 4px 20px rgba(216, 58, 74, 0.2);
      padding: 1rem 0;
    }
    .navbar-brand {
      font-weight: 700; font-size: 1.8rem; color: #fff !important;
    }
    .nav-link { color: #fff !important; font-weight: 500; padding: 0.5rem 1rem; }
    .nav-link:hover { color: #f8f9fa !important; }
    .cart-badge { background: #fff; color: #d83a4a; border-radius: 50%; padding: 4px 8px; font-size: 0.8rem; }
    /* Dropdown Profil Styling (Merah Tema) */
    .dropdown-menu {
      border: none;
      box-shadow: 0 10px 30px rgba(216, 58, 74, 0.2);
      border-radius: 15px;
      background: #fff;
    }
    .dropdown-item {
      color: #333;
      padding: 0.75rem 1.5rem;
      transition: background 0.3s;
    }
    .dropdown-item:hover {
      background: rgba(216, 58, 74, 0.1);
      color: #d83a4a;
    }
    .dropdown-item i { margin-right: 0.5rem; }
    /* Hero Statis Sederhana (Warna Merah Merah Saja, Tanpa Gambar) */
    .hero-section { 
      height: 55vh; overflow: hidden; margin-bottom: 2rem; 
      background: linear-gradient(135deg, #d83a4a, #c0392b); /* Merah merah saja, tanpa foto */
      position: relative;
    }
    @media (max-width: 768px) { .hero-section { height: 45vh; } }
    .hero-overlay {
      position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);
      text-align: center; color: #fff; z-index: 10; line-height: 1.4;
      padding: 0 1rem;
    }
    .hero-overlay h1 { 
      font-size: 3rem; font-weight: 700; text-shadow: 2px 2px 8px rgba(0,0,0,0.5); 
      margin-bottom: 1rem; 
    }
    @media (max-width: 768px) { .hero-overlay h1 { font-size: 2rem; } }
    .hero-overlay p { font-size: 1.2rem; margin-bottom: 2rem; }
    .hero-btn { 
      background: rgba(255, 255, 255, 0.9); color: #d83a4a; border: none; 
      padding: 1rem 2rem; border-radius: 50px; font-weight: 600; font-size: 1.1rem; 
      transition: all 0.3s; 
    }
    .hero-btn:hover { background: #fff; color: #d83a4a; transform: translateY(-2px); }
    /* Search Modern */
    .search-section { max-width: 800px; margin: 0 auto 3rem; padding: 0 1rem; }
    .search-form { box-shadow: 0 10px 40px rgba(216, 58, 74, 0.2); border-radius: 50px; overflow: hidden; }
    .search-input { padding: 1rem 2rem; border: none; font-size: 1.1rem; background: transparent; }
    .search-btn { background: linear-gradient(135deg, #d83a4a, #c0392b); border: none; color: #fff; padding: 1rem 2rem; font-weight: 600; }
    .search-btn:hover { background: linear-gradient(135deg, #c0392b, #a93226); transform: scale(1.05); }
    /* Category Filter Horizontal Scroll */
    .category-filter { 
      display: flex; gap: 1rem; overflow-x: auto; padding-bottom: 1rem; scrollbar-width: thin; 
    }
    .category-btn { 
      padding: 0.75rem 1.5rem; border-radius: 50px; background: #f8f9fa; border: 2px solid #e9ecef; 
      color: #333; font-weight: 500; white-space: nowrap; flex-shrink: 0; transition: all 0.3s; 
    }
    .category-btn:hover, .category-btn.active { 
      background: #d83a4a; color: #fff; border-color: #d83a4a; transform: translateY(-2px); 
    }
    /* Product Cards Rapih (Align Height, Semua Terlihat) */
    .product-card {
      background: #fff; border-radius: 20px; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.1);
      transition: all 0.4s ease; height: 100%; position: relative; display: flex; flex-direction: column; /* Rapih align */
    }
    .product-card:hover { transform: translateY(-10px) scale(1.02); box-shadow: 0 20px 50px rgba(0,0,0,0.2); }
    .product-img { 
      width: 100%; height: 250px; object-fit: contain; /* Ubah ke contain agar gambar keliatan semua tanpa potong */
      transition: transform 0.4s; flex-shrink: 0; /* Fixed height agar rapih */
      background: #f8f9fa; /* Background halus untuk ruang kosong agar rapih */
      display: flex; align-items: center; justify-content: center; /* Center gambar jika kecil */
    }
    @media (max-width: 768px) { .product-img { height: 200px; } } /* Mobile rapih */
    .product-card:hover .product-img { transform: scale(1.05); } /* Hover scale ringan agar tidak potong */
    .product-body { padding: 1.5rem; flex-grow: 1; display: flex; flex-direction: column; justify-content: space-between; /* Isi merata, semua terlihat */ }
    .product-name { font-size: 1.25rem; font-weight: 600; color: #333; margin-bottom: 0.5rem; }
    .product-price { color: #18a74a; font-weight: 700; font-size: 1.25rem; margin-bottom: 1rem; }
    .product-desc { color: #666; font-size: 0.95rem; margin-bottom: 1rem; flex-grow: 1; /* Deskripsi isi ruang tersisa */ }
    .btn-detail { background: linear-gradient(135deg, #007bff, #0056b3); color: #fff; border: none; padding: 0.75rem; border-radius: 25px; font-weight: 500; flex: 1; margin-right: 0.5rem; }
    .btn-detail:hover { background: linear-gradient(135deg, #0056b3, #004085); transform: scale(1.05); }
    .btn-cart { background: linear-gradient(135deg, #28a745, #218838); color: #fff; border: none; padding: 0.75rem; border-radius: 25px; font-weight: 500; flex: 1; }
    .btn-cart:hover { background: linear-gradient(135deg, #218838, #1e7e34); transform: scale(1.05); }
    .product-badge { position: absolute; top: 1rem; left: 1rem; background: #d83a4a; color: #fff; padding: 0.25rem 0.75rem; border-radius: 20px; font-size: 0.8rem; font-weight: 600; z-index: 2; }
    /* Sidebar Sticky Rapih (Gambar juga keliatan semua) */
    .sidebar { background: #fff; border-radius: 15px; padding: 1.5rem; box-shadow: 0 5px 20px rgba(0,0,0,0.1); height: fit-content; position: sticky; top: 100px; }
    .sidebar h5 { color: #d83a4a; border-bottom: 2px solid #d83a4a; padding-bottom: 0.5rem; margin-bottom: 1rem; font-weight: 600; }
    .sidebar-product { display: flex; gap: 1rem; margin-bottom: 1rem; padding-bottom: 1rem; border-bottom: 1px solid #eee; align-items: center; /* Rapih align gambar & teks */ }
    .sidebar-img { 
      width: 70px; height: 70px; object-fit: contain; /* Ubah ke contain agar gambar keliatan semua */
      border-radius: 10px; flex-shrink: 0; background: #f8f9fa; /* Background halus untuk ruang kosong */
      display: flex; align-items: center; justify-content: center; /* Center gambar jika kecil */
    }
    .sidebar-name { font-size: 1rem; font-weight: 500; margin-bottom: 0.25rem; }
    .sidebar-price { color: #18a74a; font-weight: 600; font-size: 1rem; }
    /* Skeleton Loader Modern (Rapih untuk 0 produk, simulasi gambar full) */
    .skeleton { background: linear-gradient(90deg, #f0f0f0 25%, #e0e0e0 50%, #f0f0f0 75%); background-size: 200% 100%; animation: loading 1.5s infinite; border-radius: 20px; display: flex; flex-direction: column; height: 100%; }
    @keyframes loading { 0% { background-position: 200% 0; } 100% { background-position: -200% 0; } }
    .skeleton-img { height: 250px; flex-shrink: 0; border-radius: 20px 20px 0 0; background: linear-gradient(90deg, #f0f0f0 25%, #e0e0e0 50%, #f0f0f0 75%); background-size: 200% 100%; animation: loading 1.5s infinite; }
    @media (max-width: 768px) { .skeleton-img { height: 200px; } }
    .skeleton-text { height: 20px; width: 80%; margin-bottom: 0.5rem; border-radius: 4px; background: #e0e0e0; }
    .skeleton-price { height: 24px; width: 60%; background: #e0e0e0; border-radius: 4px; margin-bottom: 1rem; }
    .skeleton-btn { height: 40px; border-radius: 25px; margin: 0.25rem 0; flex: 1; background: #e0e0e0; }
    /* Footer Modern */
    footer { background: linear-gradient(135deg, #333, #555); color: #fff; text-align: center; padding: 3rem 1rem; margin-top: 5rem; }
    .social-links a { color: #fff; font-size: 1.5rem; margin: 0 1rem; transition: color 0.3s; }
    .social-links a:hover { color: #d83a4a; }
    /* Responsive (Rapih Mobile) */
    @media (max-width: 992px) { .sidebar { position: static; margin-top: 2rem; } }
    @media (max-width: 768px) { 
      .hero-overlay h1 { font-size: 1.8rem; } 
      .search-form { flex-direction: column; } 
      .search-btn { border-radius: 0 0 50px 50px; } 
      .category-btn { padding: 0.5rem 1rem; font-size: 0.9rem; } 
      .product-body { padding: 1rem; } /* Kurangi padding mobile agar rapih */
    }
  </style>
</head>
<body>

<!-- Navbar Bootstrap Modern (Dengan Dropdown Profil) -->
<nav class="navbar navbar-expand-lg navbar-custom fixed-top">
  <div class="container">
    <a class="navbar-brand" href="index.php">
      <i class="fas fa-home me-2"></i>Ruang Sukma
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
        <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link active" href="index.php"><i class="fas fa-home me-1"></i>Home</a></li>
        <li class="nav-item"><a class="nav-link" href="index.php"><i class="fas fa-box me-1"></i>Produk</a></li>
        <li class="nav-item position-relative">
          <a class="nav-link" href="cart.php">
            <i class="fas fa-shopping-cart me-1"></i>Keranjang
            <?php if(isset($_SESSION['cart']) && count($_SESSION['cart']) > 0): ?>
              <span class="cart-badge"><?php echo count($_SESSION['cart']); ?></span>
            <?php endif; ?>
          </a>
        </li>
        <!-- Dropdown Profil User (Baru Ditambahkan) -->
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            <i class="fas fa-user-circle me-1"></i>
            Halo, <?= htmlspecialchars($user_name ?? 'User ') ?>!
          </a>
          <ul class="dropdown-menu dropdown-menu-end">
            <li><a class="dropdown-item" href="profil_user.php"><i class="fas fa-user me-2"></i>Profil Saya</a></li>
            <li><a class="dropdown-item" href="ubah_password.php"><i class="fas fa-key me-2"></i>Ubah Password</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item text-danger" href="logout_user.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
          </ul>
        </li>
      </ul>
    </div>
  </div>
</nav>

<!-- Hero Statis Sederhana (Merah Merah, Tanpa Gambar) -->
<section class="hero-section">
  <div class="hero-overlay">
    <h1>Selamat Datang di Ruang Sukma</h1>
    <p>Temukan barang yang anda butuhkan</p>
    <a href="#produk" class="hero-btn">Lihat Produk</a>
  </div>
</section>

<!-- Search Section Modern -->
<section class="search-section" data-aos="fade-up">
  <form method="GET" class="search-form d-flex">
    <input type="text" name="search" class="search-input form-control" placeholder="Cari produk, kategori, atau merek..." value="<?php echo htmlspecialchars($search); ?>">
    <button type="submit" class="search-btn">
      <i class="fas fa-search me-2"></i>Cari
    </button>
  </form>
</section>

<!-- Category Filter Modern -->
<section class="category-section" data-aos="fade-up">
  <div class="container">
    <div class="category-filter">
      <button class="category-btn <?php echo ($kategori === '') ? 'active' : ''; ?>" onclick="filterCategory('')">
        <i class="fas fa-th-large me-1"></i>Semua
      </button>
      <?php
      if (mysqli_num_rows($kategori_query) > 0) {
          mysqli_data_seek($kategori_query, 0); // Reset pointer untuk loop
          while ($cat = mysqli_fetch_assoc($kategori_query)) {
              $is_active = ($kategori === $cat['category_name']) ? 'active' : '';
              echo '<button class="category-btn ' . $is_active . '" onclick="filterCategory(\'' . htmlspecialchars($cat['category_name']) . '\')">
                      <i class="fas fa-tag me-1"></i>' . htmlspecialchars($cat['category_name']) . '
                    </button>';
          }
      } else {
          echo '<button class="category-btn" disabled><i class="fas fa-tag me-1"></i>Tidak Ada Kategori</button>';
      }
      ?>
    </div>
  </div>
</section>

<!-- Product Section Modern (Grid + Sidebar) -->
<section class="container-fluid py-5" id="produk" data-aos="fade-up">
  <div class="row">
    <!-- Main Grid (9 kolom desktop) -->
    <div class="col-lg-9">
      <div class="row g-4">
        <?php if ($num_produk > 0): ?>
          <?php while ($produk = mysqli_fetch_assoc($produk_query)): ?>
            <div class="col-md-4 col-sm-6" data-aos="fade-up" data-aos-delay="100">
              <div class="product-card h-100">
                <?php if (rand(0, 1)): ?>
                  <span class="product-badge">HOT</span>
                <?php else: ?>
                  <span class="product-badge bg-warning text-dark">NEW</span>
                <?php endif; ?>
                <img src="produk/<?php echo htmlspecialchars($produk['product_image'] ?? 'default.jpg'); ?>" alt="<?php echo htmlspecialchars($produk['product_name']); ?>" class="product-img" onerror="this.src='https://via.placeholder.com/300x250/d83a4a/ffffff?text=No+Image'">
                <div class="product-body">
                  <h5 class="product-name"><?php echo htmlspecialchars($produk['product_name']); ?></h5>
                  <div class="product-price">Rp <?php echo number_format($produk['product_price'], 0, ',', '.'); ?></div>
                  <p class="product-desc"><?php echo substr(htmlspecialchars($produk['product_description'] ?? 'Deskripsi produk akan ditampilkan di sini.'), 0, 100) . '...'; ?></p>
                  <div class="d-flex gap-2">
                    <a href="detail.php?id=<?php echo $produk['product_id']; ?>" class="btn-detail">Detail</a>
                    <a href="tambah_cart.php?id=<?php echo $produk['product_id']; ?>&qty=1" class="btn-cart" onclick="return confirm('Tambah ke keranjang?')">Keranjang</a>
                  </div>
                </div>
              </div>
            </div>
          <?php endwhile; ?>
        <?php else: ?>
          <!-- Skeleton Loader jika 0 produk -->
          <?php for ($i = 0; $i < 6; $i++): ?>
            <div class="col-md-4 col-sm-6" data-aos="fade-up" data-aos-delay="100">
              <div class="product-card h-100 skeleton">
                <div class="skeleton-img"></div>
                <div class="product-body">
                  <div class="skeleton-text"></div>
                  <div class="skeleton-price"></div>
                  <div class="d-flex gap-2">
                    <div class="skeleton-btn"></div>
                    <div class="skeleton-btn"></div>
                  </div>
                </div>
              </div>
            </div>
          <?php endfor; ?>
          <div class="col-12 text-center mt-4">
            <p class="text-muted fs-5">Tidak ada produk ditemukan. Coba cari yang lain!</p>
          </div>
        <?php endif; ?>
      </div>
    </div>
    <!-- Sidebar Featured (3 kolom desktop) -->
    <div class="col-lg-3 sidebar">
      <h5><i class="fas fa-star me-2"></i>Produk Unggulan</h5>
      <?php
      if (mysqli_num_rows($featured_query) > 0) {
          mysqli_data_seek($featured_query, 0); // Reset pointer
          while ($feat = mysqli_fetch_assoc($featured_query)) {
              echo '<div class="sidebar-product">
                      <img src="produk/' . htmlspecialchars($feat['product_image'] ?? 'default.jpg') . '" alt="' . htmlspecialchars($feat['product_name']) . '" class="sidebar-img" onerror="this.src=\'https://via.placeholder.com/70x70/d83a4a/ffffff?text=P\'">
                      <div>
                        <div class="sidebar-name">' . htmlspecialchars(substr($feat['product_name'], 0, 30)) . '...</div>
                        <div class="sidebar-price">Rp ' . number_format($feat['product_price'], 0, ',', '.') . '</div>
                        <a href="detail.php?id=' . $feat['product_id'] . '" class="btn btn-sm btn-detail mt-1">Lihat</a>
                      </div>
                    </div>';
          }
      } else {
          echo '<p class="text-muted">Tidak ada produk unggulan.</p>';
      }
      ?>
    </div>
  </div>
</section>

<!-- Footer Modern -->
<footer class="text-center py-5" data-aos="fade-up">
  <div class="container">
    <div class="row">
      <div class="col-md-6">
        <h5 class="text-white mb-3">Ruang Sukma</h5>
        <p class="text-light">Toko online terpercaya untuk kebutuhan rumah tangga dan kantor. Kualitas terbaik, harga terjangkau.</p>
      </div>
      <div class="col-md-6">
        <h5 class="text-white mb-3">Hubungi Kami</h5>
        <p class="text-light">Email: info@ruangsukma.com | Telp: (021) 123-4567</p>
        <div class="social-links">
          <a href="#"><i class="fab fa-facebook-f"></i></a>
          <a href="#"><i class="fab fa-instagram"></i></a>
          <a href="#"><i class="fab fa-twitter"></i></a>
          <a href="#"><i class="fab fa-whatsapp"></i></a>
        </div>
      </div>
    </div>
    <hr class="my-4 border-light">
    <p class="text-light mb-0">&copy; 2024 Ruang Sukma. All rights reserved. | <a href="tentang.php" class="text-light">Tentang Kami</a></p>
  </div>
</footer>

<!-- Scripts Modern -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
<script>
  AOS.init({ duration: 1000, once: true, offset: 100 });

  // Filter Kategori (Update URL tanpa reload penuh)
  function filterCategory(cat) {
    const url = new URL(window.location);
    if (cat === '') {
      url.searchParams.delete('kategori');
    } else {
      url.searchParams.set('kategori', cat);
    }
    url.searchParams.delete('search'); // Reset search jika filter kategori
    window.location.href = url.toString();
    
    // Update active class
    document.querySelectorAll('.category-btn').forEach(btn => btn.classList.remove('active'));
    event.target.classList.add('active');
  }

  // Smooth scroll ke #produk
  document.querySelectorAll('a[href="#produk"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
      e.preventDefault();
      document.querySelector('#produk').scrollIntoView({ behavior: 'smooth' });
    });
  });

  // Auto-hide skeleton setelah load (jika ada)
  window.addEventListener('load', () => {
    setTimeout(() => {
      document.querySelectorAll('.skeleton').forEach(el => {
        el.style.animation = 'none';
        el.style.background = '#f8f9fa';
      });
    }, 1500);
  });
</script>

</body>
</html>
<?php
// Tutup koneksi DB
mysqli_close($conn);
?>