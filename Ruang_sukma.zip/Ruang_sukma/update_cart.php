<?php
session_start();

if(isset($_POST['qty'])){
    foreach($_POST['qty'] as $id => $q){
        $id = (int)$id;
        $q  = (int)$q;
        if($q > 0){
            $_SESSION['cart'][$id] = $q;
        } else {
            unset($_SESSION['cart'][$id]);
        }
    }
}
header("Location: cart.php");
