<?php
session_start();
include 'db.php'; // Pastikan db.php ada dan $conn valid

// Cek jika request POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo 'Error: Method tidak diizinkan';
    exit;
}

// Ambil data dari POST
$id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
$qty = isset($_POST['qty']) ? (int)$_POST['qty'] : 1;

if ($id <= 0 || $qty < 1) {
    echo 'Error: ID produk atau qty tidak valid';
    exit;
}

// Cek apakah produk ada di DB (aktif)
$check_q = mysqli_query($conn, "SELECT product_id FROM tb_product WHERE product_id = {$id} AND product_status = 1");
if (!$check_q || mysqli_num_rows($check_q) == 0) {
    echo 'Error: Produk tidak ditemukan atau tidak aktif';
    exit;
}

// Inisialisasi sesi cart jika belum ada (struktur array kosong)
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Tambah atau update qty (struktur sub-array: ['qty' => value])
if (isset($_SESSION['cart'][$id])) {
    $_SESSION['cart'][$id]['qty'] += $qty; // Tambah qty jika sudah ada
} else {
    $_SESSION['cart'][$id] = ['qty' => $qty]; // Tambah baru
}

// Optional: Cek stok jika ada field 'stok' di tb_product (asumsi ada)
// $stok_q = mysqli_query($conn, "SELECT stok FROM tb_product WHERE product_id = {$id}");
// if ($stok_q && $row = mysqli_fetch_assoc($stok_q)) {
//     $stok = (int)$row['stok'];
//     if ($_SESSION['cart'][$id]['qty'] > $stok) {
//         $_SESSION['cart'][$id]['qty'] = $stok;
//         echo 'Warning: Stok terbatas, qty disesuaikan ke ' . $stok;
//         exit;
//     }
// }

echo 'sukses'; // Response untuk JS di detail.php

mysqli_close($conn);
?>