<?php
session_start(); // ✅ perbaikan dari session_star()

session_destroy(); 
header("Location: login.php");
exit;
?>
