<?php
// orders.php - Riwayat Pesanan User
session_start();
include 'db.php';

// Jika belum login, redirect ke login
if (!isset($_SESSION['user_login']) || $_SESSION['user_login'] !== true || !isset($_SESSION['user_id'])) {
    header("Location: login_user.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// Ambil data nama user untuk navbar (mirip index.php)
$user_name = $_SESSION['user_name'] ?? null;
if (!$user_name) {
    $stmt_name = mysqli_prepare($conn, "SELECT nama FROM tb_user WHERE id = ?");
    mysqli_stmt_bind_param($stmt_name, "i", $user_id);
    mysqli_stmt_execute($stmt_name);
    $result_name = mysqli_stmt_get_result($stmt_name);
    if ($result_name && mysqli_num_rows($result_name) > 0) {
        $user_data = mysqli_fetch_assoc($result_name);
        $user_name = $user_data['nama'];
        $_SESSION['user_name'] = $user_name;
    }
    mysqli_stmt_close($stmt_name);
}

// Query riwayat pesanan user (JOIN dengan detail untuk tampilkan produk)
$orders_query = "
SELECT 
    o.order_id,
    o.total_amount,
    o.status,
    o.order_date,
    GROUP_CONCAT(CONCAT(p.product_name, ' (', d.quantity, ')') SEPARATOR ', ') AS produk_details
FROM tb_order o
JOIN tb_order_detail d ON o.order_id = d.order_id
JOIN tb_product p ON d.product_id = p.product_id
WHERE o.user_id = ?
GROUP BY o.order_id, o.total_amount, o.status, o.order_date
ORDER BY o.order_date DESC
";

$stmt_orders = mysqli_prepare($conn, $orders_query);
mysqli_stmt_bind_param($stmt_orders, "i", $user_id);
mysqli_stmt_execute($stmt_orders);
$result_orders = mysqli_stmt_get_result($stmt_orders);
$num_orders = mysqli_num_rows($result_orders);
mysqli_stmt_close($stmt_orders);
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Riwayat Pesanan - Ruang Sukma</title>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Google Fonts: Poppins -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <!-- Font Awesome -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
  <!-- AOS Animations (opsional, mirip index.php) -->
  <link href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css" rel="stylesheet">
  <style>
    body {
      font-family: 'Poppins', sans-serif;
      background: linear-gradient(135deg, #f4f6f8, #e9ecef);
      color: #333;
      line-height: 1.6;
      padding-top: 80px; /* Ruang untuk navbar fixed */
    }
    a { text-decoration: none; }
    /* Navbar Modern (Mirip index.php) */
    .navbar-custom {
      background: rgba(216, 58, 74, 0.95) !important;
      backdrop-filter: blur(20px);
      box-shadow: 0 4px 20px rgba(216, 58, 74, 0.2);
      padding: 1rem 0;
    }
    .navbar-brand {
      font-weight: 700; font-size: 1.8rem; color: #fff !important;
    }
    .nav-link { color: #fff !important; font-weight: 500; padding: 0.5rem 1rem; }
    .nav-link:hover { color: #f8f9fa !important; }
    /* Dropdown Profil Styling (Mirip index.php) */
    .dropdown-menu {
      border: none;
      box-shadow: 0 10px 30px rgba(216, 58, 74, 0.2);
      border-radius: 15px;
      background: #fff;
    }
    .dropdown-item {
      color: #333;
      padding: 0.75rem 1.5rem;
      transition: background 0.3s;
    }
    .dropdown-item:hover {
      background: rgba(216, 58, 74, 0.1);
      color: #d83a4a;
    }
    .dropdown-item i { margin-right: 0.5rem; }
    /* Hero/Section Header */
    .orders-header {
      background: linear-gradient(135deg, #d83a4a, #c0392b);
      color: #fff;
      padding: 4rem 0;
      text-align: center;
      margin-bottom: 2rem;
    }
    .orders-header h1 {
      font-size: 2.5rem; font-weight: 700; margin-bottom: 1rem;
    }
    .orders-header p { font-size: 1.1rem; }
    /* Tombol Kembali (Baru Ditambahkan - Mirip profil_user.php) */
    .back-btn {
      background: #6c757d;
      color: #fff;
      border: none;
      padding: 0.75rem 1.5rem;
      border-radius: 25px;
      font-weight: 500;
      transition: all 0.3s;
      text-decoration: none;
      display: inline-block;
      margin-bottom: 1rem;
    }
    .back-btn:hover {
      background: #5a6268;
      color: #fff;
      transform: translateY(-2px);
    }
    /* Orders Table/Card Styling */
    .orders-section { max-width: 1000px; margin: 0 auto; padding: 0 1rem; }
    .orders-card {
      background: #fff; border-radius: 20px; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.1);
      margin-bottom: 1.5rem; transition: all 0.3s;
    }
    .orders-card:hover { transform: translateY(-5px); box-shadow: 0 15px 40px rgba(0,0,0,0.15); }
    .orders-header-card { background: linear-gradient(135deg, #d83a4a, #c0392b); color: #fff; padding: 1.5rem; }
    .orders-header-card h5 { margin: 0; font-weight: 600; }
    .orders-body { padding: 1.5rem; }
    .order-item { display: flex; justify-content: space-between; align-items: center; padding: 1rem 0; border-bottom: 1px solid #eee; }
    .order-item:last-child { border-bottom: none; }
    .order-details { flex-grow: 1; }
    .order-id { font-weight: 600; color: #d83a4a; }
    .order-date { color: #666; font-size: 0.9rem; }
    .order-produk { color: #333; margin: 0.5rem 0; }
    .order-total { font-weight: 700; color: #18a74a; font-size: 1.1rem; }
    .status-badge {
      padding: 0.5rem 1rem; border-radius: 20px; font-weight: 500; font-size: 0.85rem;
    }
    .status-pending { background: #fff3cd; color: #856404; }
    .status-processing { background: #d1ecf1; color: #0c5460; }
    .status-completed { background: #d4edda; color: #155724; }
    .btn-detail-order {
      background: linear-gradient(135deg, #007bff, #0056b3); color: #fff; border: none;
      padding: 0.75rem 1.5rem; border-radius: 25px; font-weight: 500; transition: all 0.3s;
    }
    .btn-detail-order:hover { background: linear-gradient(135deg, #0056b3, #004085); transform: scale(1.05); }
    /* Empty State */
    .empty-state {
      text-align: center; padding: 3rem; color: #666;
    }
    .empty-state i { font-size: 4rem; margin-bottom: 1rem; opacity: 0.5; }
    /* Responsive */
    @media (max-width: 768px) {
      .orders-header h1 { font-size: 2rem; }
      .order-item { flex-direction: column; align-items: flex-start; gap: 0.5rem; }
      .orders-body { padding: 1rem; }
      .back-btn { width: 100%; text-align: center; }
    }
  </style>
</head>
<body>

<!-- Navbar Bootstrap Modern (Mirip index.php dengan Dropdown Profil) -->
<nav class="navbar navbar-expand-lg navbar-custom fixed-top">
  <div class="container">
    <a class="navbar-brand" href="index.php">
      <i class="fas fa-home me-2"></i>Ruang Sukma
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link" href="index.php"><i class="fas fa-home me-1"></i>Home</a></li>
        <li class="nav-item"><a class="nav-link" href="index.php"><i class="fas fa-box me-1"></i>Produk</a></li>
        <li class="nav-item position-relative">
          <a class="nav-link" href="cart.php">
            <i class="fas fa-shopping-cart me-1"></i>Keranjang
            <?php if(isset($_SESSION['cart']) && count($_SESSION['cart']) > 0): ?>
              <span class="badge bg-light text-dark rounded-pill ms-1"><?php echo count($_SESSION['cart']); ?></span>
            <?php endif; ?>
          </a>
        </li>
        <!-- Dropdown Profil User -->
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            <i class="fas fa-user-circle me-1"></i>
            Halo, <?= htmlspecialchars($user_name ?? 'User  ') ?>!
          </a>
          <ul class="dropdown-menu dropdown-menu-end">
            <li><a class="dropdown-item" href="profil_user.php"><i class="fas fa-user me-2"></i>Profil Saya</a></li>
            <li><a class="dropdown-item" href="ubah_password.php"><i class="fas fa-key me-2"></i>Ubah Password</a></li>
            <li><a class="dropdown-item" href="orders.php"><i class="fas fa-shopping-bag me-2"></i>Riwayat Pesanan</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item text-danger" href="logout_user.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
          </ul>
        </li>
      </ul>
    </div>
  </div>
</nav>

<!-- Header Section -->
<section class="orders-header" data-aos="fade-down">
  <div class="container">
    <h1><i class="fas fa-shopping-bag me-2"></i>Riwayat Pesanan</h1>
    <p>Lihat status pesanan Anda dan detail pembelian sebelumnya.</p>
  </div>
</section>

<!-- Orders Section -->
<section class="orders-section" data-aos="fade-up">
  <!-- TAMBAHAN BARU: Tombol Kembali ke Beranda (Mirip profil_user.php) -->
  <div class="text-center mb-3">
    <a href="index.php" class="back-btn">
      <i class="fas fa-arrow-left me-2"></i>Kembali ke Beranda
    </a>
  </div>
  
  <?php if ($num_orders > 0): ?>
    <?php while ($order = mysqli_fetch_assoc($result_orders)): ?>
      <div class="orders-card">
        <div class="orders-header-card">
          <div class="d-flex justify-content-between align-items-center">
            <h5 class="mb-0">
              <i class="fas fa-hashtag me-2"></i>Order #<?= htmlspecialchars($order['order_id']) ?>
            </h5>
            <span class="status-badge status-<?= htmlspecialchars($order['status']) ?>">
              <?= ucfirst(htmlspecialchars($order['status'])) ?>
            </span>
          </div>
          <small class="d-block mt-1 opacity-75">
            <i class="fas fa-calendar me-1"></i><?= date('d M Y H:i', strtotime($order['order_date'])) ?>
          </small>
        </div>
        <div class="orders-body">
          <div class="order-item">
            <div class="order-details">
              <div class="order-produk">
                <i class="fas fa-box me-1"></i>Produk: <?= htmlspecialchars($order['produk_details'] ?? 'Tidak ada detail') ?>
              </div>
            </div>
            <div class="text-end">
              <div class="order-total">Rp <?= number_format($order['total_amount'], 0, ',', '.') ?></div>
              <a href="order_detail.php?id=<?= $order['order_id'] ?>" class="btn btn-detail-order mt-2">
                <i class="fas fa-eye me-1"></i>Lihat Detail
              </a>
            </div>
          </div>
        </div>
      </div>
    <?php endwhile; ?>
  <?php else: ?>
    <div class="orders-card empty-state">
      <i class="fas fa-shopping-cart"></i>
      <h5 class="mt-3">Belum Ada Pesanan</h5>
      <p class="mb-4">Mulai belanja sekarang untuk melihat riwayat pesanan Anda di sini.</p>
      <a href="index.php" class="btn btn-detail-order">
        <i class="fas fa-shopping-bag me-1"></i>Mulai Belanja
      </a>
    </div>
  <?php endif; ?>
</section>

<!-- Footer Modern (Mirip index.php) -->
<footer class="text-center py-5 mt-5" style="background: linear-gradient(135deg, #333, #555); color: #fff;">
  <div class="container">
    <div class="row">
      <div class="col-md-6">
        <h5 class="text-white mb-3">Ruang Sukma</h5>
        <p class="text-light">Toko online terpercaya untuk kebutuhan rumah tangga dan kantor. Kualitas terbaik, harga terjangkau.</p>
      </div>
      <div class="col-md-6">
        <h5 class="text-white mb-3">Hubungi Kami</h5>
        <p class="text-light">Email: info@ruangsukma.com | Telp: (021) 123-4567</p>
        <div class="social-links d-flex justify-content-center gap-3">
          <a href="#" style="color: #fff; font-size: 1.5rem;"><i class="fab fa-facebook-f"></i></a>
          <a href="#" style="color: #fff; font-size: 1.5rem;"><i class="fab fa-instagram"></i></a>
          <a href="#" style="color: #fff; font-size: 1.5rem;"><i class="fab fa-twitter"></i></a>
          <a href="#" style="color: #fff; font-size: 1.5rem;"><i class="fab fa-whatsapp"></i></a>
        </div>
      </div>
    </div>
    <hr class="my-4 border-light">
    <p class="text-light mb-0">&copy; 2024 Ruang Sukma. All rights reserved.</p>
  </div>
</footer>

<!-- Scripts -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
<script>
  AOS.init({ duration: 1000, once: true, offset: 100 });
</script>

</body>
</html>
<?php
mysqli_close($conn);
?>