<?php
   session_start();
   include 'db.php';
   if($_SESSION['status_login'] != true){
      echo '<script>window.location="login.php"</script>';
   }

   if(isset($_GET['id'])){
      $id = $_GET['id'];
      $delete = mysqli_query($conn, "DELETE FROM tb_category WHERE category_id = '".$id."' ");
      
      if($delete){
         echo '<script>alert("Data berhasil dihapus")</script>';
      } else {
         echo '<script>alert("Gagal menghapus data: '.mysqli_error($conn).'")</script>';
      }

      echo '<script>window.location="data-kategori.php"</script>';
   } else {
      echo '<script>window.location="data-kategori.php"</script>';
   }
?>
