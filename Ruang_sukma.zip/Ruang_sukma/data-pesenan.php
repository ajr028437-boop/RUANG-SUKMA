<?php
session_start();
include 'db.php';

if ($_SESSION['status_login'] != true) {
    header("Location: login.php");
    exit;
}

if (!isset($_SESSION['admin_messages'])) {
    $_SESSION['admin_messages'] = [];
}

// Function untuk hitung ongkir berdasarkan alamat (sama seperti di halaman user sukses)
function hitungOngkir($alamat) {
    if (empty($alamat) || strlen(trim($alamat)) < 10) {
        return 0; // Alamat terlalu pendek/kosong
    }
    $lower_alamat = strtolower(trim($alamat));
    if (strpos($lower_alamat, 'tasik') !== false || strpos($lower_alamat, 'unsil') !== false || 
        strpos($lower_alamat, 'katumbiri') !== false || strpos($lower_alamat, 'indihiang') !== false) {
        return 15000;
    } elseif (strpos($lower_alamat, 'bandung') !== false || strpos($lower_alamat, 'cirebon') !== false || 
              strpos($lower_alamat, 'garut') !== false) {
        return 30000;
    } elseif (strpos($lower_alamat, 'jakarta') !== false || strpos($lower_alamat, 'bekasi') !== false || 
              strpos($lower_alamat, 'bogor') !== false) {
        return 50000;
    } else {
        return 20000; // Default
    }
}

// Handling Update Status (sama seperti lama, tidak diubah)
if (isset($_POST['update_status'])) {
    $order_id = intval($_POST['order_id']);
    $status = $_POST['status'];

    // Validasi status saat ini untuk mencegah mundur
    $current_status_query = "SELECT status FROM tb_order WHERE order_id = ?";
    $stmt_current = mysqli_prepare($conn, $current_status_query);
    mysqli_stmt_bind_param($stmt_current, "i", $order_id);
    mysqli_stmt_execute($stmt_current);
    $result_current = mysqli_stmt_get_result($stmt_current);
    $current_row = mysqli_fetch_assoc($result_current);
    $current_status = $current_row['status'] ?? 'pending';
    mysqli_stmt_close($stmt_current);

    $allowed_statuses = ['pending', 'processing', 'completed'];
    if ($current_status === 'processing') {
        $allowed_statuses = ['processing', 'completed'];
    } elseif ($current_status === 'completed') {
        $allowed_statuses = ['completed'];
    }

    if (in_array($status, $allowed_statuses)) {
        $update_query = "UPDATE tb_order SET status = ? WHERE order_id = ?";
        $stmt = mysqli_prepare($conn, $update_query);
        mysqli_stmt_bind_param($stmt, "si", $status, $order_id);

        if (mysqli_stmt_execute($stmt)) {
            mysqli_stmt_close($stmt);

            // Email notifikasi (sama seperti lama)
            $get_user_query = "SELECT u.email, u.nama FROM tb_order o JOIN tb_user u ON o.user_id = u.id WHERE o.order_id = ?";
            $stmt_user = mysqli_prepare($conn, $get_user_query);
            mysqli_stmt_bind_param($stmt_user, "i", $order_id);
            mysqli_stmt_execute($stmt_user);
            $result_user = mysqli_stmt_get_result($stmt_user);

            if ($user_row = mysqli_fetch_assoc($result_user)) {
                $email = $user_row['email'];
                $nama = $user_row['nama'];

                // Fallback ke mail() (PHPMailer dikomentari seperti lama)
                $status_display = ucfirst($status);
                $subject = "Update Status Pesanan - Ruang Sukma";
                $message = "Halo {$nama},\n\nStatus pesanan #{$order_id} Anda telah diupdate menjadi: {$status_display}.\n\nTerima kasih telah berbelanja di Ruang Sukma!\nJika ada pertanyaan, hubungi kami di admin@ruangsukma.com.\n\nSalam hangat,\nTim Ruang Sukma";
                $headers = "From: admin@ruangsukma.com\r\nReply-To: admin@ruangsukma.com\r\nContent-Type: text/plain; charset=UTF-8\r\n";
                if (mail($email, $subject, $message, $headers)) {
                    $_SESSION['admin_messages'][] = ['type' => 'success', 'text' => "Status diupdate ke '" . ucfirst($status) . "' dan email terkirim! User akan lihat update otomatis di detail pesanan."];
                } else {
                    $_SESSION['admin_messages'][] = ['type' => 'warning', 'text' => "Status diupdate ke '" . ucfirst($status) . "', tapi email gagal. User tetap dapat update via polling."];
                }
            } else {
                $_SESSION['admin_messages'][] = ['type' => 'warning', 'text' => "Status diupdate ke '" . ucfirst($status) . "', tapi user tidak ditemukan untuk notifikasi."];
            }
            mysqli_stmt_close($stmt_user);
        } else {
            $_SESSION['admin_messages'][] = ['type' => 'danger', 'text' => 'Gagal update status: ' . mysqli_error($conn)];
        }
    } else {
        $_SESSION['admin_messages'][] = ['type' => 'danger', 'text' => 'Update tidak valid: Tidak bisa mundur ke status sebelumnya (misal dari processing ke pending).'];
    }

    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

// Handling Hapus Pesanan (sama seperti lama, tapi sekarang izinkan hapus completed)
if (isset($_POST['hapus'])) {
    $order_id = intval($_POST['order_id']);

    $delete_detail = "DELETE FROM tb_order_detail WHERE order_id = ?";
    $stmt_detail = mysqli_prepare($conn, $delete_detail);
    mysqli_stmt_bind_param($stmt_detail, "i", $order_id);
    mysqli_stmt_execute($stmt_detail);
    mysqli_stmt_close($stmt_detail);

    $delete_order = "DELETE FROM tb_order WHERE order_id = ?";
    $stmt_order = mysqli_prepare($conn, $delete_order);
    mysqli_stmt_bind_param($stmt_order, "i", $order_id);

    if (mysqli_stmt_execute($stmt_order)) {
        mysqli_stmt_close($stmt_order);
        $_SESSION['admin_messages'][] = ['type' => 'success', 'text' => 'Pesanan #'.$order_id.' dihapus!'];
    } else {
        $_SESSION['admin_messages'][] = ['type' => 'danger', 'text' => 'Gagal hapus pesanan: ' . mysqli_error($conn)];
    }

    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

// Handling Filter dan Sorting
$filter_status = $_GET['status'] ?? '';
$date_from = $_GET['date_from'] ?? '';
$date_to = $_GET['date_to'] ?? '';
$sort_by = $_GET['sort_by'] ?? 'order_date';
$order = $_GET['order'] ?? 'DESC';

// Pagination
$limit = 10; // Jumlah data per halaman
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$page = max(1, $page); // Pastikan page minimal 1
$offset = ($page - 1) * $limit;

// Query untuk hitung total records (untuk pagination)
$total_query = "
SELECT COUNT(DISTINCT o.order_id) AS total
FROM tb_order o
JOIN tb_user u ON o.user_id = u.id
JOIN tb_order_detail d ON o.order_id = d.order_id
JOIN tb_product p ON d.product_id = p.product_id
WHERE 1=1
";

// Tambahkan filter ke total_query
if (!empty($filter_status)) {
    $total_query .= " AND o.status = '" . mysqli_real_escape_string($conn, $filter_status) . "'";
}
if (!empty($date_from)) {
    $total_query .= " AND DATE(o.order_date) >= '" . mysqli_real_escape_string($conn, $date_from) . "'";
}
if (!empty($date_to)) {
    $total_query .= " AND DATE(o.order_date) <= '" . mysqli_real_escape_string($conn, $date_to) . "'";
}

$total_result = $conn->query($total_query);
$total_row = $total_result->fetch_assoc();
$total_records = $total_row['total'] ?? 0;
$total_pages = ceil($total_records / $limit);

// Query utama: Diubah ke per ORDER (GROUP BY), dengan subtotal, ongkir dihitung, alamat dari tb_order
$query = "
SELECT 
    o.order_id, o.total_amount, o.status, o.order_date, o.alamat, o.phone,
    u.nama, u.email,
    GROUP_CONCAT(CONCAT(p.product_name, ' (', d.quantity, ' x Rp ', FORMAT(p.product_price, 0, 'de_DE'), ')') SEPARATOR '<br>') AS produk_details,
    SUM(d.quantity * p.product_price) AS subtotal_barang
FROM tb_order o
JOIN tb_user u ON o.user_id = u.id
JOIN tb_order_detail d ON o.order_id = d.order_id
JOIN tb_product p ON d.product_id = p.product_id
WHERE 1=1
";

// Tambahkan filter
if (!empty($filter_status)) {
    $query .= " AND o.status = '" . mysqli_real_escape_string($conn, $filter_status) . "'";
}
if (!empty($date_from)) {
    $query .= " AND DATE(o.order_date) >= '" . mysqli_real_escape_string($conn, $date_from) . "'";
}
if (!empty($date_to)) {
    $query .= " AND DATE(o.order_date) <= '" . mysqli_real_escape_string($conn, $date_to) . "'";
}

$query .= " GROUP BY o.order_id, o.total_amount, o.status, o.order_date, o.alamat, o.phone, u.nama, u.email";

// Sorting
$valid_sort_columns = ['order_id', 'order_date', 'nama', 'email', 'total_amount', 'status'];
if (in_array($sort_by, $valid_sort_columns)) {
    $query .= " ORDER BY " . $sort_by . " " . ($order === 'ASC' ? 'ASC' : 'DESC');
} else {
    $query .= " ORDER BY o.order_date DESC";
}

// Tambahkan LIMIT dan OFFSET untuk pagination
$query .= " LIMIT $limit OFFSET $offset";

$result = $conn->query($query);
if (!$result) {
    $_SESSION['admin_messages'][] = ['type' => 'danger', 'text' => 'Error query: ' . $conn->error];
    $result = false;
}

// Query Statistik
$stats_query = "
SELECT 
    COUNT(*) AS total_pesanan,
    SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) AS pending,
    SUM(CASE WHEN status = 'processing' THEN 1 ELSE 0 END) AS processing,
    SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) AS completed,
    SUM(total_amount) AS total_pendapatan
FROM tb_order
WHERE 1=1
";
if (!empty($filter_status)) {
    $stats_query .= " AND status = '" . mysqli_real_escape_string($conn, $filter_status) . "'";
}
if (!empty($date_from)) {
    $stats_query .= " AND DATE(order_date) >= '" . mysqli_real_escape_string($conn, $date_from) . "'";
}
if (!empty($date_to)) {
    $stats_query .= " AND DATE(order_date) <= '" . mysqli_real_escape_string($conn, $date_to) . "'";
}

$stats_result = $conn->query($stats_query);
$stats = $stats_result ? $stats_result->fetch_assoc() : ['total_pesanan' => 0, 'pending' => 0, 'processing' => 0, 'completed' => 0, 'total_pendapatan' => 0];

// Export CSV: Diupdate include subtotal, ongkir, alamat dari order
if (isset($_GET['export']) && $_GET['export'] == 'excel') {
    $export_query = "
    SELECT 
        o.order_id, o.total_amount, o.status, o.order_date, o.alamat, o.phone,
        u.nama, u.email,
        GROUP_CONCAT(CONCAT(p.product_name, ' (', d.quantity, ')') SEPARATOR ', ') AS produk_details,
        SUM(d.quantity * p.product_price) AS subtotal_barang
    FROM tb_order o
    JOIN tb_user u ON o.user_id = u.id
    JOIN tb_order_detail d ON o.order_id = d.order_id
    JOIN tb_product p ON d.product_id = p.product_id
    WHERE 1=1
    ";
    if (!empty($filter_status)) {
        $export_query .= " AND o.status = '" . mysqli_real_escape_string($conn, $filter_status) . "'";
    }
    if (!empty($date_from)) {
        $export_query .= " AND DATE(o.order_date) >= '" . mysqli_real_escape_string($conn, $date_from) . "'";
    }
    if (!empty($date_to)) {
        $export_query .= " AND DATE(o.order_date) <= '" . mysqli_real_escape_string($conn, $date_to) . "'";
    }
    $export_query .= " GROUP BY o.order_id, o.total_amount, o.status, o.order_date, o.alamat, o.phone, u.nama, u.email ORDER BY o.order_date DESC";

    $export_result = $conn->query($export_query);
    if ($export_result) {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=data_pesenan_' . date('Y-m-d') . '.csv');
        $output = fopen('php://output', 'w');

        fputcsv($output, ['ID Order', 'Tanggal Order', 'Nama', 'Email', 'No HP', 'Alamat Pengiriman', 'Detail Produk', 'Subtotal Barang', 'Ongkir', 'Total Order', 'Status']);

        while ($row = $export_result->fetch_assoc()) {
            $alamat = $row['alamat'] ?? (strlen($row['alamat'] ?? '') > 100 ? substr($row['alamat'], 0, 100) . '...' : ($row['alamat'] ?? 'Belum diisi'));
            $ongkir = hitungOngkir($alamat);
            $subtotal = $row['subtotal_barang'] ?? 0;
            fputcsv($output, [
                $row['order_id'],
                date('d-m-Y', strtotime($row['order_date'])),
                $row['nama'],
                $row['email'],
                $row['phone'] ?? $row['no_hp'] ?? 'Belum diisi', // Fallback ke user no_hp jika order.phone kosong
                $alamat,
                $row['produk_details'] ?? 'Tidak ada',
                'Rp ' . number_format($subtotal, 0, ',', '.'),
                'Rp ' . number_format($ongkir, 0, ',', '.'),
                'Rp ' . number_format($row['total_amount'], 0, ',', '.'),
                ucfirst($row['status'])
            ]);
        }
        fclose($output);
    } else {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=error_export.csv');
        echo "Error: " . $conn->error;
    }
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Data Pesanan - Ruang Sukma</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Quicksand&display=swap');
        body { font-family: 'Quicksand', sans-serif; background-color: #f9fafb; margin: 0; min-height: 100vh; }
        .sidebar { min-height: 100vh; background: #d32f2f; color: #fff; padding: 30px 0; box-shadow: 3px 0 8px rgba(0,0,0,0.1); width: 250px; display: flex; flex-direction: column; align-items: center; position: fixed; top: 0; left: 0; z-index: 1000; } /* Tambah z-index dan top/left untuk fixed */
        .sidebar h2 { font-weight: 700; font-size: 1.8rem; margin-bottom: 2rem; letter-spacing: 1px; text-align: center; }
        .sidebar a { color: #fff; font-weight: 600; font-size: 1rem; padding: 12px 25px; border-radius: 10px; margin: 8px 15px; text-decoration: none; width: 100%; transition: background-color 0.3s ease, transform 0.2s ease; display: block; }
        .sidebar a.active, .sidebar a:hover { background: #b71c1c; box-shadow: inset 5px 0 0 0 #ff5252; transform: translateX(5px); text-decoration: none; }
        .content { flex-grow: 1; background-color: #fff; min-height: 100vh; padding: 30px 40px 30px 290px; } /* Padding kiri 290px untuk akomodasi sidebar fixed */
        h2.page-title { margin-bottom: 1.5rem; font-weight: 700; }
        .card { border-radius: 12px; box-shadow: 0 6px 15px rgb(0 0 0 / 0.1); border: none; margin-bottom: 2rem; }
        .card-body { padding: 2rem; }
        table { border-collapse: separate !important; border-spacing: 0 10px !important; width: 100%; table-layout: auto; } /* Auto layout agar tidak sempit */
        thead tr { background-color: #b71c1c !important; color: #fff; border-radius: 12px; }
        thead th { border: none !important; font-weight: 700; font-size: 1rem; padding: 12px 15px; vertical-align: middle; text-align: center; min-width: 100px; } /* Min-width minimal */
        th.alamat-th, th.produk-th { min-width: 200px; } /* Kolom lebar untuk alamat & produk */
                th.harga-th { min-width: 120px; } /* Harga series */
        tbody tr { background-color: #fff; box-shadow: 0 2px 8px rgb(0 0 0 / 0.05); border-radius: 10px; transition: box-shadow 0.3s ease; }
        tbody tr:hover { box-shadow: 0 6px 20px rgb(0 0 0 / 0.12); }
        tbody td { vertical-align: middle; padding: 15px 12px; font-size: 0.95rem; color: #333; border: none !important; text-align: center; word-wrap: break-word; }
        tbody td.text-start { text-align: left; }
        td.alamat-col, td.produk-col { max-width: 250px; word-break: break-word; overflow-wrap: break-word; line-height: 1.4; } /* Lebar lebih untuk alamat & produk, multi-line OK */
        td.harga-col { font-weight: 600; color: #d32f2f; } /* Styling harga */
        .btn-primary, .btn-danger, .btn-success { font-weight: 600; border-radius: 8px; padding: 6px 14px; transition: background-color 0.3s ease, box-shadow 0.3s ease; margin: 2px; }
        .btn-primary { background-color: #e53935; border: none; box-shadow: 0 3px 8px rgb(229 38 16 / 0.4); color: #fff; }
        .btn-primary:hover:not(:disabled) { background-color: #b71c1c; box-shadow: 0 6px 12px rgb(204 0 0 / 0.6); color: #fff; }
        .btn-danger { background-color: #e53935; border: none; box-shadow: 0 3px 8px rgb(229 57 53 / 0.4); color: #fff; }
        .btn-danger:hover:not(:disabled) { background-color: #b71c1c; color: #fff; }
        .btn-sm { padding: 4px 8px; font-size: 0.875rem; }
        select { border-radius: 6px; padding: 4px 8px; margin-right: 5px; border: 1px solid #ddd; }
        .alert { border-radius: 8px; margin-bottom: 1rem; }
        .form-select-sm { width: auto !important; display: inline-block !important; }
        small { font-size: 0.8rem; }
        .summary-section { margin-top: 2rem; } /* Tambahan untuk spacing summary */
        .pagination { justify-content: center; margin-top: 2rem; } /* Styling pagination */
        .pagination .page-link { color: #d32f2f; border-color: #d32f2f; }
        .pagination .page-link:hover { background-color: #d32f2f; color: #fff; }
        .pagination .page-item.active .page-link { background-color: #d32f2f; border-color: #d32f2f; }
        @media (max-width: 768px) {
            .sidebar { width: 100%; min-height: auto; flex-direction: row; justify-content: space-around; padding: 15px 0; position: relative; z-index: 1000; } /* Sidebar mobile tidak fixed, tambah z-index */
            .content { padding: 20px 15px 30px 15px; } /* Reset padding kiri di mobile */
            .sidebar h2 { display: none; }
            .sidebar a { margin: 0 5px; padding: 8px 12px; font-size: 0.9rem; text-align: center; flex-grow: 1; }
            table { font-size: 0.85rem; }
            thead th, tbody td { padding: 10px 8px; }
            .btn-sm { padding: 2px 6px; font-size: 0.8rem; }
            select { width: 100px; margin-bottom: 5px; }
            td.alamat-col, td.produk-col { max-width: 150px; }
            th.alamat-th, th.produk-th { min-width: 150px; }
            /* Di mobile, buat tabel scrollable horizontal jika terlalu lebar */
            .card-body { overflow-x: auto; }
            .pagination { margin-top: 1rem; }
        }

    </style>
</head>
<body>
    
    <div class="d-flex flex-column flex-md-row min-vh-100">
        <!-- Sidebar -->
        <nav class="sidebar d-flex flex-column">
            <h2>Ruang Sukma</h2>
            <a href="dashboard.php" class="nav-link">📊 Dashboard</a>
            <a href="profil.php" class="nav-link">👤 Profil</a>
            <a href="data-kategori.php" class="nav-link">📂 Data Kategori</a>
            <a href="data-produk.php" class="nav-link">📦 Data Produk</a>
            <a href="data-pesenan.php" class="nav-link active">🧾 Data Pesanan</a>
            <a href="data-pendapatan.php" class="nav-link">💰 Data Pendapatan</a>
            <a href="data-pengeluaran.php" class="nav-link">💸 Data Pengeluaran</a>
            <a href="keluar.php" class="nav-link">🚪 Keluar</a>
        </nav>

        <!-- Content -->
        <main class="content">
            <h2 class="page-title">🧾 Data Pesanan</h2>

            <!-- Tampilkan Pesan dari Session -->
            <?php if (!empty($_SESSION['admin_messages'])): ?>
                <?php foreach ($_SESSION['admin_messages'] as $msg): ?>
                    <div class="alert alert-<?= $msg['type'] ?> alert-dismissible fade show" role="alert">
                        <?= htmlspecialchars($msg['text']) ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endforeach; ?>
                <?php unset($_SESSION['admin_messages']); ?>
            <?php endif; ?>

            <!-- Tombol Export -->
            <div class="mb-3">
                <a href="?export=excel" class="btn btn-success">
                    <i class="fas fa-download me-2"></i>Export to Excel
                </a>
            </div>

            <!-- Filter dan Sorting -->
            <div class="mb-3">
                <form method="get" class="row g-3">
                    <div class="col-md-2">
                        <label for="status" class="form-label">Status</label>
                        <select name="status" id="status" class="form-select">
                            <option value="">Semua</option>
                            <option value="pending" <?= $filter_status == 'pending' ? 'selected' : '' ?>>Pending</option>
                            <option value="processing" <?= $filter_status == 'processing' ? 'selected' : '' ?>>Processing</option>
                            <option value="completed" <?= $filter_status == 'completed' ? 'selected' : '' ?>>Completed</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label for="date_from" class="form-label">Dari Tanggal</label>
                        <input type="date" name="date_from" id="date_from" class="form-control" value="<?= htmlspecialchars($date_from) ?>">
                    </div>
                    <div class="col-md-2">
                        <label for="date_to" class="form-label">Sampai Tanggal</label>
                        <input type="date" name="date_to" id="date_to" class="form-control" value="<?= htmlspecialchars($date_to) ?>">
                    </div>
                    <div class="col-md-2">
                        <label for="sort_by" class="form-label">Sort By</label>
                        <select name="sort_by" id="sort_by" class="form-select">
                            <option value="order_date" <?= $sort_by == 'order_date' ? 'selected' : '' ?>>Tanggal Order</option>
                            <option value="order_id" <?= $sort_by == 'order_id' ? 'selected' : '' ?>>ID Order</option>
                            <option value="nama" <?= $sort_by == 'nama' ? 'selected' : '' ?>>Nama</option>
                            <option value="total_amount" <?= $sort_by == 'total_amount' ? 'selected' : '' ?>>Total</option>
                            <option value="status" <?= $sort_by == 'status' ? 'selected' : '' ?>>Status</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label for="order" class="form-label">Order</label>
                        <select name="order" id="order" class="form-select">
                            <option value="DESC" <?= $order == 'DESC' ? 'selected' : '' ?>>Descending</option>
                            <option value="ASC" <?= $order == 'ASC' ? 'selected' : '' ?>>Ascending</option>
                        </select>
                    </div>
                    <div class="col-md-2 d-flex align-items-end">
                        <button type="submit" class="btn btn-primary me-2">Filter & Sort</button>
                        <a href="data-pesenan.php" class="btn btn-secondary">Reset</a>
                    </div>
                </form>
            </div>

            <!-- Statistik -->
            <div class="card summary-section">
                <div class="card-body">
                    <h5 class="card-title">Statistik Pesanan</h5>
                    <div class="row">
                        <div class="col-md-2">
                            <div class="text-center">
                                <h4 class="text-primary"><?= $stats['total_pesanan'] ?></h4>
                                <p>Total Pesanan</p>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="text-center">
                                <h4 class="text-warning"><?= $stats['pending'] ?></h4>
                                <p>Pending</p>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="text-center">
                                <h4 class="text-info"><?= $stats['processing'] ?></h4>
                                <p>Processing</p>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="text-center">
                                <h4 class="text-success"><?= $stats['completed'] ?></h4>
                                <p>Completed</p>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="text-center">
                                <h4 class="text-danger">Rp <?= number_format($stats['total_pendapatan'], 0, ',', '.') ?></h4>
                                <p>Total Pendapatan</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Tombol Cetak -->
            <div class="mb-3">
                <button onclick="window.print()" class="btn btn-info">
                    <i class="fas fa-print me-2"></i>Cetak Halaman
                </button>
            </div>

            <!-- Tabel Data Pesanan -->
            <div class="card">
                <div class="card-body">
                    <table class="table table-striped table-bordered align-middle">
                        <thead>
                            <tr>
                                <th>ID Order</th>
                                <th>Tanggal Order</th>
                                <th class="text-start">Nama</th>
                                <th class="text-start">Email</th>
                                <th>No HP</th>
                                <th class="text-start alamat-th">Alamat Pengiriman</th>
                                <th class="text-start produk-th">Produk</th>
                                <th class="harga-th">Subtotal Barang</th>
                                <th class="harga-th">Ongkir</th>
                                <th class="harga-th">Total Order</th>
                                <th>Status</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($result && $result->num_rows > 0): ?>
                                <?php while ($row = $result->fetch_assoc()): ?>
                                    <?php
                                    // Hitung ongkir berdasarkan alamat pesanan (spesifik per order)
                                    $alamat_pengiriman = $row['alamat'] ?? ''; // Prioritas dari tb_order.alamat
                                    if (empty($alamat_pengiriman)) {
                                        $alamat_pengiriman = 'Belum diisi (gunakan profil user)'; // Fallback jika kosong
                                    }
                                    $ongkir = hitungOngkir($alamat_pengiriman);
                                    $subtotal_barang = $row['subtotal_barang'] ?? 0;
                                    $total_order = $row['total_amount']; // Dari DB, seharusnya = subtotal + ongkir

                                    // No HP: Prioritas o.phone, fallback ke u.no_hp (tapi query tidak punya u.no_hp, asumsikan tambah jika perlu)
                                    $no_hp = $row['phone'] ?? 'Belum diisi';

                                    // Logika untuk option dropdown berdasarkan status saat ini
                                    $current_status = $row['status'];
                                    $allowed_options = ['pending', 'processing', 'completed'];
                                    if ($current_status === 'processing') {
                                        $allowed_options = ['processing', 'completed'];
                                    } elseif ($current_status === 'completed') {
                                        $allowed_options = ['completed'];
                                    }
                                    $is_locked = ($current_status === 'completed');
                                    ?>
                                    <tr>
                                        <td><?= htmlspecialchars($row['order_id']) ?></td>
                                        <td><?= date('d-m-Y H:i', strtotime($row['order_date'])) ?></td>
                                        <td class="text-start"><?= htmlspecialchars($row['nama']) ?></td>
                                        <td class="text-start"><?= htmlspecialchars($row['email']) ?></td>
                                        <td><?= htmlspecialchars($no_hp) ?></td>
                                        <td class="text-start alamat-col"><?= htmlspecialchars($alamat_pengiriman) ?></td>
                                        <td class="text-start produk-col"><?= $row['produk_details'] ?? 'Tidak ada produk' ?></td>
                                        <td class="text-end harga-col">Rp <?= number_format($subtotal_barang, 0, ',', '.') ?></td>
                                        <td class="text-end harga-col">
                                            Rp <?= number_format($ongkir, 0, ',', '.') ?><br>
                                            <small class="text-muted">(Estimasi dari alamat)</small>
                                        </td>
                                        <td class="text-end harga-col">Rp <?= number_format($total_order, 0, ',', '.') ?></td>
                                        <td>
                                            <span class="badge bg-<?= $row['status'] == 'completed' ? 'success' : ($row['status'] == 'pending' ? 'warning' : ($row['status'] == 'processing' ? 'info' : 'secondary')) ?> fs-6">
                                                <?= htmlspecialchars(ucfirst($row['status'])) ?>
                                            </span>
                                        </td>
                                        <td>
                                            <!-- Tombol Detail -->
                                            <a href="detail-pesanan.php?id=<?= $row['order_id'] ?>" class="btn btn-sm btn-info me-1">
                                                <i class="fas fa-eye"></i> Detail
                                            </a>
                                            <!-- Form Edit Status (dinamis berdasarkan allowed options) -->
                                            <form method="post" style="display: inline-block; margin-bottom: 5px;">
                                                <input type="hidden" name="order_id" value="<?= $row['order_id'] ?>">
                                                <select name="status" class="form-select form-select-sm d-inline-block w-auto" style="width: auto; display: inline-block;" required <?= $is_locked ? 'disabled' : '' ?>>
                                                    <?php foreach ($allowed_options as $opt): ?>
                                                        <?php
                                                        $label = ucfirst($opt);
                                                        $selected = ($current_status === $opt) ? 'selected' : '';
                                                        $disabled_opt = ($is_locked && $opt !== 'completed') ? 'disabled' : '';
                                                        ?>
                                                        <option value="<?= $opt ?>" <?= $selected ?> <?= $disabled_opt ?>><?= $label ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                                <button type="submit" name="update_status" class="btn btn-sm btn-primary ms-1" <?= $is_locked ? 'disabled' : '' ?>>
                                                    <i class="fas fa-sync-alt"></i> Update
                                                </button>
                                            </form>
                                            <!-- Form Hapus (sekarang selalu bisa, bahkan untuk completed) -->
                                            <form method="post" style="display: inline-block;" onsubmit="return confirm('Apakah Anda yakin ingin menghapus pesanan #<?= $row['order_id'] ?>? Data tidak bisa dikembalikan.');">
                                                <input type="hidden" name="order_id" value="<?= $row['order_id'] ?>">
                                                <button type="submit" name="hapus" class="btn btn-sm btn-danger">
                                                    <i class="fas fa-trash"></i> Hapus
                                                </button>
                                            </form>
                                            <?php if ($is_locked): ?>
                                                <small class="text-muted d-block mt-1">Status selesai - Update tidak bisa diubah</small>
                                            <?php endif; ?>
                                            <?php if ($subtotal_barang + $ongkir != $total_order): ?>
                                                <small class="text-warning d-block mt-1">⚠️ Total tidak match (cek ongkir/DB)</small>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="13" class="text-center py-4">
                                        <i class="fas fa-inbox fa-2x text-muted mb-2"></i><br>
                                        Tidak ada data pesanan
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Pagination -->
<?php if ($total_pages > 1): ?>
    <nav aria-label="Page navigation">
        <ul class="pagination">
            <?php
            // Bangun query string untuk pagination (simpan filter dan sorting)
            $query_params = [];
            if (!empty($filter_status)) $query_params['status'] = $filter_status;
            if (!empty($date_from)) $query_params['date_from'] = $date_from;
            if (!empty($date_to)) $query_params['date_to'] = $date_to;
            if (!empty($sort_by)) $query_params['sort_by'] = $sort_by;
            if (!empty($order)) $query_params['order'] = $order;
            $query_string = http_build_query($query_params);
            $base_url = '?' . $query_string . ($query_string ? '&' : '');
            ?>
            <?php if ($page > 1): ?>
                <li class="page-item">
                    <a class="page-link" href="<?= $base_url ?>page=<?= $page - 1 ?>" aria-label="Previous">
                        <span aria-hidden="true">&laquo;</span>
                    </a>
                </li>
            <?php endif; ?>

            <?php
            $start_page = max(1, $page - 2);
            $end_page = min($total_pages, $page + 2);
            for ($i = $start_page; $i <= $end_page; $i++): ?>
                <li class="page-item <?= $i == $page ? 'active' : '' ?>">
                    <a class="page-link" href="<?= $base_url ?>page=<?= $i ?>"><?= $i ?></a>
                </li>
            <?php endfor; ?>

            <?php if ($page < $total_pages): ?>
                <li class="page-item">
                    <a class="page-link" href="<?= $base_url ?>page=<?= $page + 1 ?>" aria-label="Next">
                        <span aria-hidden="true">&raquo;</span>
                    </a>
                </li>
            <?php endif; ?>
        </ul>
    </nav>
<?php endif; ?>
        </main>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        // Auto-dismiss alert setelah 5 detik
        setTimeout(function() {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(function(alert) {
                const bsAlert = new bootstrap.Alert(alert);
                bsAlert.close();
            });
        }, 5000);
    </script>

<?php
mysqli_close($conn);
?>
</body>
</html>