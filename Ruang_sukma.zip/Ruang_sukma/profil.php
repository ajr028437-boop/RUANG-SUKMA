<?php
   session_start();
   include 'db.php';
   if($_SESSION['status_login'] != true){
      echo '<script>window.location="login.php"</script>';
   }

   $query = mysqli_query($conn, "SELECT * FROM tb_admin WHERE admin_id ='".$_SESSION['id']."'");
   $d = mysqli_fetch_object($query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8" />
   <meta name="viewport" content="width=device-width, initial-scale=1" />
   <title>Profil - Ruang Sukma</title>
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
   <style>
      @import url('https://fonts.googleapis.com/css2?family=Quicksand&display=swap');

      body {
         font-family: 'Quicksand', sans-serif;
         background-color: #f9fafb;
         margin: 0;
         min-height: 100vh;
      }
      .sidebar {
         min-height: 100vh;
         width: 250px;
         background: #d32f2f;
         color: #fff;
         padding: 30px 0;
         box-shadow: 3px 0 8px rgba(0,0,0,0.1);
         display: flex;
         flex-direction: column;
         align-items: center;
      }
      .sidebar h2 {
         font-weight: 700;
         font-size: 1.8rem;
         margin-bottom: 2rem;
         letter-spacing: 1px;
         text-align: center;
      }
      .sidebar .nav-link {
         color: #fff;
         font-weight: 600;
         font-size: 1rem;
         padding: 12px 25px;
         border-radius: 10px;
         margin: 6px 15px;
         transition: background-color 0.3s ease, transform 0.2s ease;
         width: 100%;
         text-align: left;
      }
      .sidebar .nav-link.active, .sidebar .nav-link:hover {
         background: #b71c1c;
         box-shadow: inset 5px 0 0 0 #ff5252;
         transform: translateX(5px);
         text-decoration: none;
      }
      .content {
         flex-grow: 1;
         background-color: #fff;
         min-height: 100vh;
         display: flex;
         flex-direction: column;
      }
      /* Topbar */
      .navbar {
         background-color: #d32f2f !important;
         box-shadow: 0 2px 6px rgb(0 0 0 / 0.1);
      }
      .navbar-brand {
         font-weight: 700;
         font-size: 1.3rem;
      }
      /* Profile Cards */
      .profile-card {
         border-radius: 12px;
         box-shadow: 0 6px 15px rgb(0 0 0 / 0.1);
         overflow: hidden;
         margin-bottom: 2rem;
      }
      .profile-header {
         background: linear-gradient(135deg, #d32f2f, #ff6b81);
         color: #fff;
         text-align: center;
         padding: 40px 20px;
      }
      .profile-header h2 {
         margin: 0;
         font-weight: 700;
         font-size: 2rem;
      }
      .profile-header p {
         margin: 5px 0 0;
         font-size: 14px;
         opacity: 0.9;
      }
      .card-body {
         padding: 2rem;
      }
      .form-label {
         font-weight: 600;
      }
      .btn-custom {
         border-radius: 12px;
         font-weight: 700;
         transition: 0.3s;
      }
      .btn-custom:hover {
         transform: translateY(-2px);
         box-shadow: 0 4px 12px rgba(211, 47, 47, 0.4);
      }
      /* Footer */
      footer {
         background-color: #f1f1f1;
         text-align: center;
         padding: 15px 0;
         font-size: 0.9rem;
         color: #555;
         margin-top: auto;
      }
      /* Responsive */
      @media (max-width: 768px) {
         .sidebar {
            width: 100%;
            min-height: auto;
            flex-direction: row;
            justify-content: space-around;
            padding: 15px 0;
         }
         .sidebar h2 {
            display: none;
         }
         .sidebar .nav-link {
            margin: 0 5px;
            padding: 8px 12px;
            font-size: 0.9rem;
            text-align: center;
            flex-grow: 1;
         }
         .content {
            min-height: auto;
         }
         .card-body {
            padding: 1.5rem;
         }
      }
   </style>
</head>
<body>
   <div class="d-flex flex-column flex-md-row min-vh-100">
      <!-- Sidebar -->
      <nav class="sidebar d-flex flex-column">
         <h2>Ruang Sukma</h2>
         <a href="dashboard.php" class="nav-link">📊 Dashboard</a>
         <a href="profil.php" class="nav-link active">👤 Profil</a>
         <a href="data-kategori.php" class="nav-link">📂 Data Kategori</a>
         <a href="data-produk.php" class="nav-link">📦 Data Produk</a>
         <a href="data-pesenan.php" class="nav-link">🧾 Data Pesanan</a>
         <a href="data-pendapatan.php" class="nav-link">💰 Data Pendapatan</a>
         <a href="data-pengeluaran.php" class="nav-link">💸 Data Pengeluaran</a>
         <a href="keluar.php" class="nav-link">🚪 Keluar</a>
      </nav>

      <!-- Content -->
      <div class="content d-flex flex-column">
         <!-- Topbar -->
         <nav class="navbar navbar-expand-lg navbar-dark">
            <div class="container-fluid">
               <span class="navbar-brand">👤 Profil</span>
            </div>
         </nav>

         <main class="container py-4 flex-grow-1">
            <div class="row justify-content-center">
               <div class="col-md-8">

                  <!-- Card Edit Profil -->
                  <div class="card profile-card">
                     <div class="profile-header">
                        <h2><?= htmlspecialchars($d->admin_name) ?></h2>
                        <p>Administrator</p>
                     </div>
                     <div class="card-body">
                        <h4 class="mb-4 text-center">Edit Profil</h4>
                        <form action="" method="POST" novalidate>
                           <div class="mb-3">
                              <label class="form-label" for="nama">Nama Lengkap</label>
                              <input type="text" id="nama" name="nama" class="form-control" 
                                     value="<?= htmlspecialchars($d->admin_name) ?>" required>
                           </div>
                           <div class="mb-3">
                              <label class="form-label" for="user">Username</label>
                              <input type="text" id="user" name="user" class="form-control" 
                                     value="<?= htmlspecialchars($d->username) ?>" required>
                           </div>
                           <div class="mb-3">
                              <label class="form-label" for="hp">No HP</label>
                              <input type="text" id="hp" name="hp" class="form-control" 
                                     value="<?= htmlspecialchars($d->admin_telp) ?>" required>
                           </div>
                           <div class="mb-3">
                              <label class="form-label" for="email">Email</label>
                              <input type="email" id="email" name="email" class="form-control" 
                                     value="<?= htmlspecialchars($d->admin_email) ?>" required>
                           </div>
                           <div class="mb-3">
                              <label class="form-label" for="alamat">Alamat</label>
                              <textarea id="alamat" name="alamat" class="form-control" rows="2" required><?= htmlspecialchars($d->admin_address) ?></textarea>
                           </div>
                           <button type="submit" name="ubah_profil" class="btn btn-danger btn-custom w-100">💾 Simpan Perubahan</button>
                        </form>
                        <?php
                        if(isset($_POST['ubah_profil'])){
                           $nama   = ucwords($_POST['nama']);
                           $user   = $_POST['user'];
                           $hp     = $_POST['hp'];
                           $email  = $_POST['email'];
                           $alamat = ucwords($_POST['alamat']);

                           $update = mysqli_query($conn, "UPDATE tb_admin SET 
                                       admin_name     = '".$nama."',
                                       username       = '".$user."',
                                       admin_telp     = '".$hp."',
                                       admin_email    = '".$email."',
                                       admin_address  = '".$alamat."'
                                       WHERE admin_id = '".$d->admin_id."' ");

                           if($update){
                              echo '<script>alert("Profil berhasil diperbarui!"); window.location="profil.php";</script>';
                           }else{
                              echo '<div class="alert alert-danger mt-3">Gagal: '.mysqli_error($conn).'</div>';
                           }
                        }
                        ?>
                     </div>
                  </div>

                  <!-- Card Ubah Password -->
                  <div class="card profile-card">
                     <div class="card-body">
                        <h4 class="mb-4 text-center">Ubah Password</h4>
                        <form action="" method="POST" novalidate>
                           <div class="mb-3">
                              <label class="form-label" for="pass1">Password Baru</label>
                              <input type="password" id="pass1" name="pass1" class="form-control" required>
                           </div>
                           <div class="mb-3">
                              <label class="form-label" for="pass2">Konfirmasi Password Baru</label>
                              <input type="password" id="pass2" name="pass2" class="form-control" required>
                           </div>
                           <button type="submit" name="ubah_password" class="btn btn-danger btn-custom w-100">🔑 Ubah Password</button>
                        </form>
                        <?php
                        if(isset($_POST['ubah_password'])){
                           $pass1 = $_POST['pass1'];
                           $pass2 = $_POST['pass2'];

                           if($pass1 != $pass2){
                              echo '<div class="alert alert-warning mt-3">Konfirmasi password tidak sesuai!</div>';
                           }else{
                              $u_pass = mysqli_query($conn, "UPDATE tb_admin SET 
                                          admin_password = '".MD5($pass1)."' 
                                          WHERE admin_id = '".$d->admin_id."' ");
                              if($u_pass){
                                 echo '<script>alert("Password berhasil diubah!"); window.location="profil.php";</script>';
                              }else{
                                 echo '<div class="alert alert-danger mt-3">Gagal: '.mysqli_error($conn).'</div>';
                              }
                           }
                        }
                        ?>
                     </div>
                  </div>

               </div>
            </div>
         </main>

         <!-- Footer -->
         <footer>
            <small>Copyright &copy; 2025 - Ruang Sukma</small>
         </footer>
      </div>
   </div>
</body>
</html>