<?php
session_start();
include 'db.php';
if (!isset($_SESSION['status_login']) || $_SESSION['status_login'] !== true) {
    header('Location: login.php');
    exit();
}

// Ambil ID produk dari URL dan validasia
if (!isset($_GET['id'])) {
    header('Location: data-produk.php');
    exit();
}

$id = $_GET['id'];
$produk = mysqli_query($conn, "SELECT * FROM tb_product WHERE product_id = '" . mysqli_real_escape_string($conn, $id) . "' ");
if (!$produk || mysqli_num_rows($produk) == 0) {
    echo '<script>alert("Data tidak ditemukan")</script>';
    echo '<script>window.location="data-produk.php"</script>';
    exit();
}
$p = mysqli_fetch_object($produk);

// Proses update data
if (isset($_POST['submit'])) {
    $kategori   = mysqli_real_escape_string($conn, $_POST['kategori']);
    $nama       = mysqli_real_escape_string($conn, $_POST['nama']);
    $harga      = mysqli_real_escape_string($conn, $_POST['harga']);
    $deskripsi  = mysqli_real_escape_string($conn, $_POST['deskripsi']);
    $status     = mysqli_real_escape_string($conn, $_POST['status']);

    // cek apakah user upload gambar baru
    if ($_FILES['gambar']['name'] != '') {
        $filename = $_FILES['gambar']['name'];
        $tmp_name = $_FILES['gambar']['tmp_name'];

        $type1 = explode('.', $filename);
        $type2 = strtolower(end($type1));

        $newname = 'produk' . time() . '.' . $type2;
        $allowed_type = array('jpg', 'jpeg', 'png', 'gif');

        if (!in_array($type2, $allowed_type)) {
            echo '<script>alert("Format file tidak diizinkan")</script>';
        } else {
            // hapus file lama
            if (file_exists('./produk/' . $p->product_image) && $p->product_image != '') {
                unlink('./produk/' . $p->product_image);
            }
            // upload file baru
            move_uploaded_file($tmp_name, './produk/' . $newname);
            $namagambar = $newname;
        }
    } else {
        $namagambar = $p->product_image; // tetap pakai yang lama
    }

    // update ke database
    $update = mysqli_query($conn, "UPDATE tb_product SET
                    category_name = '$kategori',
                    product_name = '$nama',
                    product_price = '$harga',
                    product_description = '$deskripsi',
                    product_image = '$namagambar',
                    product_status = '$status'
                WHERE product_id = '" . $p->product_id . "' ");

    if ($update) {
        echo '<script>alert("Ubah data berhasil")</script>';
        echo '<script>window.location="data-produk.php"</script>';
        exit();
    } else {
        echo 'Gagal ' . mysqli_error($conn);
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Edit Produk - Ruang Sukma</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Quicksand&display=swap');

        body {
            font-family: 'Quicksand', sans-serif;
            background-color: #f9fafb;
            margin: 0;
            min-height: 100vh;
        }

        .sidebar {
            min-height: 100vh;
            background: #d32f2f;
            color: #fff;
            padding: 30px 0;
            box-shadow: 3px 0 8px rgba(0, 0, 0, 0.1);
        }

        .sidebar h4 {
            font-weight: 700;
            font-size: 1.6rem;
            margin-bottom: 2rem;
            text-align: center;
            letter-spacing: 1px;
        }

        .sidebar a {
            color: #fff;
            text-decoration: none;
            display: block;
            padding: 12px 25px;
            border-radius: 10px;
            margin: 8px 15px;
            font-weight: 600;
            font-size: 1rem;
            transition: background-color 0.3s ease, transform 0.2s ease;
            box-shadow: inset 0 0 0 0 transparent;
        }

        .sidebar a.active,
        .sidebar a:hover {
            background: #b71c1c;
            box-shadow: inset 5px 0 0 0 #ff5252;
            transform: translateX(5px);
        }

        .content {
            padding: 30px 40px;
            background-color: #fff;
            min-height: 100vh;
        }

        h3 {
            margin-bottom: 1.5rem;
        }

        .input-control {
            width: 100%;
            padding: 10px 15px;
            border-radius: 8px;
            border: 1px solid #ddd;
            font-size: 1rem;
            margin-bottom: 20px;
            transition: border-color 0.3s ease;
        }

        .input-control:focus {
            outline: none;
            border-color: #e53935;
            box-shadow: 0 0 8px rgb(229 38 16 / 0.4);
        }

        .btn {
            background: #e53935;
            border: none;
            color: #fff;
            font-weight: 600;
            padding: 10px 25px;
            border-radius: 8px;
            cursor: pointer;
            box-shadow: 0 4px 8px rgb(229 38 16 / 0.4);
            transition: background-color 0.3s ease, box-shadow 0.3s ease;
        }

        .btn:hover {
            background: #b71c1c;
            box-shadow: 0 6px 12px rgb(204 0 0 / 0.6);
        }

        img {
            margin-bottom: 15px;
            border-radius: 8px;
            max-width: 150px;
            height: auto;
            display: block;
        }

        footer {
            background-color: #fff;
            padding: 15px 40px;
            text-align: center;
            font-size: 0.9rem;
            color: #666;
            box-shadow: 0 -2px 8px rgb(0 0 0 / 0.05);
        }

        @media (max-width: 768px) {
            .sidebar {
                min-height: auto;
                padding: 15px 0;
            }

            .sidebar a {
                margin: 5px 10px;
                padding: 10px 15px;
                font-size: 0.9rem;
            }

            .content {
                padding: 20px 15px;
            }
        }
    </style>
</head>

<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <nav class="col-md-2 sidebar d-flex flex-column">
                <h4 class="text-center mb-4">📌 Ruang Sukma</h4>
                <a href="dashboard.php">📊 Dashboard</a>
                <a href="profil.php">👤 Profil</a>
                <a href="data-kategori.php">📂 Data Kategori</a>
                <a href="data-produk.php" class="active">📦 Data Produk</a>
                <a href="data-pesenan.php">🧾 Data Pesanan</a>
                <a href="data-pendapatan.php">💰 Data Pendapatan</a>
                <a href="data-pengeluaran.php">💸 Data Pengeluaran</a>
                <a href="keluar.php">🚪 Keluar</a>
            </nav>

            <!-- Main Content -->
            <main class="col-md-10 content">
                <h3>✏️ Edit Produk</h3>
                <form action="" method="POST" enctype="multipart/form-data" style="max-width: 600px;">
                    <input type="text" name="kategori" class="input-control" placeholder="Isi kategori produk" value="<?= htmlspecialchars($p->category_name) ?>" required>
                    <input type="text" name="nama" class="input-control" placeholder="Nama Produk" value="<?= htmlspecialchars($p->product_name) ?>" required>
                    <input type="number" name="harga" class="input-control" placeholder="Harga" value="<?= htmlspecialchars($p->product_price) ?>" required>
                    <textarea class="input-control" name="deskripsi" placeholder="Deskripsi" rows="4"><?= htmlspecialchars($p->product_description) ?></textarea>

                    <label>Gambar Produk Saat Ini:</label>
                    <?php if ($p->product_image && file_exists('./produk/' . $p->product_image)) : ?>
                        <img src="produk/<?= htmlspecialchars($p->product_image) ?>" alt="Gambar Produk">
                    <?php else : ?>
                        <p><em>Tidak ada gambar</em></p>
                    <?php endif; ?>

                    <input type="file" name="gambar" class="input-control">

                    <select class="input-control" name="status" required>
                        <option value="1" <?= ($p->product_status == 1) ? 'selected' : ''; ?>>Tersedia</option>
                        <option value="0" <?= ($p->product_status == 0) ? 'selected' : ''; ?>>Tidak Tersedia</option>
                    </select>

                    <button type="submit" name="submit" class="btn">Simpan Perubahan</button>
                </form>
            </main>
        </div>
    </div>

    <footer>
        <div class="container">
            <small>Copyright &copy; 2025 - Ruang Sukma</small>
        </div>
    </footer>
</body>

</html>