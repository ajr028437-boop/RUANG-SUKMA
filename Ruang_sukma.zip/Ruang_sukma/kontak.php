<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Kontak Kami - Ruang Sukma</title>
  <style>
    body {font-family:'Segoe UI',Arial,sans-serif;background:#f8f9fa;margin:0;padding:0;}
    header {background:#dc3545;color:#fff;padding:15px 30px;text-align:center;font-size:22px;font-weight:bold;}
    .content {max-width:600px;margin:40px auto;background:#fff;padding:30px;border-radius:10px;box-shadow:0 4px 12px rgba(0,0,0,0.1);}
    h2 {color:#dc3545;margin-top:0;}
    label {display:block;margin-bottom:8px;font-weight:500;}
    input, textarea {
      width:100%;padding:10px;margin-bottom:15px;border:1px solid #ccc;border-radius:6px;font-size:14px;
    }
    button {
      padding:10px 20px;border:none;background:#28a745;color:#fff;
      font-size:15px;border-radius:6px;cursor:pointer;transition:0.3s;
    }
    button:hover {background:#218838;}
    .info {margin-top:20px;font-size:14px;color:#555;}
    .info p {margin:6px 0;}
    footer {margin-top:40px;background:#343a40;color:#fff;text-align:center;padding:15px;font-size:14px;}
  </style>
</head>
<body>

<header>Kontak Kami</header>

<div class="content">
  <h2>Hubungi Kami</h2>
  <form action="#" method="post">
    <label>Nama</label>
    <input type="text" name="nama" required>

    <label>Email</label>
    <input type="email" name="email" required>

    <label>Pesan</label>
    <textarea name="pesan" rows="5" required></textarea>

    <button type="submit">Kirim Pesan</button>
  </form>

  <div class="info">
    <p><b>Email:</b> support@ruangsukma.com</p>
    <p><b>Telepon/WA:</b> 0831-2098-7582</p>
    <p><b>Alamat:</b> Tasikmalaya, Jawa Barat</p>
  </div>
</div>

<footer>&copy; 2025 - Ruang Sukma</footer>

</body>
</html>
