<?php
session_start();
include 'db.php';

if ($_SESSION['status_login'] != true) {
    header("Location: login.php");
    exit;
}

if (!isset($_SESSION['admin_messages'])) {
    $_SESSION['admin_messages'] = [];
}

// Ambil order_id dari GET
$order_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if ($order_id <= 0) {
    $_SESSION['admin_messages'][] = ['type' => 'danger', 'text' => 'ID pesanan tidak valid.'];
    header("Location: data-pesenan.php");
    exit;
}

// Function untuk hitung ongkir (sama seperti di halaman lain)
function hitungOngkir($alamat) {
    if (empty($alamat) || strlen(trim($alamat)) < 10) {
        return 0; // Alamat terlalu pendek/kosong
    }
    $lower_alamat = strtolower(trim($alamat));
    if (strpos($lower_alamat, 'tasik') !== false || strpos($lower_alamat, 'unsil') !== false || 
        strpos($lower_alamat, 'katumbiri') !== false || strpos($lower_alamat, 'indihiang') !== false) {
        return 15000;
    } elseif (strpos($lower_alamat, 'bandung') !== false || strpos($lower_alamat, 'cirebon') !== false || 
              strpos($lower_alamat, 'garut') !== false) {
        return 30000;
    } elseif (strpos($lower_alamat, 'jakarta') !== false || strpos($lower_alamat, 'bekasi') !== false || 
              strpos($lower_alamat, 'bogor') !== false) {
        return 50000;
    } else {
        return 20000; // Default
    }
}

// Query untuk detail pesanan
$query = "
SELECT 
    o.order_id, o.total_amount, o.status, o.order_date, o.alamat, o.phone,
    u.nama, u.email,
    d.quantity, p.product_name, p.product_price
FROM tb_order o
JOIN tb_user u ON o.user_id = u.id
JOIN tb_order_detail d ON o.order_id = d.order_id
JOIN tb_product p ON d.product_id = p.product_id
WHERE o.order_id = ?
ORDER BY p.product_name ASC
";

$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, "i", $order_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if (!$result || mysqli_num_rows($result) == 0) {
    $_SESSION['admin_messages'][] = ['type' => 'danger', 'text' => 'Pesanan tidak ditemukan.'];
    header("Location: data-pesenan.php");
    exit;
}

// Ambil data pesanan umum (dari row pertama)
$row = mysqli_fetch_assoc($result);
$order_info = [
    'order_id' => $row['order_id'],
    'order_date' => $row['order_date'],
    'nama' => $row['nama'],
    'email' => $row['email'],
    'phone' => $row['phone'] ?? 'Belum diisi',
    'alamat' => $row['alamat'] ?? 'Belum diisi',
    'status' => $row['status'],
    'total_amount' => $row['total_amount']
];

// Kumpulkan produk
$produk_list = [];
$subtotal_barang = 0;
do {
    $produk_list[] = [
        'product_name' => $row['product_name'],
        'quantity' => $row['quantity'],
        'product_price' => $row['product_price'],
        'subtotal' => $row['quantity'] * $row['product_price']
    ];
    $subtotal_barang += $row['quantity'] * $row['product_price'];
} while ($row = mysqli_fetch_assoc($result));

mysqli_stmt_close($stmt);

// Hitung ongkir
$ongkir = hitungOngkir($order_info['alamat']);
$total_order = $order_info['total_amount']; // Dari DB

// Handling Update Status (opsional, jika ingin bisa update dari detail)
if (isset($_POST['update_status'])) {
    $status = $_POST['status'];

    // Validasi status saat ini untuk mencegah mundur
    $current_status_query = "SELECT status FROM tb_order WHERE order_id = ?";
    $stmt_current = mysqli_prepare($conn, $current_status_query);
    mysqli_stmt_bind_param($stmt_current, "i", $order_id);
    mysqli_stmt_execute($stmt_current);
    $result_current = mysqli_stmt_get_result($stmt_current);
    $current_row = mysqli_fetch_assoc($result_current);
    $current_status = $current_row['status'] ?? 'pending';
    mysqli_stmt_close($stmt_current);

    $allowed_statuses = ['pending', 'processing', 'completed'];
    if ($current_status === 'processing') {
        $allowed_statuses = ['processing', 'completed'];
    } elseif ($current_status === 'completed') {
        $allowed_statuses = ['completed'];
    }

    if (in_array($status, $allowed_statuses)) {
        $update_query = "UPDATE tb_order SET status = ? WHERE order_id = ?";
        $stmt = mysqli_prepare($conn, $update_query);
        mysqli_stmt_bind_param($stmt, "si", $status, $order_id);

        if (mysqli_stmt_execute($stmt)) {
            mysqli_stmt_close($stmt);

            // Email notifikasi
            $get_user_query = "SELECT u.email, u.nama FROM tb_order o JOIN tb_user u ON o.user_id = u.id WHERE o.order_id = ?";
            $stmt_user = mysqli_prepare($conn, $get_user_query);
            mysqli_stmt_bind_param($stmt_user, "i", $order_id);
            mysqli_stmt_execute($stmt_user);
            $result_user = mysqli_stmt_get_result($stmt_user);

            if ($user_row = mysqli_fetch_assoc($result_user)) {
                $email = $user_row['email'];
                $nama = $user_row['nama'];

                $status_display = ucfirst($status);
                $subject = "Update Status Pesanan - Ruang Sukma";
                $message = "Halo {$nama},\n\nStatus pesanan #{$order_id} Anda telah diupdate menjadi: {$status_display}.\n\nTerima kasih telah berbelanja di Ruang Sukma!\nJika ada pertanyaan, hubungi kami di admin@ruangsukma.com.\n\nSalam hangat,\nTim Ruang Sukma";
                $headers = "From: admin@ruangsukma.com\r\nReply-To: admin@ruangsukma.com\r\nContent-Type: text/plain; charset=UTF-8\r\n";
                if (mail($email, $subject, $message, $headers)) {
                    $_SESSION['admin_messages'][] = ['type' => 'success', 'text' => "Status diupdate ke '" . ucfirst($status) . "' dan email terkirim!"];
                } else {
                    $_SESSION['admin_messages'][] = ['type' => 'warning', 'text' => "Status diupdate ke '" . ucfirst($status) . "', tapi email gagal."];
                }
            } else {
                $_SESSION['admin_messages'][] = ['type' => 'warning', 'text' => "Status diupdate ke '" . ucfirst($status) . "', tapi user tidak ditemukan."];
            }
            mysqli_stmt_close($stmt_user);
        } else {
            $_SESSION['admin_messages'][] = ['type' => 'danger', 'text' => 'Gagal update status: ' . mysqli_error($conn)];
        }
    } else {
        $_SESSION['admin_messages'][] = ['type' => 'danger', 'text' => 'Update tidak valid.'];
    }

    header("Location: " . $_SERVER['PHP_SELF'] . "?id=" . $order_id);
    exit;
}

// Handling Hapus Pesanan
if (isset($_POST['hapus'])) {
    $delete_detail = "DELETE FROM tb_order_detail WHERE order_id = ?";
    $stmt_detail = mysqli_prepare($conn, $delete_detail);
    mysqli_stmt_bind_param($stmt_detail, "i", $order_id);
    mysqli_stmt_execute($stmt_detail);
    mysqli_stmt_close($stmt_detail);

    $delete_order = "DELETE FROM tb_order WHERE order_id = ?";
    $stmt_order = mysqli_prepare($conn, $delete_order);
    mysqli_stmt_bind_param($stmt_order, "i", $order_id);

    if (mysqli_stmt_execute($stmt_order)) {
        mysqli_stmt_close($stmt_order);
        $_SESSION['admin_messages'][] = ['type' => 'success', 'text' => 'Pesanan #'.$order_id.' dihapus!'];
        header("Location: data-pesenan.php");
        exit;
    } else {
        $_SESSION['admin_messages'][] = ['type' => 'danger', 'text' => 'Gagal hapus pesanan: ' . mysqli_error($conn)];
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Detail Pesanan #<?= $order_id ?> - Ruang Sukma</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Quicksand&display=swap');
        body { font-family: 'Quicksand', sans-serif; background-color: #f9fafb; margin: 0; min-height: 100vh; }
        .sidebar { min-height: 100vh; background: #d32f2f; color: #fff; padding: 30px 0; box-shadow: 3px 0 8px rgba(0,0,0,0.1); width: 250px; display: flex; flex-direction: column; align-items: center; position: fixed; top: 0; left: 0; z-index: 1000; }
        .sidebar h2 { font-weight: 700; font-size: 1.8rem; margin-bottom: 2rem; letter-spacing: 1px; text-align: center; }
        .sidebar a { color: #fff; font-weight: 600; font-size: 1rem; padding: 12px 25px; border-radius: 10px; margin: 8px 15px; text-decoration: none; width: 100%; transition: background-color 0.3s ease, transform 0.2s ease; display: block; }
        .sidebar a.active, .sidebar a:hover { background: #b71c1c; box-shadow: inset 5px 0 0 0 #ff5252; transform: translateX(5px); text-decoration: none; }
        .content { flex-grow: 1; background-color: #fff; min-height: 100vh; padding: 30px 40px 30px 290px; }
        h2.page-title { margin-bottom: 1.5rem; font-weight: 700; }
        .card { border-radius: 12px; box-shadow: 0 6px 15px rgb(0 0 0 / 0.1); border: none; margin-bottom: 2rem; }
        .card-body { padding: 2rem; }
        .btn-primary { background-color: #e53935; border: none; box-shadow: 0 3px 8px rgb(229 38 16 / 0.4); color: #fff; }
        .btn-primary:hover:not(:disabled) { background-color: #b71c1c; box-shadow: 0 6px 12px rgb(204 0 0 / 0.6); color: #fff; }
        .btn-danger { background-color: #e53935; border: none; box-shadow: 0 3px 8px rgb(229 57 53 / 0.4); color: #fff; }
        .btn-danger:hover:not(:disabled) { background-color: #b71c1c; color: #fff; }
        .alert { border-radius: 8px; margin-bottom: 1rem; }
        @media (max-width: 768px) {
            .sidebar { width: 100%; min-height: auto; flex-direction: row; justify-content: space-around; padding: 15px 0; position: relative; z-index: 1000; }
            .content { padding: 20px 15px 30px 15px; }
            .sidebar h2 { display: none; }
            .sidebar a { margin: 0 5px; padding: 8px 12px; font-size: 0.9rem; text-align: center; flex-grow: 1; }
        }
    </style>
</head>
<body>
    <div class="d-flex flex-column flex-md-row min-vh-100">
        <!-- Sidebar -->
        <nav class="sidebar d-flex flex-column">
            <h2>Ruang Sukma</h2>
            <a href="dashboard.php" class="nav-link">📊 Dashboard</a>
            <a href="profil.php" class="nav-link">👤 Profil</a>
            <a href="data-kategori.php" class="nav-link">📂 Data Kategori</a>
            <a href="data-produk.php" class="nav-link">📦 Data Produk</a>
            <a href="data-pesenan.php" class="nav-link active">🧾 Data Pesanan</a>
            <a href="data-pendapatan.php" class="nav-link">💰 Data Pendapatan</a>
            <a href="data-pengeluaran.php" class="nav-link">💸 Data Pengeluaran</a>
            <a href="keluar.php" class="nav-link">🚪 Keluar</a>
        </nav>

        <!-- Content -->
        <main class="content">
            <h2 class="page-title">Detail Pesanan #<?= $order_id ?></h2>

            <!-- Tampilkan Pesan dari Session -->
            <?php if (!empty($_SESSION['admin_messages'])): ?>
                <?php foreach ($_SESSION['admin_messages'] as $msg): ?>
                    <div class="alert alert-<?= $msg['type'] ?> alert-dismissible fade show" role="alert">
                        <?= htmlspecialchars($msg['text']) ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endforeach; ?>
                <?php unset($_SESSION['admin_messages']); ?>
            <?php endif; ?>

            <!-- Informasi Pesanan -->
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Informasi Pesanan</h5>
                    <div class="row">
                        <div class="col-md-6">
                            <p><strong>ID Pesanan:</strong> <?= htmlspecialchars($order_info['order_id']) ?></p>
                            <p><strong>Tanggal Order:</strong> <?= date('d-m-Y H:i', strtotime($order_info['order_date'])) ?></p>
                            <p><strong>Nama:</strong> <?= htmlspecialchars($order_info['nama']) ?></p>
                            <p><strong>Email:</strong> <?= htmlspecialchars($order_info['email']) ?></p>
                        </div>
                        <div class="col-md-6">
                            <p><strong>No HP:</strong> <?= htmlspecialchars($order_info['phone']) ?></p>
                            <p><strong>Alamat Pengiriman:</strong> <?= htmlspecialchars($order_info['alamat']) ?></p>
                            <p><strong>Status:</strong> 
                                <span class="badge bg-<?= $order_info['status'] == 'completed' ? 'success' : ($order_info['status'] == 'pending' ? 'warning' : ($order_info['status'] == 'processing' ? 'info' : 'secondary')) ?> fs-6">
                                    <?= htmlspecialchars(ucfirst($order_info['status'])) ?>
                                </span>
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Detail Produk -->
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Detail Produk</h5>
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Produk</th>
                                <th>Jumlah</th>
                                <th>Harga Satuan</th>
                                <th>Subtotal</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($produk_list as $produk): ?>
                                <tr>
                                    <td><?= htmlspecialchars($produk['product_name']) ?></td>
                                    <td><?= htmlspecialchars($produk['quantity']) ?></td>
                                    <td>Rp <?= number_format($produk['product_price'], 0, ',', '.') ?></td>
                                    <td>Rp <?= number_format($produk['subtotal'], 0, ',', '.') ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Ringkasan Biaya -->
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Ringkasan Biaya</h5>
                    <p><strong>Subtotal Barang:</strong> Rp <?= number_format($subtotal_barang, 0, ',', '.') ?></p>
                    <p><strong>Ongkir:</strong> Rp <?= number_format($ongkir, 0, ',', '.') ?> <small class="text-muted">(Estimasi dari alamat)</small></p>
                    <p><strong>Total Order:</strong> Rp <?= number_format($total_order, 0, ',', '.') ?></p>
                    <?php if ($subtotal_barang + $ongkir != $total_order): ?>
                        <small class="text-warning">⚠️ Total tidak match (cek ongkir/DB)</small>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Aksi -->
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Aksi</h5>
                    <a href="data-pesenan.php" class="btn btn-secondary me-2">Kembali ke Data Pesanan</a>
                    
                                      <!-- Form Update Status -->
                    <?php
                    $current_status = $order_info['status'];
                    $allowed_options = ['pending', 'processing', 'completed'];
                    if ($current_status === 'processing') {
                        $allowed_options = ['processing', 'completed'];
                    } elseif ($current_status === 'completed') {
                        $allowed_options = ['completed'];
                    }
                    $is_locked = ($current_status === 'completed');
                    ?>
                    <form method="post" style="display: inline-block; margin-right: 10px;">
                        <input type="hidden" name="order_id" value="<?= $order_id ?>">
                        <select name="status" class="form-select d-inline-block w-auto" required <?= $is_locked ? 'disabled' : '' ?>>
                            <?php foreach ($allowed_options as $opt): ?>
                                <?php
                                $label = ucfirst($opt);
                                $selected = ($current_status === $opt) ? 'selected' : '';
                                $disabled_opt = ($is_locked && $opt !== 'completed') ? 'disabled' : '';
                                ?>
                                <option value="<?= $opt ?>" <?= $selected ?> <?= $disabled_opt ?>><?= $label ?></option>
                            <?php endforeach; ?>
                        </select>
                        <button type="submit" name="update_status" class="btn btn-primary ms-2" <?= $is_locked ? 'disabled' : '' ?>>
                            <i class="fas fa-sync-alt"></i> Update Status
                        </button>
                    </form>
                    
                    <!-- Form Hapus -->
                    <form method="post" style="display: inline-block;" onsubmit="return confirm('Apakah Anda yakin ingin menghapus pesanan #<?= $order_id ?>? Data tidak bisa dikembalikan.');">
                        <input type="hidden" name="order_id" value="<?= $order_id ?>">
                        <button type="submit" name="hapus" class="btn btn-danger">
                            <i class="fas fa-trash"></i> Hapus Pesanan
                        </button>
                    </form>
                    
                    <?php if ($is_locked): ?>
                        <small class="text-muted d-block mt-2">Status selesai - Update tidak bisa diubah</small>
                    <?php endif; ?>
                </div>
            </div>
        </main>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        // Auto-dismiss alert setelah 5 detik
        setTimeout(function() {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(function(alert) {
                const bsAlert = new bootstrap.Alert(alert);
                bsAlert.close();
            });
        }, 5000);
    </script>

<?php
mysqli_close($conn);
?>
</body>
</html>