<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_login']) || !isset($_SESSION['user_id'])) {
    header("Location: login_user.php");
    exit;
}

$order_id = (int)($_GET['order_id'] ?? 0);
$user_id = $_SESSION['user_id'];
$order_data = [];
$details = [];
$subtotal_items = 0; // Subtotal dari items (tanpa ongkir)
$ongkir_estimated = 0; // Ongkir dihitung ulang dari alamat
$total = 0;

if ($order_id > 0) {
    // Ambil data order
    $query_order = "SELECT * FROM tb_order WHERE order_id = ? AND user_id = ?";
    $stmt_order = mysqli_prepare($conn, $query_order);
    if ($stmt_order) {
        mysqli_stmt_bind_param($stmt_order, "ii", $order_id, $user_id);
        mysqli_stmt_execute($stmt_order);
        $result_order = mysqli_stmt_get_result($stmt_order);
        
        if (mysqli_num_rows($result_order) > 0) {
            $order_data = mysqli_fetch_assoc($result_order);
            
            // Ambil details dan hitung subtotal items (FINAL: get_result sekali, fetch di loop)
            $query_details = "SELECT od.*, p.product_name FROM tb_order_detail od 
                              JOIN tb_product p ON od.product_id = p.product_id 
                              WHERE od.order_id = ?";
            $stmt_details = mysqli_prepare($conn, $query_details);
            if ($stmt_details) {
                mysqli_stmt_bind_param($stmt_details, "i", $order_id);
                mysqli_stmt_execute($stmt_details);
                $result_details = mysqli_stmt_get_result($stmt_details); // Panggil SEKALI di sini
                
                while ($row = mysqli_fetch_assoc($result_details)) { // Fetch berulang di loop
                    $details[] = $row;
                    $subtotal_items += (float)($row['subtotal'] ?? 0); // Cast ke float untuk aman
                }
                
                mysqli_free_result($result_details); // Be                mysqli_stmt_close($stmt_details);
            } else {
                error_log("Error prepare details: " . mysqli_error($conn));
                $_SESSION['error'] = 'Error mengambil detail pesanan.';
                header("Location: index.php");
                exit;
            }
            
            // Total lengkap dari DB (sudah include ongkir dari checkout)
            $total = (float)($order_data['total_amount'] ?? 0);
            
            // Hitung ulang ongkir berdasarkan alamat (sama logika seperti checkout.php untuk konsistensi)
            $alamat = trim($order_data['alamat'] ?? '');
            $lower_alamat = strtolower($alamat);
            if (strlen($alamat) >= 10) {
                if (strpos($lower_alamat, 'tasik') !== false || strpos($lower_alamat, 'unsil') !== false || 
                    strpos($lower_alamat, 'katumbiri') !== false || strpos($lower_alamat, 'indihiang') !== false) {
                    $ongkir_estimated = 15000;
                } else if (strpos($lower_alamat, 'bandung') !== false || strpos($lower_alamat, 'cirebon') !== false || 
                           strpos($lower_alamat, 'garut') !== false) {
                    $ongkir_estimated = 30000;
                } else if (strpos($lower_alamat, 'jakarta') !== false || strpos($lower_alamat, 'bekasi') !== false || 
                           strpos($lower_alamat, 'bogor') !== false) {
                    $ongkir_estimated = 50000;
                } else {
                    $ongkir_estimated = 20000; // Default
                }
            } else {
                $ongkir_estimated = 0; // Jika alamat terlalu pendek, ongkir 0 (hindari error tampilan)
            }
            
        } else {
            // Order tidak ditemukan (mungkin invalid atau bukan milik user)
            $_SESSION['error'] = 'Pesanan tidak ditemukan atau tidak valid.';
            header("Location: index.php");
            exit;
        }
        mysqli_stmt_close($stmt_order);
    } else {
        error_log("Error prepare order: " . mysqli_error($conn));
        $_SESSION['error'] = 'Error sistem. Coba lagi.';
        header("Location: index.php");
        exit;
    }
} else {
    $_SESSION['error'] = 'ID pesanan tidak valid.';
    header("Location: index.php");
    exit;
}

mysqli_close($conn);
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Ruang Sukma - Pesanan Berhasil</title>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Google Fonts: Poppins -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <!-- Font Awesome -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
  <!-- AOS Animations -->
  <link href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css" rel="stylesheet">
  <style>
    body {
      font-family: 'Poppins', sans-serif;
      background: linear-gradient(135deg, #f4f6f8, #e9ecef);
      color: #333;
      line-height: 1.6;
      padding-top: 80px;
    }
    .success-section { max-width: 900px; margin: 2rem auto; padding: 0 1rem; }
    .success-card { background: #fff; border-radius: 20px; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.1); text-align: center; }
    .success-icon { font-size: 4rem; color: #28a745; margin-bottom: 1rem; animation: pulse 2s infinite; }
    @keyframes pulse { 0% { transform: scale(1); } 50% { transform: scale(1.05); } 100% { transform: scale(1); } }
    .success-title { color: #28a745; font-weight: 700; margin-bottom: 1rem; }
    .order-info { background: #f8f9fa; padding: 1.5rem; border-radius: 10px; margin: 1rem 0; }
    .detail-item { display: flex; justify-content: space-between; padding: 0.5rem 0; border-bottom: 1px solid #eee; }
    .price-breakdown { background: #e8f5e8; padding: 1rem; border-radius: 10px; margin: 1rem 0; }
    .price-row { display: flex; justify-content: space-between; margin-bottom: 0.5rem; }
    .price-label { color: #666; }
    .price-value { font-weight: 600; color: #333; }
    .total-row .price-value { color: #d83a4a; font-size: 1.2rem; font-weight: 700; }
    .btn-continue { background: linear-gradient(135deg, #d83a4a, #c82333); color: #fff; border: none; padding: 1rem 2rem; border-radius: 50px; font-weight: 600; transition: all 0.3s; }
    .btn-continue:hover { background: linear-gradient(135deg, #c82333, #b21f2d); transform: translateY(-2px); }
    .navbar-custom { background: rgba(216, 58, 74, 0.95) !important; backdrop-filter: blur(20px); box-shadow: 0 4px 20px rgba(216, 58, 74, 0.2); padding: 1rem 0; }
    .navbar-brand { font-weight: 700; font-size: 1.8rem; color: #fff !important; }
    .nav-link { color: #fff !important; font-weight: 500; padding: 0.5rem 1rem; }
    .nav-link:hover { color: #f8f9fa !important; }
    .cart-badge { background: #fff; color: #d83a4a; border-radius: 50%; padding: 4px 8px; font-size: 0.8rem; }
    footer { background: linear-gradient(135deg, #333, #555); color: #fff; text-align: center; padding: 3rem 1rem; margin-top: 5rem; }
    .social-links a { color: #fff; font-size: 1.5rem; margin: 0 1rem; transition: color 0.3s; }
    .social-links a:hover { color: #d83a4a; }
    @media (max-width: 768px) {
      .navbar-brand { font-size: 1.5rem; }
      .detail-item, .price-row { flex-direction: column; align-items: flex-start; gap: 0.25rem; }
      .success-icon { font-size: 3rem; }
    }
  </style>
</head>
<body>

<!-- Navbar (Konsisten dengan checkout.php, cart kosong setelah sukses) -->
<nav class="navbar navbar-expand-lg navbar-custom fixed-top">
  <div class="container">
    <a class="navbar-brand" href="index.php"><i class="fas fa-home me-2"></i>Ruang Sukma</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"><span class="navbar-toggler-icon"></span></button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link" href="index.php"><i class="fas fa-home me-1"></i>Home</a></li>
        <li class="nav-item"><a class="nav-link" href="index.php"><i class="fas fa-box me-1"></i>Produk</a></li>
        <li class="nav-item position-relative">
          <a class="nav-link" href="cart.php">
            <i class="fas fa-shopping-cart me-1"></i>Keranjang
            <?php if(isset($_SESSION['cart']) && count($_SESSION['cart']) > 0): ?>
              <span class="cart-badge"><?php echo count($_SESSION['cart']); ?></span>
            <?php endif; ?>
          </a>
        </li>
        <li class="nav-item"><span class="nav-link text-white">Halo, <?php echo htmlspecialchars($_SESSION['user_name'] ?? 'User  '); ?>!</span></li>
        <li class="nav-item"><a class="nav-link" href="logout_user.php"><i class="fas fa-sign-out-alt me-1"></i>Logout</a></li>
      </ul>
    </div>
  </div>
</nav>

<!-- Success Section (Lengkap: Info, Items, Breakdown, Pengiriman, Pembayaran) -->
<section class="success-section" data-aos="fade-up">
  <div class="container">
    <div class="success-card">
      <div class="p-4">
        <i class="fas fa-check-circle success-icon"></i>
        <h2 class="success-title">Pesanan Berhasil!</h2>
        <p class="lead">Terima kasih atas pembelian Anda. Pesanan Anda telah dikonfirmasi dan akan diproses segera.</p>
        
        <!-- Info Order Dasar -->
        <div class="order-info">
          <h5><i class="fas fa-receipt me-2"></i>Detail Pesanan</h5>
          <div class="row">
            <div class="col-md-6">
              <p><strong>ID Pesanan:</strong> #<?php echo $order_id; ?></p>
              <p><strong>Tanggal:</strong> <?php echo date('d/m/Y H:i', strtotime($order_data['order_date'] ?? 'now')); ?></p>
            </div>
            <div class="col-md-6">
              <p><strong>Total Bayar:</strong> Rp <?php echo number_format($total, 0, ',', '.'); ?></p>
            </div>
          </div>
        </div>
        
        <!-- Daftar Item Pesanan -->
        <div class="mb-4">
          <h5><i class="fas fa-list me-2"></i>Daftar Belanja</h5>
          <?php if (!empty($details)): ?>
            <?php foreach ($details as $detail): ?>
              <div class="detail-item">
                <span><?php echo htmlspecialchars($detail['product_name']); ?> (x<?php echo $detail['quantity']; ?>)</span>
                <span>Rp <?php echo number_format($detail['subtotal'], 0, ',', '.'); ?></span>
              </div>
            <?php endforeach; ?>
          <?php else: ?>
            <p class="text-muted">Tidak ada item pesanan (hubungi admin jika ini error).</p>
          <?php endif; ?>
        </div>
        
        <!-- Breakdown Harga (Lengkap: Subtotal + Ongkir Estimasi + Total dari DB) -->
        <div class="price-breakdown">
          <h6><i class="fas fa-calculator me-2"></i>Rincian Harga</h6>
          <div class="price-row">
            <span class="price-label">Subtotal Belanja:</span>
            <span class="price-value">Rp <?php echo number_format($subtotal_items, 0, ',', '.'); ?></span>
          </div>
          <div class="price-row">
            <span class="price-label">Ongkir (Estimasi dari alamat: <?php echo htmlspecialchars(substr($alamat, 0, 50)) . (strlen($alamat) > 50 ? '...' : ''); ?>):</span>
            <span class="price-value">Rp <?php echo number_format($ongkir_estimated, 0, ',', '.'); ?></span>
          </div>
          <div class="price-row total-row">
            <span class="price-label">Total Bayar (Include Ongkir):</span>
            <span class="price-value">Rp <?php echo number_format($total, 0, ',', '.'); ?></span>
          </div>
          <small class="text-muted d-block mt-2">Ongkir dihitung berdasarkan lokasi pengiriman. Total di atas adalah nilai final dari pesanan Anda.</small>
        </div>
        
        <!-- Info Pengiriman & Pembayaran -->
        <div class="row mb-4">
          <div class="col-md-6">
            <h6><i class="fas fa-map-marker-alt me-2 text-primary"></i>Pengiriman</h6>
            <p><strong>Alamat Lengkap:</strong><br><?php echo nl2br(htmlspecialchars($order_data['alamat'] ?? 'Tidak tersedia')); ?></p>
            <p><strong>Telepon/WhatsApp:</strong> <?php echo htmlspecialchars($order_data['phone'] ?? 'Tidak tersedia'); ?></p>
          </div>
          <div class="col-md-6">
            <h6><i class="fas fa-credit-card me-2 text-success"></i>Pembayaran</h6>
            <p><strong>Metode:</strong> <?php 
              $method = $order_data['payment_method'] ?? 'Tidak tersedia';
              $method_icon = ($method == 'COD') ? '<i class="fas fa-truck text-success"></i>' : '<i class="fas fa-bank text-primary"></i>';
              echo $method_icon . ' ' . htmlspecialchars($method);
            ?></p>
            <?php if ($method == 'Transfer'): ?>
              <small class="text-muted">Transfer ke BCA 1234567890 a.n. Ruang Sukma. Konfirmasi pembayaran via WhatsApp setelah transfer.</small>
            <?php else: ?>
              <small class="text-muted">Bayar saat barang diterima (COD).</small>
            <?php endif; ?>
          </div>
        </div>
        
        <!-- Alert Info -->
        <div class="alert alert-info mt-4">
          <i class="fas fa-info-circle me-2"></i>
          Pesanan Anda akan diproses dalam 24 jam kerja. Pantau status pesanan di <a href="orders.php" class="alert-link">Riwayat Pesanan</a>. Jika halaman riwayat belum tersedia, hubungi admin via WhatsApp atau email. Terima kasih!
        </div>
        
        <!-- Buttons -->
        <div class="mt-4">
          <a href="index.php" class="btn btn-continue me-2"><i class="fas fa-shopping-bag me-2"></i>Lanjut Belanja</a>
          <a href="orders.php" class="btn btn-outline-primary"><i class="fas fa-history me-2"></i>Lihat Riwayat Pesanan</a>
          <a href="cart.php" class="btn btn-outline-secondary ms-2"><i class="fas fa-shopping-cart me-2"></i>Keranjang (Kosong)</a>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Footer (Konsisten dengan checkout.php) -->
<footer class="text-center py-5" data-aos="fade-up">
  <div class="container">
    <div class="row">
      <div class="col-md-6">
        <h5 class="text-white mb-3">Ruang Sukma</h5>
        <p class="text-light">Toko online terpercaya untuk kebutuhan rumah tangga dan kantor. Kualitas terbaik, harga terjangkau.</p>
      </div>
      <div class="col-md-6">
        <h5 class="text-white mb-3">Hubungi Kami</h5>
        <p class="text-light">Email: info@ruangsukma.com | Telp: (021) 123-4567</p>
        <div class="social-links">
          <a href="#"><i class="fab fa-facebook-f"></i></a>
          <a href="#"><i class="fab fa-instagram"></i></a>
          <a href="#"><i class="fab fa-twitter"></i></a>
          <a href="#"><i class="fab fa-whatsapp"></i></a>
        </div>
      </div>
    </div>
    <hr class="my-4 border-light">
    <p class="text-light mb-0">&copy; 2024 Ruang Sukma. All rights reserved. | <a href="tentang.php" class="text-light">Tentang Kami</a></p>
  </div>
</footer>

<!-- Scripts (Konsisten dengan checkout.php) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
<script>
  AOS.init({ duration: 1000, once: true, offset: 100 });
  
  // Optional: Auto-print atau share (untuk user experience lebih baik)
  window.addEventListener('load', function() {
    // Tampilkan notifikasi sukses (jika pakai Bootstrap toast, bisa tambah)
    console.log('Pesanan berhasil! Order ID: <?php echo $order_id;     ?>');
    
    // Optional: Smooth scroll ke atas saat load
    window.scrollTo({ top: 0, behavior: 'smooth' });
    
    // Optional: Tombol print halaman (untuk user cetak receipt)
    const printBtn = document.createElement('button');
    printBtn.innerHTML = '<i class="fas fa-print me-1"></i>Cetak Receipt';
    printBtn.className = 'btn btn-outline-success mt-2';
    printBtn.onclick = function() {
      window.print();
    };
    const buttonsDiv = document.querySelector('.mt-4');
    if (buttonsDiv) {
      buttonsDiv.appendChild(printBtn);
    }
    
    // Optional: Auto-hide alert setelah 10 detik (jika ada alert lain)
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
      setTimeout(() => {
        alert.style.transition = 'opacity 0.5s';
        alert.style.opacity = '0';
        setTimeout(() => alert.remove(), 500);
      }, 10000);
    });
  });
</script>

</body>
</html>
<?php
// Penutup koneksi (sudah ditutup di atas, tapi pastikan tidak ada loose connection)
if (isset($conn) && mysqli_ping($conn)) {
    mysqli_close($conn);
}
// Hapus session error jika ada (untuk clean state setelah sukses)
if (isset($_SESSION['error'])) {
    unset($_SESSION['error']);
}
?>