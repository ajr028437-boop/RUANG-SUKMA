<?php
session_start();
include 'db.php';
if($_SESSION['status_login'] != true){
    echo '<script>window.location="login.php"</script>';
}

// Tambahan untuk pagination
$limit = 10; // Jumlah produk per halaman
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$page = max(1, $page);
$offset = ($page - 1) * $limit;

// Query total produk untuk pagination
$total_query = "SELECT COUNT(*) AS total FROM tb_product";
$total_result = mysqli_query($conn, $total_query);
$total_row = mysqli_fetch_assoc($total_result);
$total_records = $total_row['total'];
$total_pages = ceil($total_records / $limit);

// Modifikasi query produk dengan LIMIT dan OFFSET
$query = "SELECT * FROM tb_product ORDER BY product_id DESC LIMIT $limit OFFSET $offset";
$produk = mysqli_query($conn, $query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Data Produk - Ruang Sukma</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Quicksand&display=swap');

    body {
      font-family: 'Quicksand', sans-serif;
      background-color: #f9fafb;
      margin: 0;
      min-height: 100vh;
    }
    .sidebar {
      min-height: 100vh;
      background: #d32f2f;
      color: #fff;
      padding: 30px 0;
      box-shadow: 3px 0 8px rgba(0,0,0,0.1);
    }
    .sidebar h4 {
      font-weight: 700;
      font-size: 1.6rem;
      margin-bottom: 2rem;
      text-align: center;
      letter-spacing: 1px;
    }
    .sidebar a {
      color: #fff;
      text-decoration: none;
      display: block;
      padding: 12px 25px;
      border-radius: 10px;
      margin: 8px 15px;
      font-weight: 600;
      font-size: 1rem;
      transition: background-color 0.3s ease, transform 0.2s ease;
      box-shadow: inset 0 0 0 0 transparent;
    }
    .sidebar a.active, .sidebar a:hover {
      background: #b71c1c;
      box-shadow: inset 5px 0 0 0 #ff5252;
      transform: translateX(5px);
    }
    .content {
      padding: 30px 40px;
      background-color: #fff;
      min-height: 100vh;
    }
    .btn-primary {
      background: #e53935;
      border: none;
      font-weight: 600;
      padding: 10px 20px;
      border-radius: 8px;
      box-shadow: 0 4px 8px rgb(229 38 16 / 0.4);
      transition: background-color 0.3s ease, box-shadow 0.3s ease;
    }
    .btn-primary:hover {
      background: #b71c1c;
      box-shadow: 0 6px 12px rgb(204 0 0 / 0.6);
    }
    .card {
      border-radius: 12px;
      box-shadow: 0 6px 15px rgb(0 0 0 / 0.1);
      border: none;
    }
    .card-body {
      padding: 1.8rem 2rem;
    }
    table {
      border-collapse: separate !important;
      border-spacing: 0 10px !important;
      width: 100%;
    }
    thead tr {
      background-color: #b71c1c !important;
      color: #fff;
      border-radius: 12px;
    }
    thead th {
      border: none !important;
      font-weight: 700;
      font-size: 1rem;
      padding: 12px 15px;
      vertical-align: middle;
      text-align: center;
    }
    tbody tr {
      background-color: #fff;
      box-shadow: 0 2px 8px rgb(0 0 0 / 0.05);
      border-radius: 10px;
      transition: box-shadow 0.3s ease;
    }
    tbody tr:hover {
      box-shadow: 0 6px 20px rgb(0 0 0 / 0.12);
    }
    tbody td {
      vertical-align: middle;
      padding: 15px 12px;
      font-size: 0.95rem;
      color: #333;
      border: none !important;
      text-align: center;
    }
    tbody td.description {
      text-align: left;
      max-width: 250px;
      white-space: normal;
      word-wrap: break-word;
    }
    tbody td img {
      border-radius: 8px;
      box-shadow: 0 2px 6px rgb(0 0 0 / 0.1);
      transition: transform 0.3s ease;
      max-width: 80px;
      height: auto;
    }
    tbody td img:hover {
      transform: scale(1.05);
    }
    .btn-warning {
      background-color: #fbc02d;
      border: none;
      font-weight: 600;
      padding: 6px 14px;
      border-radius: 6px;
      box-shadow: 0 3px 8px rgb(251 192 45 / 0.4);
      transition: background-color 0.3s ease;
      color: #333;
      margin-right: 5px;
    }
    .btn-warning:hover {
      background-color: #c49000;
      color: #fff;
    }
    .btn-danger {
      background-color: #e53935;
      border: none;
      font-weight: 600;
      padding: 6px 14px;
      border-radius: 6px;
      box-shadow: 0 3px 8px rgb(229 57 53 / 0.4);
      transition: background-color 0.3s ease;
    }
    .btn-danger:hover {
      background-color: #b71c1c;
    }
    .category-badge {
      background: #e3f2fd;
      color: #1976d2;
      padding: 4px 8px;
      border-radius: 12px;
      font-size: 0.85rem;
      font-weight: 600;
    }
    .pagination {
      justify-content: center;
      margin-top: 2rem;
    }
    .pagination .page-link {
      color: #d32f2f;
      border-color: #d32f2f;
    }
    .pagination .page-link:hover {
      background-color: #d32f2f;
      color: #fff;
    }
    .pagination .page-item.active .page-link {
      background-color: #d32f2f;
      border-color: #d32f2f;
    }
  </style>
</head>
<body>
<div class="container-fluid">
  <div class="row">
    <!-- Sidebar -->
    <nav class="col-md-2 sidebar d-flex flex-column">
      <h4 class="text-center mb-4">📌 Ruang Sukma</h4>
      <a href="dashboard.php">📊 Dashboard</a>
      <a href="profil.php">👤 Profil</a>
      <a href="data-kategori.php">📂 Data Kategori</a>
      <a href="data-produk.php" class="active">📦 Data Produk</a>
      <a href="data-pesenan.php">🧾 Data Pesanan</a>
      <a href="data-pendapatan.php">💰 Data Pendapatan</a>
      <a href="data-pengeluaran.php">💸 Data Pengeluaran</a>
      <a href="keluar.php">🚪 Keluar</a>
    </nav>

    <!-- Main Content -->
    <main class="col-md-10 content">
      <div class="d-flex justify-content-between align-items-center mb-4">
        <h3>📦 Data Produk</h3>
        <a href="tambah-produk.php" class="btn btn-primary">+ Tambah Produk</a>
      </div>

      <div class="card shadow-sm">
        <div class="card-body table-responsive">
          <table class="table table-bordered align-middle">
            <thead>
              <tr>
                <th width="60px">No</th>
                <th>Kategori</th>
                <th>Nama Produk</th>
                <th style="min-width:120px;">Harga</th>
                <th style="min-width:200px;">Deskripsi</th>
                <th>Gambar</th>
                <th>Status</th>
                <th width="150px">Aksi</th>
              </tr>
            </thead>
            <tbody>
              <?php 
                $no = ($page - 1) * $limit + 1; // Nomor urut berdasarkan halaman
                if($produk && mysqli_num_rows($produk) > 0){
                  while ($row = mysqli_fetch_array($produk)) {
              ?>
              <tr>
                <td><?= $no++; ?></td>
                <td>
                  <?php if (!empty($row['category_name'])): ?>
                    <span class="category-badge"><?= htmlspecialchars($row['category_name']); ?></span>
                  <?php else: ?>
                    -
                  <?php endif; ?>
                </td>
                <td><?= htmlspecialchars($row['product_name']); ?></td>
                <td>Rp. <?= number_format($row['product_price']); ?></td>
                <td class="description"><?= nl2br(htmlspecialchars($row['product_description'])); ?></td>
                <td>
                  <?php if($row['product_image'] != "") { ?>
                    <img src="produk/<?= htmlspecialchars($row['product_image']) ?>" alt="Gambar Produk" />
                  <?php } else { echo "-"; } ?>
                </td>
                <td><?= ($row['product_status'] == 0)? 'Tidak Tersedia':'Tersedia'; ?></td>
                <td>
                  <a href="edit-produk.php?id=<?= $row['product_id']; ?>" class="btn btn-warning">Edit</a>
                  <a href="proses-hapus-produk.php?id=<?= $row['product_id']; ?>" class="btn btn-danger" onclick="return confirm('Yakin ingin menghapus produk ini?')">Hapus</a>
                </td>
              </tr>
              <?php 
                  }
                } else {
              ?>
              <tr>
                <td colspan="8" class="text-center py-4">Tidak ada data produk tersedia.</td>
              </tr>
              <?php } ?>
            </tbody>
          </table>
        </div>
      </div>

      <!-- Pagination di bawah tabel -->
      <?php if ($total_pages > 1): ?>
        <nav aria-label="Page navigation">
          <ul class="pagination">
            <?php if ($page > 1): ?>
              <li class="page-item">
                <a class="page-link" href="?page=<?= $page - 1 ?>" aria-label="Previous">
                  <span aria-hidden="true">&laquo;</span>
                </a>
              </li>
            <?php endif; ?>

            <?php
            $start_page = max(1, $page - 2);
            $end_page = min($total_pages, $page + 2);
            for ($i = $start_page; $i <= $end_page; $i++): ?>
              <li class="page-item <?= $i == $page ? 'active' : '' ?>">
                <a class="page-link" href="?page=<?= $i ?>"><?= $i ?></a>
              </li>
            <?php endfor; ?>

            <?php if ($page < $total_pages): ?>
              <li class="page-item">
                <a class="page-link" href="?page=<?= $page + 1 ?>" aria-label="Next">
                  <span aria-hidden="true">&raquo;</span>
                </a>
              </li>
            <?php endif; ?>
          </ul>
        </nav>
      <?php endif; ?>
    </main>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>