<?php
   session_start();
   include 'db.php';
   if($_SESSION['status_login'] != true){
      echo '<script>window.location="login.php"</script>';
   }

   // pastikan ada parameter id
   if(isset($_GET['id'])){
      $id = $_GET['id'];

      // cek apakah id ada di database
      $cek = mysqli_query($conn, "SELECT * FROM tb_category WHERE category_id = '".$id."' ");
      if(mysqli_num_rows($cek) > 0){
         $delete = mysqli_query($conn, "DELETE FROM tb_category WHERE category_id = '".$id."' ");
         if($delete){
            echo '<script>alert("Data berhasil dihapus")</script>';
         } else {
            echo '<script>alert("Gagal menghapus data: '.mysqli_error($conn).'")</script>';
         }
      }
   }

   // kembali ke halaman data-kategori
   echo '<script>window.location="data-kategori.php"</script>';
?>
