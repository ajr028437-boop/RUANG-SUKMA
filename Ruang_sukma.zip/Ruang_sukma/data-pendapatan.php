<?php
session_start();
include 'db.php';  // Koneksi DB bersama (pastikan db.php ada)

// Cek login (konsisten dengan data-pesenan.php)
if($_SESSION['status_login'] != true){
    echo '<script>window.location="login.php"</script>';
}

// Query otomatis: Pendapatan murni dari pesanan (completed), GROUP BY bulan
$query = "
    SELECT DATE_FORMAT(order_date, '%Y-%m') AS bulan, 
           SUM(total_amount) AS total_pendapatan
    FROM tb_order 
    WHERE status = 'completed'
    GROUP BY bulan
    ORDER BY bulan DESC
";
$result = mysqli_query($conn, $query);

// Fitur Export ke Excel/CSV (dari query otomatis)
if (isset($_GET['export']) && $_GET['export'] == 'excel') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=pendapatan_per_bulan.csv');
    $output = fopen('php://output', 'w');
    
    fputcsv($output, ['Bulan', 'Total Pendapatan (Rp) - Dari Pesanan Selesai']);
    
    if ($result && mysqli_num_rows($result) > 0) {
        mysqli_data_seek($result, 0);  // Reset result pointer
        while ($row = mysqli_fetch_assoc($result)) {
            fputcsv($output, [
                $row['bulan'],
                'Rp ' . number_format($row['total_pendapatan'], 0, ',', '.')
            ]);
        }
    } else {
        fputcsv($output, ['Tidak ada data pendapatan (cek pesanan completed)']);
    }
    
    fclose($output);
    mysqli_close($conn);
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Data Pendapatan - Ruang Sukma</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        /* Style sama seperti sebelumnya */
        @import url('https://fonts.googleapis.com/css2?family=Quicksand&display=swap');

        body {
            font-family: 'Quicksand', sans-serif;
            background-color: #f9fafb;
            margin: 0;
            min-height: 100vh;
        }
        .sidebar {
            min-height: 100vh;
            background: #d32f2f;
            color: #fff;
            padding: 30px 0;
            box-shadow: 3px 0 8px rgba(0,0,0,0.1);
            width: 250px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        .sidebar h2 {
            font-weight: 700;
            font-size: 1.8rem;
            margin-bottom: 2rem;
            letter-spacing: 1px;
            text-align: center;
        }
        .sidebar a {
            color: #fff;
            font-weight: 600;
            font-size: 1rem;
            padding: 12px 25px;
            border-radius: 10px;
            margin: 8px 15px;
            text-decoration: none;
            width: 100%;
            transition: background-color 0.3s ease, transform 0.2s ease;
            display: block;
        }
        .sidebar a.active, .sidebar a:hover {
            background: #b71c1c;
            box-shadow: inset 5px 0 0 0 #ff5252;
            transform: translateX(5px);
            text-decoration: none;
        }
        .content {
            flex-grow: 1;
            background-color: #fff;
            min-height: 100vh;
            padding: 30px 40px;
        }
        h2.page-title {
            margin-bottom: 1.5rem;
            font-weight: 700;
        }
        .card {
            border-radius: 12px;
            box-shadow: 0 6px 15px rgb(0 0 0 / 0.1);
            border: none;
            margin-bottom: 2rem;
        }
        .card-body {
            padding: 2rem;
        }
        table {
            border-collapse: separate !important;
            border-spacing: 0 10px !important;
            width: 100%;
        }
        thead tr {
            background-color: #b71c1c !important;
            color: #fff;
            border-radius: 12px;
        }
        thead th {
            border: none !important;
            font-weight: 700;
            font-size: 1rem;
            padding: 12px 15px;
            vertical-align: middle;
            text-align: center;
        }
        tbody tr {
            background-color: #fff;
            box-shadow: 0 2px 8px rgb(0 0 0 / 0.05);
            border-radius: 10px;
            transition: box-shadow 0.3s ease;
        }
        tbody tr:hover {
            box-shadow: 0 6px 20px rgb(0 0 0 / 0.12);
        }
        tbody td {
            vertical-align: middle;
            padding: 15px 12px;
            font-size: 0.95rem;
            color: #333;
            border: none !important;
            text-align: center;
            word-wrap: break-word;
        }
        tbody td.text-start {
            text-align: left;
        }
        .btn-export {
            background-color: #ff9800;
            color: #fff;
            border: none;
            padding: 8px 16px;
            border-radius: 8px;
            font-weight: 600;
            text-decoration: none;
            display: inline-block;
            margin-bottom: 1rem;
            transition: background-color 0.3s ease;
        }
        .btn-export:hover {
            background-color: #f57c00;
            color: #fff;
        }
        .explanation {
            background: #d4edda;
            border: 1px solid #c3e6cb;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 1.5rem;
            font-size: 0.95rem;
        }
        .explanation h6 {
            color: #155724;
            margin-bottom: 8px;
        }
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                min-height: auto;
                flex-direction: row;
                justify-content: space-around;
                padding: 15px 0;
            }
            .sidebar h2 {
                display: none;
            }
            .sidebar a {
                margin: 0 5px;
                padding: 8px 12px;
                font-size: 0.9rem;
                text-align: center;
                flex-grow: 1;
            }
            .content {
                padding: 20px 15px;
                min-height: auto;
            }
            table {
                font-size: 0.85rem;
            }
            thead th, tbody td {
                padding: 10px 8px;
            }
            .btn-export {
                width: 100%;
                text-align: center;
            }
        }
    </style>
</head>
<body>
    <div class="d-flex flex-column flex-md-row min-vh-100">
        <!-- Sidebar -->
        <nav class="sidebar d-flex flex-column">
            <h2>Ruang Sukma</h2>
            <a href="dashboard.php" class="nav-link">📊 Dashboard</a>
            <a href="profil.php" class="nav-link">👤 Profil</a>
            <a href="data-kategori.php" class="nav-link">📂 Data Kategori</a>
            <a href="data-produk.php" class="nav-link">📦 Data Produk</a>
            <a href="data-pesenan.php" class="nav-link">🧾 Data Pesanan</a>
            <a href="data-pendapatan.php" class="nav-link active">💰 Data Pendapatan</a>
            <a href="data-pengeluaran.php" class="nav-link">💸 Data Pengeluaran</a>
            <a href="keluar.php" class="nav-link">🚪 Keluar</a>
        </nav>

        <!-- Content -->
        <main class="content">
            <h2 class="page-title">💰 Data Pendapatan</h2>

            <!-- Penjelasan singkat (otomatis dari pesanan) -->
            <div class="explanation">
                <h6><i class="fas fa-info-circle me-2"></i>Catatan:</h6>
                <p>Total pendapatan dihitung <strong>otomatis dan real-time</strong> dari <strong>pesanan selesai (completed)</strong> di tabel pesanan. Setiap kali status pesanan diubah ke 'completed' di halaman Data Pesanan, total di sini akan update langsung tanpa perlu tambah manual.</p>
            </div>

            <!-- Button Export -->
            <div class="mb-3">
                <a href="?export=excel" class="btn-export"><i class="fas fa-download me-2"></i>Export to Excel</a>
            </div>

            <!-- Tabel Data Pendapatan (otomatis dari pesanan) -->
            <div class="card shadow-sm">
                <div class="card-body">
                    <h5 class="card-title mb-3">Ringkasan Pendapatan per Bulan (dari Pesanan Selesai)</h5>
                    <table class="table table-striped table-bordered align-middle">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Bulan</th>
                                <th>Total Pendapatan (Rp)</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $no = 1;
                            if(mysqli_num_rows($result) > 0):
                                while($row = mysqli_fetch_assoc($result)): ?>
                                <tr>
                                    <td><?= $no++ ?></td>
                                    <td class="text-start"><?= htmlspecialchars($row['bulan']) ?></td>
                                    <td class="text-end" style="color: #4caf50; font-weight: bold;">Rp <?= number_format($row['total_pendapatan'], 0, ',', '.') ?></td>
                                </tr>
                            <?php 
                                endwhile;
                            else: ?>
                                <tr>
                                    <td colspan="3" class="text-center py-4">
                                        <i class="fas fa-inbox fa-2x text-muted mb-2"></i><br>
                                        Belum ada data pendapatan. Silakan update status pesanan ke 'completed' di <a href="data-pesenan.php">Data Pesanan</a>.
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
// Tutup koneksi DB
mysqli_close($conn);
?>