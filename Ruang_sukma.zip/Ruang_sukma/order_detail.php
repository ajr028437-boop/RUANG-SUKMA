<?php
// order_detail.php - Detail Pesanan Spesifik dengan Auto-Update Status
session_start();
include 'db.php';

// Jika belum login, redirect ke login
if (!isset($_SESSION['user_login']) || $_SESSION['user_login'] !== true || !isset($_SESSION['user_id'])) {
    header("Location: login_user.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$order_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($order_id <= 0) {
    header("Location: orders.php?error=invalid_order");
    exit;
}

// TAMBAHAN: Handling AJAX untuk polling status (return JSON jika ajax=1)
if (isset($_GET['ajax']) && $_GET['ajax'] == 1) {
    $ajax_query = "SELECT status FROM tb_order WHERE order_id = ? AND user_id = ?";
    $stmt_ajax = mysqli_prepare($conn, $ajax_query);
    if ($stmt_ajax) {
        mysqli_stmt_bind_param($stmt_ajax, "ii", $order_id, $user_id);
        mysqli_stmt_execute($stmt_ajax);
        $result_ajax = mysqli_stmt_get_result($stmt_ajax);
        if ($row = mysqli_fetch_assoc($result_ajax)) {
            header('Content-Type: application/json');
            echo json_encode(['status' => $row['status']]);
        } else {
            http_response_code(404);
            echo json_encode(['error' => 'Order not found']);
        }
        mysqli_stmt_close($stmt_ajax);
    } else {
        http_response_code(500);
        echo json_encode(['error' => 'Database error']);
    }
    exit;  // Stop, jangan tampilkan HTML
}

// Ambil data nama user untuk navbar
$user_name = $_SESSION['user_name'] ?? null;
if (!$user_name) {
    $stmt_name = mysqli_prepare($conn, "SELECT nama FROM tb_user WHERE id = ?");
    if ($stmt_name) {
        mysqli_stmt_bind_param($stmt_name, "i", $user_id);
        mysqli_stmt_execute($stmt_name);
        $result_name = mysqli_stmt_get_result($stmt_name);
        if ($result_name && mysqli_num_rows($result_name) > 0) {
            $user_data = mysqli_fetch_assoc($result_name);
            $user_name = $user_data['nama'];
            $_SESSION['user_name'] = $user_name;
        }
        mysqli_stmt_close($stmt_name);
    }
}

// Query detail order (include alamat dari tb_user)
$order_query = "
SELECT 
    o.order_id,
    o.total_amount,
    o.status,
    o.order_date,
    u.nama AS user_name,
    CONCAT(COALESCE(u.alamat, ''), ', ', COALESCE(u.lokasi, '')) AS shipping_address
FROM tb_order o
JOIN tb_user u ON o.user_id = u.id
WHERE o.order_id = ? AND o.user_id = ?
";

$stmt_order = mysqli_prepare($conn, $order_query);
if ($stmt_order) {
    mysqli_stmt_bind_param($stmt_order, "ii", $order_id, $user_id);
    mysqli_stmt_execute($stmt_order);
    $result_order = mysqli_stmt_get_result($stmt_order);
    $order = mysqli_fetch_assoc($result_order);

    if (!$order) {
        header("Location: orders.php?error=order_not_found");
        exit;
    }
    mysqli_stmt_close($stmt_order);
} else {
    header("Location: orders.php?error=database_error");
    exit;
}

// TAMBAHAN: Simpan status awal untuk perbandingan JS
$initial_status = $order['status'];

// Query detail produk
$details_query = "
SELECT 
    d.quantity,
    d.subtotal,
    p.Product_name AS product_name,
    p.Product_image AS product_image,
    (d.subtotal / d.quantity) AS price
FROM tb_order_detail d
JOIN tb_product p ON d.product_id = p.Product_id
WHERE d.order_id = ?
";

$stmt_details = mysqli_prepare($conn, $details_query);
if ($stmt_details) {
    mysqli_stmt_bind_param($stmt_details, "i", $order_id);
    mysqli_stmt_execute($stmt_details);
    $result_details = mysqli_stmt_get_result($stmt_details);
    $order_details = [];
    $total_items = 0;
    while ($detail = mysqli_fetch_assoc($result_details)) {
        $order_details[] = $detail;
        $total_items += $detail['quantity'];
    }
    mysqli_stmt_close($stmt_details);
} else {
    $order_details = [];
    $total_items = 0;
}

// Status messages dan ikon (untuk tampilan & JS)
$status_messages = [
    'pending' => 'Menunggu Pembayaran & Konfirmasi',
    'processing' => 'Sedang Diproses (Packing & Pengiriman)',
    'completed' => 'Pesanan Selesai & Diterima'
];
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Detail Pesanan #<?= $order_id ?> - Ruang Sukma</title>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Google Fonts: Poppins -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <!-- Font Awesome -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
  <!-- AOS Animations -->
  <link href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css" rel="stylesheet">
  <style>
    body {
      font-family: 'Poppins', sans-serif;
      background: linear-gradient(135deg, #f4f6f8, #e9ecef);
      color: #333;
      line-height: 1.6;
      padding-top: 80px;
    }
    a { text-decoration: none; }
    /* Navbar Modern */
    .navbar-custom {
      background: rgba(216, 58, 74, 0.95) !important;
      backdrop-filter: blur(20px);
      box-shadow: 0 4px 20px rgba(216, 58, 74, 0.2);
      padding: 1rem 0;
    }
    .navbar-brand { font-weight: 700; font-size: 1.8rem; color: #fff !important; }
    .nav-link { color: #fff !important; font-weight: 500; padding: 0.5rem 1rem; }
    .nav-link:hover { color: #f8f9fa !important; }
    /* Dropdown Profil */
    .dropdown-menu { border: none; box-shadow: 0 10px 30px rgba(216, 58, 74, 0.2); border-radius: 15px; background: #fff; }
    .dropdown-item { color: #333; padding: 0.75rem 1.5rem; transition: background 0.3s; }
    .dropdown-item:hover { background: rgba(216, 58, 74, 0.1); color: #d83a4a; }
    .dropdown-item i { margin-right: 0.5rem; }
    /* Header */
    .detail-header { background: linear-gradient(135deg, #d83a4a, #c0392b); color: #fff; padding: 3rem 0; text-align: center; margin-bottom: 2rem; }
    .detail-header h1 { font-size: 2.5rem; font-weight: 700; margin-bottom: 0.5rem; }
    .detail-header p { font-size: 1.1rem; opacity: 0.9; }
    /* Tombol Kembali */
    .back-btn { background: #6c757d; color: #fff; border: none; padding: 0.75rem 1.5rem; border-radius: 25px; font-weight: 500; transition: all 0.3s; text-decoration: none; display: inline-block; margin-bottom: 1rem; }
    .back-btn:hover { background: #5a6268; color: #fff; transform: translateY(-2px); }
    /* Detail Section */
    .detail-section { max-width: 1000px; margin: 0 auto; padding: 0 1rem; }
    .order-summary-card { background: #fff; border-radius: 20px; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.1); margin-bottom: 2rem; transition: all 0.3s; }
    .order-summary-card:hover { transform: translateY(-5px); box-shadow: 0 15px 40px rgba(0,0,0,0.15); }
    .summary-header { background: linear-gradient(135deg, #d83a4a, #c0392b); color: #fff; padding: 1.5rem; }
    .summary-header h5 { margin: 0; font-weight: 600; }
    .summary-body { padding: 1.5rem; }
    .status-badge-large { padding: 0.75rem 1.5rem; border-radius: 25px; font-weight: 600; font-size: 1rem; display: inline-block; margin-bottom: 1rem; transition: all 0.3s; }
    .status-pending { background: #fff3cd; color: #856404; }
    .status-processing { background: #d1ecf1; color: #0c5460; }
    .status-completed { background: #d4edda; color: #155724; }
    .status-message { color: #666; font-style: italic; margin-top: 0.5rem; }
    .info-row { display: flex; justify-content: space-between; margin-bottom: 0.5rem; }
    .info-label { font-weight: 500; color: #d83a4a; }
    .info-value { color: #333; }
    /* Products Table */
    .products-card { background: #fff; border-radius: 20px; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.1); margin-bottom: 2rem; }
    .products-header { background: #f8f9fa; padding: 1rem 1.5rem; border-bottom: 1px solid #dee2e6; }
    .products-header h6 { margin: 0; color: #d83a4a; font-weight: 600; }
    .table { margin: 0; }
    .table th { background: #f8f9fa; border-top: none; font-weight: 500; color: #333; }
    .table td { vertical-align: middle; border-color: #eee; }
    .product-img-small { width: 60px; height: 60px; object-fit: cover; border-radius: 10px; }
    .subtotal-price { font-weight: 600; color: #18a74a; }
    .grand-total { font-size: 1.25rem; font-weight: 700; color: #d83a4a; }
    /* Empty State */
    .empty-state { text-align: center; padding: 3rem; color: #666; }
    .empty-state i { font-size: 4rem; margin-bottom: 1rem; opacity: 0.5; }
    /* Footer */
    .footer { background: linear-gradient(135deg, #d83a4a, #c0392b); color: #fff; padding: 3rem 0 1rem; margin-top: 4rem; }
    .footer h6 { font-weight: 600; margin-bottom: 1rem; color: #fff; }
    .footer p, .footer a { color: rgba(255,255,255,0.8); }
    .footer a:hover { color: #fff; text-decoration: underline; }
    .footer-social i { font-size: 1.5rem; margin: 0 0.5rem; color: #fff; transition: color 0.3s; }
    .footer-social i:hover { color: #ffd700; }
    .footer-bottom { border-top: 1px solid rgba(255,255,255,0.1); padding-top: 1.5rem; margin-top: 2rem; text-align: center; color: rgba(255,255,255,0.7); }
    /* TAMBAHAN: Animasi Pulse untuk Badge Saat Update */
    @keyframes pulse {
      0% { transform: scale(1); }
      50% { transform: scale(1.05); }
      100% { transform: scale(1); }
    }
    /* Toast Styling (Bootstrap default, tapi custom warna header) */
    .toast-header.bg-warning { background-color: #fff3cd !important; color: #856404 !important; border: 1px solid #ffeaa7; }
    .toast-header.bg-info { background-color: #d1ecf1 !important; color: #0c5460 !important; border: 1px solid #bee5eb; }
    .toast-header.bg-success { background-color: #d4edda !important; color: #155724 !important; border: 1px solid #c3e6cb; }
    /* Responsive */
    @media (max-width: 768px) {
      .detail-header h1 { font-size: 2rem; }
      .info-row { flex-direction: column; gap: 0.25rem; }
      .table { font-size: 0.9rem; }
      .product-img-small { width: 50px; height: 50px; }
      .back-btn { width: 100%; text-align: center; }
      .footer { padding: 2rem 0 1rem; }
      .toast-container { bottom: 10px !important; right: 10px !important; }
    }
  </style>
</head>
<body>

<!-- Navbar Bootstrap Modern -->
<nav class="navbar navbar-expand-lg navbar-custom fixed-top">
  <div class="container">
    <a class="navbar-brand" href="index.php">
      <i class="fas fa-home me-2"></i>Ruang Sukma
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link" href="index.php"><i class="fas fa-home me-1"></i>Home</a></li>
        <li class="nav-item"><a class="nav-link" href="index.php"><i class="fas fa-box me-1"></i>Produk</a></li>
        <li class="nav-item position-relative">
          <a class="nav-link" href="cart.php">
            <i class="fas fa-shopping-cart me-1"></i>Keranjang
            <?php if(isset($_SESSION['cart']) && count($_SESSION['cart']) > 0): ?>
              <span class="badge bg-light text-dark rounded-pill ms-1"><?php echo count($_SESSION['cart']); ?></span>
            <?php endif; ?>
          </a>
        </li>
        <!-- Dropdown Profil User -->
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            <i class="fas fa-user-circle me-1"></i>
            Halo, <?= htmlspecialchars($user_name ?? 'User   ') ?>!
          </a>
          <ul class="dropdown-menu dropdown-menu-end">
            <li><a class="dropdown-item" href="profil_user.php"><i class="fas fa-user me-2"></i>Profil Saya</a></li>
            <li><a class="dropdown-item" href="ubah_password.php"><i class="fas fa-key me-2"></i>Ubah Password</a></li>
            <li><a class="dropdown-item" href="orders.php"><i class="fas fa-shopping-bag me-2"></i>Riwayat Pesanan</a></li>
            <li><hr class="dropdown-divider"></li>
            <            <li><a class="dropdown-item text-danger" href="logout_user.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
          </ul>
        </li>
      </ul>
    </div>
  </div>
</nav>

<!-- Header Section -->
<section class="detail-header" data-aos="fade-down">
  <div class="container">
    <h1><i class="fas fa-receipt me-2"></i>Detail Pesanan</h1>
    <p>Order #<?= $order_id ?> - Pantau progres pesanan Anda</p>
  </div>
</section>

<!-- Detail Section -->
<section class="detail-section" data-aos="fade-up">
  <!-- Tombol Kembali ke Riwayat Pesanan -->
  <div class="text-center mb-3">
    <a href="orders.php" class="back-btn">
      <i class="fas fa-arrow-left me-2"></i>Kembali ke Riwayat Pesanan
    </a>
  </div>

  <!-- Order Summary Card -->
  <div class="order-summary-card">
    <div class="summary-header">
      <h5><i class="fas fa-info-circle me-2"></i>Ringkasan Pesanan</h5>
    </div>
    <div class="summary-body">
      <!-- Status Progres (Admin Update) - ID untuk JS auto-update -->
      <span id="status-badge" class="status-badge-large status-<?= htmlspecialchars($order['status']) ?>">
        <i id="status-icon" class="fas fa-<?= $order['status'] === 'completed' ? 'check-circle' : ($order['status'] === 'processing' ? 'cog' : 'clock') ?> me-2"></i>
        <?= ucfirst(htmlspecialchars($order['status'])) ?>
      </span>
      <div id="status-message" class="status-message">
        <?= htmlspecialchars($status_messages[$order['status']] ?? 'Status tidak diketahui') ?>
      </div>
      
      <!-- Info Order -->
      <div class="mt-3">
        <div class="info-row">
          <span class="info-label">ID Pesanan:</span>
          <span class="info-value">#<?= htmlspecialchars($order['order_id']) ?></span>
        </div>
        <div class="info-row">
          <span class="info-label">Tanggal Pesan:</span>
          <span class="info-value"><?= date('d M Y H:i', strtotime($order['order_date'])) ?></span>
        </div>
        <div class="info-row">
          <span class="info-label">Penerima:</span>
          <span class="info-value"><?= htmlspecialchars($order['user_name']) ?></span>
        </div>
        <div class="info-row">
          <span class="info-label">Alamat Pengiriman:</span>
          <span class="info-value"><?= htmlspecialchars($order['shipping_address'] ?? 'Belum diisi. Silakan update profil Anda.') ?></span>
        </div>
        <div class="info-row">
          <span class="info-label">Total Item:</span>
          <span class="info-value"><?= $total_items ?> item</span>
        </div>
        <div class="info-row">
          <span class="info-label">Total Bayar:</span>
          <span class="info-value grand-total">Rp <?= number_format($order['total_amount'], 0, ',', '.') ?></span>
        </div>
      </div>
    </div>
  </div>

  <!-- Products List Card -->
  <?php if (!empty($order_details)): ?>
    <div class="products-card">
      <div class="products-header">
        <h6><i class="fas fa-boxes me-2"></i>Daftar Produk (<?= $total_items ?> Item)</h6>
      </div>
      <div class="table-responsive">
        <table class="table table-hover">
          <thead>
            <tr>
              <th width="15%">Gambar</th>
              <th>Produk</th>
              <th width="10%">Qty</th>
              <th width="15%">Harga Satuan</th>
              <th width="15%">Subtotal</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($order_details as $detail): ?>
              <tr>
                <td>
                  <img src="produk/<?= htmlspecialchars($detail['product_image'] ?? 'default.jpg') ?>" alt="<?= htmlspecialchars($detail['product_name']) ?>" class="product-img-small" onerror="this.src='https://via.placeholder.com/60x60/d83a4a/ffffff?text=Img'">
                </td>
                <td><?= htmlspecialchars($detail['product_name']) ?></td>
                <td><?= $detail['quantity'] ?></td>
                <td>Rp <?= number_format($detail['price'], 0, ',', '.') ?></td>
                <td class="subtotal-price">Rp <?= number_format($detail['subtotal'], 0, ',', '.') ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  <?php else: ?>
    <div class="products-card empty-state">
      <i class="fas fa-box-open"></i>
      <h5 class="mt-3">Tidak Ada Detail Produk</h5>
      <p class="mb-0">Hubungi admin jika ada masalah dengan pesanan ini.</p>
    </div>
  <?php endif; ?>
</section>

<!-- Footer Modern -->
<footer class="footer">
  <div class="container">
    <div class="row">
      <div class="col-lg-4 col-md-6 mb-4">
        <h6><i class="fas fa-heart me-2"></i>Tentang Ruang Sukma</h6>
        <p>Ruang Sukma adalah platform e-commerce yang menyediakan produk berkualitas tinggi dengan pengiriman cepat dan layanan pelanggan terbaik.</p>
        <div class="footer-social">
          <a href="#"><i class="fab fa-facebook-f"></i></a>
          <a href="#"><i class="fab fa-instagram"></i></a>
          <a href="#"><i class="fab fa-twitter"></i></a>
          <a href="#"><i class="fab fa-whatsapp"></i></a>
        </div>
      </div>
      <div class="col-lg-2 col-md-6 mb-4">
        <h6>Produk</h6>
        <ul class="list-unstyled">
          <li><a href="index.php"><i class="fas fa-chevron-right me-2"></i>Kategori Utama</a></li>
          <li><a href="index.php"><i class="fas fa-chevron-right me-2"></i>Promo Spesial</a></li>
          <li><a href="index.php"><i class="fas fa-chevron-right me-2"></i>Produk Terbaru</a></li>
        </ul>
      </div>
      <div class="col-lg-3 col-md-6 mb-4">
        <h6>Customer Service</h6>
        <ul class="list-unstyled">
          <li><a href="orders.php"><i class="fas fa-chevron-right me-2"></i>Riwayat Pesanan</a></li>
          <li><a href="#"><i class="fas fa-chevron-right me-2"></i>Hubungi Kami</a></li>
          <li><a href="#"><i class="fas fa-chevron-right me-2"></i>FAQ</a></li>
          <li><a href="#"><i class="fas fa-chevron-right me-2"></i>Kebijakan Privasi</a></li>
        </ul>
      </div>
      <div class="col-lg-3 col-md-6 mb-4">
        <h6>Kontak</h6>
        <p><i class="fas fa-envelope me-2"></i>info@ruangsukma.com</p>
        <p><i class="fas fa-phone me-2"></i>+62 123 4567 890</p>
        <p><i class="fas fa-map-marker-alt me-2"></i>Jl. Sukma No. 123, Jakarta, Indonesia</p>
      </div>
    </div>
    <div class="footer-bottom">
      <p>&copy; 2024 Ruang Sukma. Semua hak dilindungi. Dibuat dengan <i class="fas fa-heart text-danger"></i> untuk Anda.</p>
    </div>
  </div>
</footer>

<!-- TAMBAHAN: Toast Container untuk Notifikasi Status Update (pojok kanan bawah) -->
<div class="toast-container position-fixed bottom-0 end-0 p-3">
    <div id="statusToast" class="toast" role="alert" aria-live="assertive" aria-atomic="true">
        <div class="toast-header">
            <i class="fas fa-bell me-2 text-primary"></i>
            <strong class="me-auto">Update Status Pesanan</strong>
            <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
        <div class="toast-body">
            <span id="toastMessage"></span>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<!-- AOS JS -->
<script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
<script>
  AOS.init({
    duration: 1000,
    once: true
  });

  // TAMBAHAN: JS Polling untuk Auto-Update Status (berubah-ubah diam-diam dari admin)
  // Variabel dari PHP (status awal, order ID, mapping)
  const initialStatus = '<?= $initial_status ?>';
  const orderId = <?= $order_id ?>;
  const statusMessages = <?= json_encode($status_messages) ?>;
  const statusIcons = {
    'pending': 'clock',
    'processing': 'cog',
    'completed': 'check-circle'
  };
  const statusClasses = {
    'pending': 'status-pending',
    'processing': 'status-processing',
    'completed': 'status-completed'
  };

  let currentStatus = initialStatus;  // Track status saat ini

  // TAMBAHAN: Fungsi untuk tampilkan toast notifikasi saat status berubah
  function showStatusToast(newStatus) {
    const toastEl = document.getElementById('statusToast');
    const toastMessage = document.getElementById('toastMessage');
    const toast = new bootstrap.Toast(toastEl);

    const statusDisplay = newStatus.charAt(0).toUpperCase() + newStatus.slice(1);
    toastMessage.innerHTML = `Status pesanan Anda telah diupdate menjadi: <strong>${statusDisplay}</strong>. Cek detail di bawah!`;

    // Set warna header toast berdasarkan status (override Bootstrap)
    const header = toastEl.querySelector('.toast-header');
    header.className = `toast-header ${statusClasses[newStatus] || 'bg-warning text-dark'}`;

    toast.show();  // Tampilkan toast (auto-hide setelah 5 detik)
  }

  // Fungsi untuk update tampilan status (ditingkatkan dengan panggil toast jika berubah)
  function updateStatus(newStatus) {
    if (newStatus && newStatus !== currentStatus) {
      console.log('Status updated to:', newStatus);  // Debug log (opsional, bisa hilangkan)
      
      // Tampilkan toast notifikasi (hanya sekali per perubahan)
      showStatusToast(newStatus);
      
      // Update visual (badge, icon, message)
      const badge = document.getElementById('status-badge');
      const icon = document.getElementById('status-icon');
      const message = document.getElementById('status-message');
      
      badge.className = `status-badge-large ${statusClasses[newStatus] || 'status-pending'}`;
      icon.className = `fas fa-${statusIcons[newStatus] || 'clock'} me-2`;
      badge.innerHTML = `<i class="fas fa-${statusIcons[newStatus] || 'clock'} me-2"></i>${newStatus.charAt(0).toUpperCase() + newStatus.slice(1)}`;
      message.textContent = statusMessages[newStatus] || 'Status tidak diketahui';
      
      currentStatus = newStatus;
      badge.style.transition = 'all 0.5s ease';
      
      // Opsional: Efek animasi badge (pulse)
      badge.style.animation = 'pulse 0.5s ease-in-out';
    }
  }

  // Fungsi AJAX untuk cek status terbaru (fetch ke halaman yang sama dengan ajax=1)
  function checkStatusUpdate() {
    fetch(`order_detail.php?id=${orderId}&ajax=1`)
      .then(response => {
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        return response.json();
      })
      .then(data => {
        if (data.status) {
          updateStatus(data.status);  // Ini akan trigger toast jika berubah
        } else if (data.error) {
          console.error('Error from server:', data.error);
        }
      })
      .catch(error => {
        console.error('Error checking status:', error);
        // Tidak tampilkan error ke user (diam-diam, lanjut polling)
      });
  }

  // Polling setiap 30 detik (30000 ms) - "berubah-ubah" otomatis
  setInterval(checkStatusUpdate, 30000);
  
  // Cek sekali saat halaman load (untuk sinkronisasi awal)
  checkStatusUpdate();
</script>

<?php
mysqli_close($conn);
?>

</body>
</html>