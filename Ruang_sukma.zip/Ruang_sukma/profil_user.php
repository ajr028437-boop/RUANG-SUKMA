<?php
// profile_user.php
session_start();
include 'db.php';

if (!isset($_SESSION['user_login']) || !isset($_SESSION['user_id'])) {
    header("Location: login_user.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// Ambil data profil user
$query_user = "SELECT nama, email, no_hp, alamat, lokasi, created_at FROM tb_user WHERE id = ?";
$stmt_user = mysqli_prepare($conn, $query_user);
mysqli_stmt_bind_param($stmt_user, "i", $user_id);
mysqli_stmt_execute($stmt_user);
$result_user = mysqli_stmt_get_result($stmt_user);
$user_data = null;
if (mysqli_num_rows($result_user) > 0) {
    $user_data = mysqli_fetch_assoc($result_user);
    $_SESSION['user_name'] = $user_data['nama']; // Update session name jika berubah
}
mysqli_stmt_close($stmt_user);

// Handling Update Profil
$update_message = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_profil'])) {
    $nama = mysqli_real_escape_string($conn, $_POST['nama']);
    $no_hp = mysqli_real_escape_string($conn, $_POST['no_hp']);
    $alamat = mysqli_real_escape_string($conn, $_POST['alamat']);
    $lokasi = mysqli_real_escape_string($conn, $_POST['lokasi']);
    
    $update_query = "UPDATE tb_user SET nama = ?, no_hp = ?, alamat = ?, lokasi = ? WHERE id = ?";
    $stmt_update = mysqli_prepare($conn, $update_query);
    mysqli_stmt_bind_param($stmt_update, "sss si", $nama, $no_hp, $alamat, $lokasi, $user_id);
    if (mysqli_stmt_execute($stmt_update)) {
        $update_message = '<div class="alert alert-success">Profil berhasil diupdate!</div>';
        // Refresh data user
        $user_data['nama'] = $nama;
        $user_data['no_hp'] = $no_hp;
        $user_data['alamat'] = $alamat;
        $user_data['lokasi'] = $lokasi;
        $_SESSION['user_name'] = $nama;
    } else {
        $update_message = '<div class="alert alert-danger">Gagal update profil: ' . $conn->error . '</div>';
    }
    mysqli_stmt_close($stmt_update);
}

// Handling Ganti Password (opsional, form terpisah)
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_password'])) {
    $old_pass = $_POST['old_password'];
    $new_pass = $_POST['new_password'];
    $confirm_pass = $_POST['confirm_password'];
    
    // Ambil password lama
    $query_old = "SELECT password FROM tb_user WHERE id = ?";
    $stmt_old = mysqli_prepare($conn, $query_old);
    mysqli_stmt_bind_param($stmt_old, "i", $user_id);
    mysqli_stmt_execute($stmt_old);
    $result_old = mysqli_stmt_get_result($stmt_old);
    $old_data = mysqli_fetch_assoc($result_old);
    mysqli_stmt_close($stmt_old);
    
    if (password_verify($old_pass, $old_data['password']) && $new_pass === $confirm_pass) {
        $hashed_new = password_hash($new_pass, PASSWORD_DEFAULT);
        $update_pass_query = "UPDATE tb_user SET password = ? WHERE id = ?";
        $stmt_pass = mysqli_prepare($conn, $update_pass_query);
        mysqli_stmt_bind_param($stmt_pass, "si", $hashed_new, $user_id);
        if (mysqli_stmt_execute($stmt_pass)) {
            $update_message = '<div class="alert alert-success">Password berhasil diubah!</div>';
        } else {
            $update_message = '<div class="alert alert-danger">Gagal ubah password: ' . $conn->error . '</div>';
        }
        mysqli_stmt_close($stmt_pass);
    } else {
        $update_message = '<div class="alert alert-danger">Password lama salah atau konfirmasi tidak cocok!</div>';
    }
}

// Ambil riwayat pesanan (5 terbaru)
$query_orders = "
SELECT 
    o.order_id,
    o.total_amount,
    o.status,
    o.order_date,
    COUNT(d.product_id) as item_count,
    GROUP_CONCAT(p.product_name SEPARATOR ', ') as product_names
FROM tb_order o
LEFT JOIN tb_order_detail d ON o.order_id = d.order_id
LEFT JOIN tb_product p ON d.product_id = p.product_id
WHERE o.user_id = ?
GROUP BY o.order_id
ORDER BY o.order_date DESC
LIMIT 5
";
$stmt_orders = mysqli_prepare($conn, $query_orders);
mysqli_stmt_bind_param($stmt_orders, "i", $user_id);
mysqli_stmt_execute($stmt_orders);
$result_orders = mysqli_stmt_get_result($stmt_orders);
$orders = [];
while ($row = mysqli_fetch_assoc($result_orders)) {
    $orders[] = $row;
}
mysqli_stmt_close($stmt_orders);
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Ruang Sukma - Profil User</title>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Google Fonts: Poppins -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <!-- Font Awesome -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
  <!-- AOS Animations -->
  <link href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css" rel="stylesheet">
  <style>
    body {
      font-family: 'Poppins', sans-serif;
      background: linear-gradient(135deg, #f4f6f8, #e9ecef);
      color: #333;
      line-height: 1.6;
      padding-top: 80px;
    }
    a { text-decoration: none; }
    .navbar-custom {
      background: rgba(216, 58, 74, 0.95) !important;
      backdrop-filter: blur(20px);
      box-shadow: 0 4px 20px rgba(216, 58, 74, 0.2);
      padding: 1rem 0;
    }
    .navbar-brand { font-weight: 700; font-size: 1.8rem; color: #fff !important; }
    .nav-link { color: #fff !important; font-weight: 500; padding: 0.5rem 1rem; }
    .nav-link:hover { color: #f8f9fa !important; }
    .profile-section { max-width: 1000px; margin: 2rem auto; padding: 0 1rem; }
    .profile-card { background: #fff; border-radius: 20px; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.1); margin-bottom: 2rem; }
    .profile-header { background: linear-gradient(135deg, #d83a4a, #c82333); color: #fff; padding: 2rem; text-align: center; }
    .profile-details { padding: 2rem; }
    .detail-row { display: flex; justify-content: space-between; padding: 0.5rem 0; border-bottom: 1px solid #eee; }
    .detail-label { font-weight: 500; color: #666; }
    .detail-value { font-weight: 600; color: #d83a4a; }
    .form-control { border-radius: 10px; border: 1px solid #ddd; padding: 0.75rem; }
    .btn-primary { background: linear-gradient(135deg, #d83a4a, #c82333); border: none; border-radius: 10px; padding: 0.75rem 1.5rem; font-weight: 600; }
    .btn-primary:hover { background: linear-gradient(135deg, #c82333, #b21f2d); transform: translateY(-2px); }
    .orders-table { margin-top: 2rem; }
    .orders-table th { background: #d83a4a; color: #fff; }
    .orders-table td { vertical-align: middle; }
    .status-badge { font-size: 0.85rem; }
    footer { background: linear-gradient(135deg, #d83a4a, #c82333); color: #fff; margin-top: 4rem; }
    .social-links a { color: #fff; font-size: 1.5rem; margin: 0 0.5rem; transition: color 0.3s; }
    .social-links a:hover { color: #ffd700; }
    @media (max-width: 768px) {
      .detail-row { flex-direction: column; text-align: left; }
      .profile-header { padding: 1rem; }
      .orders-table { font-size: 0.9rem; }
    }
  </style>
</head>
<body>

<!-- Navbar (Sama seperti success.php, index.php, cart.php) -->
<nav class="navbar navbar-expand-lg navbar-custom fixed-top">
  <div class="container">
    <a class="navbar-brand" href="index.php">
      <i class="fas fa-home me-2"></i>Ruang Sukma
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link" href="index.php"><i class="fas fa-home me-1"></i>Home</a></li>
        <li class="nav-item"><a class="nav-link" href="index.php#produk"><i class="fas fa-box me-1"></i>Produk</a></li>
        <li class="nav-item"><a class="nav-link" href="cart.php"><i class="fas fa-shopping-cart me-1"></i>Keranjang</a></li>
        <li class="nav-item"><a class="nav-link active" href="profile_user.php"><i class="fas fa-user me-1"></i>Profil</a></li>
        <li class="nav-item"><a class="nav-link" href="logout_user.php"><i class="fas fa-sign-out-alt me-1"></i>Logout</a></li>
      </ul>
    </div>
  </div>
</nav>

<!-- Profile Section -->
<section class="profile-section">
  <div class="container">
    <?php echo $update_message; ?>
    
    <div class="profile-card" data-aos="fade-up">
      <div class="profile-header">
        <i class="fas fa-user-circle fa-5x mb-3"></i>
        <h2>Selamat Datang, <?php echo htmlspecialchars($user_data['nama'] ?? 'User '); ?>!</h2>
        <p class="mb-0">Kelola profil dan lihat riwayat pesanan Anda.</p>
      </div>
      
      <div class="profile-details">
        <h5 class="mb-3"><i class="fas fa-user-edit me-2 text-primary"></i>Edit Profil</h5>
        
        <!-- Form Edit Profil -->
        <form method="POST">
          <input type="hidden" name="update_profil" value="1">
          <div class="row">
            <div class="col-md-6 mb-3">
              <label class="form-label">Nama Lengkap</label>
              <input type="text" name="nama" class="form-control" value="<?php echo htmlspecialchars($user_data['nama'] ?? ''); ?>" required>
            </div>
            <div class="col-md-6 mb-3">
              <label class="form-label">Email (Tidak bisa diubah)</label>
              <input type="email" class="form-control" value="<?php echo htmlspecialchars($user_data['email'] ?? ''); ?>" disabled>
            </div>
            <div class="col-md-6 mb-3">
              <label class="form-label">No. HP</label>
              <input type="text" name="no_hp" class="form-control" value="<?php echo htmlspecialchars($user_data['no_hp'] ?? ''); ?>" required>
            </div>
            <div class="col-md-6 mb-3">
              <label class="form-label">Lokasi (Kota/Kecamatan)</label>
              <input type="text" name="lokasi" class="form-control" value="<?php echo htmlspecialchars($user_data['lokasi'] ?? ''); ?>" required>
            </div>
            <div class="col-12 mb-3">
              <label class="form-label">Alamat Lengkap</label>
              <textarea name="alamat" class="form-control" rows="3" required><?php echo htmlspecialchars($user_data['alamat'] ?? ''); ?></textarea>
            </div>
          </div>
          <button type="submit" class="btn btn-primary"><i class="fas fa-save me-2"></i>Update Profil</button>
        </form>
        
        <!-- Form Ganti Password (Opsional) -->
        <h5 class="mt-4 mb-3"><i class="fas fa-lock me-2 text-primary"></i>Ganti Password</h5>
        <form method="POST" class="row g-3">
          <input type="hidden" name="update_password" value="1">
          <div class="col-md-4">
            <label class="form-label">Password Lama</label>
            <input type="password" name="old_password" class="form-control" required>
          </div>
          <div class="col-md-4">
            <label class="form-label">Password Baru</label>
            <input type="password" name="new_password" class="form-control" required minlength="6">
          </div>
          <div class="col-md-4">
            <label class="form-label">Konfirmasi Password</label>
            <input type="password" name="confirm_password" class="form-control" required>
          </div>
          <div class="col-12">
            <button type="submit" class="btn btn-outline-primary"><i class="fas fa-key me-2"></i>Ubah Password</button>
          </div>
        </form>
      </div>
    </div>
    
    <!-- Riwayat Pesanan -->
    <div class="profile-card" data-aos="fade-up">
      <div class="profile-header" style="background: linear-gradient(135deg, #28a745, #20c997);">
        <i class="fas fa-shopping-bag fa-2x mb-2"></i>
        <h5>Riwayat Pesanan</h5>
        <p class="mb-0">Pesanan terakhir Anda (5 terbaru)</p>
      </div>
      
      <div class="profile-details">
        <?php if (empty($orders)): ?>
          <p class="text-center text-muted py-4">Belum ada riwayat pesanan.</p>
        <?php else: ?>
          <div class="table-responsive">
            <table class="table table-striped orders-table">
              <thead>
                <tr>
                  <th>ID Order</th>
                  <th>Tanggal</th>
                  <th>Produk</th>
                  <th>Total</th>
                  <th>Status</th>
                  <th>Aksi</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($orders as $order): ?>
                  <tr>
                    <td>#<?php echo $order['order_id']; ?></td>
                    <td><?php echo date('d/m/Y', strtotime($order['order_date'])); ?></td>
                    <td><?php echo htmlspecialchars(substr($order['product_names'] ?? 'Tidak ada', 0, 50)) . '...'; ?></td>
                    <td>Rp <?php echo number_format($order['total_amount'], 0, ',', '.'); ?></td>
                    <td>
                      <span class="badge bg-<?php 
                        switch ($order['status']) {
                          case 'completed': echo 'success'; break;
                          case 'processing': echo 'info'; break;
                          case 'pending': echo 'warning'; break;
                          case 'cancelled': echo 'danger'; break;
                          default: echo 'secondary';
                        }
                      ?> status-badge">
                        <?php echo ucfirst($order['status']); ?>
                      </span>
                    </td>
                    <td>
                      <a                       <a href="success.php?order_id=<?php echo $order['order_id']; ?>" class="btn btn-sm btn-outline-primary">
                        <i class="fas fa-eye me-1"></i>Lihat Detail
                      </a>
                    </td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</section>

<!-- Footer (Sama seperti success.php, index.php, cart.php) -->
<footer class="text-center py-5" data-aos="fade-up" style="background: linear-gradient(135deg, #d83a4a, #c82333); color: #fff; margin-top: 4rem;">
  <div class="container">
    <div class="row">
      <div class="col-md-6">
        <h5 class="text-white mb-3">Ruang Sukma</h5>
        <p class="text-light">Toko online terpercaya untuk kebutuhan rumah tangga dan kantor. Kualitas terbaik, harga terjangkau.</p>
      </div>
      <div class="col-md-6">
        <h5 class="text-white mb-3">Hubungi Kami</h5>
        <p class="text-light">Email: info@ruangsukma.com | Telp: (021) 123-4567</p>
        <div class="social-links d-flex justify-content-center mt-3">
          <a href="#"><i class="fab fa-facebook-f"></i></a>
          <a href="#"><i class="fab fa-instagram"></i></a>
          <a href="#"><i class="fab fa-twitter"></i></a>
          <a href="#"><i class="fab fa-whatsapp"></i></a>
        </div>
      </div>
    </div>
    <hr class="my-4 border-light">
    <p class="text-light mb-0">&copy; 2024 Ruang Sukma. All rights reserved.</p>
  </div>
</footer>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<!-- AOS JS -->
<script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
<script>
  AOS.init({
    duration: 1000,
    once: true
  });

  // Validasi form password (opsional, untuk UX lebih baik)
  document.querySelector('form[method="POST"][name="update_password"]').addEventListener('submit', function(e) {
    const newPass = document.querySelector('input[name="new_password"]').value;
    const confirmPass = document.querySelector('input[name="confirm_password"]').value;
    if (newPass !== confirmPass) {
      e.preventDefault();
      alert('Konfirmasi password tidak cocok!');
    } else if (newPass.length < 6) {
      e.preventDefault();
      alert('Password baru minimal 6 karakter!');
    }
  });
</script>

</body>
</html>