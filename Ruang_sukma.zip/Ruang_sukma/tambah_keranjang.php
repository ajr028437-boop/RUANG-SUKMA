<?php
session_start();

if (isset($_POST['id'])) {
    $id = $_POST['id'];
    $nama = $_POST['nama'];
    $harga = $_POST['harga'];

    // simpan ke session cart
    $_SESSION['cart'][] = [
        'id' => $id,
        'nama' => $nama,
        'harga' => $harga
    ];
}

header("Location: cart.php");
exit;
?>
