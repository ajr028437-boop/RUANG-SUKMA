<?php
session_start();

// hapus semua session user
session_unset();
session_destroy();

// arahkan balik ke login
header("Location: login_user.php");
exit;
